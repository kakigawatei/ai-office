﻿param([Parameter(Mandatory=$true)][string]$Kit)
# install_win.ps1 — Windows 用: 設定シートを開いてから setup_windows.ps1 を動かす（install.ps1 から呼ばれる）
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "AIオフィス セットアップ"
Write-Host ("✓ キットを " + $Kit + " に置きました") -ForegroundColor Green
Write-Host ""
Write-Host "設定シートをメモ帳で開きます。"
Write-Host "サーバー名・bot の名前・社員名簿などを変えたい場合だけ書き換えて保存（Ctrl+S）してください。"
Write-Host "メモ帳を閉じると、続きが始まります（そのままで良ければ、何もせずメモ帳を閉じるだけ）。"
Start-Process notepad.exe (Join-Path $Kit "設定シート.txt") -Wait
& (Join-Path $Kit "skill\discord-ai-office\scripts\setup_windows.ps1") -Kit $Kit
