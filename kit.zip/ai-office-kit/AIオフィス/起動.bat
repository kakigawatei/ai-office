@echo off
chcp 65001 >nul
title AIオフィス 起動
powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.claude\skills\discord-ai-office\scripts\start.ps1" -Office "%~dp0."
