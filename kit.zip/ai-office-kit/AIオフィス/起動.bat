@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.claude\skills\discord-ai-office\scripts\start.ps1" -Hold
