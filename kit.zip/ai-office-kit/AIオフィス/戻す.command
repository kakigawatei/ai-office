#!/bin/bash
# 戻す — AIオフィスを控え（更新の直前・毎日の控え）に戻す。違いを見せてから「はい」で戻し、AI を起動し直す
cd "$(dirname "$0")"
export PYTHONUTF8=1 PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
python3 "$HOME/.claude/skills/discord-ai-office/scripts/office.py" restore
read -r -p "Enter で閉じる"
