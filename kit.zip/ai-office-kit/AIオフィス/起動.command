#!/bin/bash
cd "$(dirname "$0")"
bash "$HOME/.claude/skills/discord-ai-office/scripts/start.sh" "$(pwd)"
read -r -p "Enter で閉じる"
