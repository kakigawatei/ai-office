#!/bin/bash
cd "$(dirname "$0")"
bash "$HOME/.claude/skills/discord-ai-office/scripts/restart.sh" "$(pwd)"
