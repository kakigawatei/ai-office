#!/bin/bash
cd "$(dirname "$0")"
export PYTHONUTF8=1 PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
python3 "$HOME/.claude/skills/discord-ai-office/scripts/office.py" pause
read -r -p "Enter で閉じる"
