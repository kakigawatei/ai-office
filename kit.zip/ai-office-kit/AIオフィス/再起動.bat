@echo off
chcp 65001 >nul
title AIオフィス 再起動
powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.claude\skills\discord-ai-office\scripts\restart.ps1" -Office "%~dp0."
