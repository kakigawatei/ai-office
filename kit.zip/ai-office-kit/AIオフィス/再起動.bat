@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.claude\skills\discord-ai-office\scripts\restart.ps1" -Office "%~dp0." -Hold
