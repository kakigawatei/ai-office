@echo off
chcp 65001 >nul
set PYTHONUTF8=1
python "%USERPROFILE%\.claude\skills\discord-ai-office\scripts\office.py" uninstall --office "%~dp0."
pause
