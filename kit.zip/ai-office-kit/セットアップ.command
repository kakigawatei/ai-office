#!/bin/bash
# セットアップ（Mac）: ダブルクリックで AIオフィスをまとめて用意する。先に「設定シート.txt」を書いておく
KIT="$(cd "$(dirname "$0")" && pwd)"
bash "$KIT/skill/discord-ai-office/scripts/setup_mac.sh" "$KIT"
