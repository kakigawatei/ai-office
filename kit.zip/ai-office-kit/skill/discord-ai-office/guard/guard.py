#!/usr/bin/env python
"""Discord 用 Claude の見張りと関所（T-0354 対策1・3・2026-09-28／監査 AUDIT-guard.md を受けて第2版）。

Discord から動く Claude（全許可＝bypassPermissions）と、その Claude が起動した子のセッションだけに効かせるフック。
起動ファイルが立てる AIOFFICE_DISCORD=1 が無ければ何もしない（PC のセッションには効かない）。
  - pre は ~/.claude/settings.json（ユーザー設定）に登録する。子の claude も環境変数を受け継ぐので見張りが付く（監査 C-1）
  - start は Discord 用の起動にだけ渡す ~/.claude/ai-office/guard/settings.json に登録する（子のセッションでは報告しない）
  どちらも `office.py guard on` が登録し、`office.py guard off` が外す（キット版・2026-09-30。原作 momomon）

  guard.py pre    PreToolUse。操作を1行ずつ記録し（対策3）、危ない操作は Discord に ✅ を求める（対策1）。
                  ✅ を押したのが access.json の allowFrom（オーナー）かを、フック自身が Discord API で確かめてから通す。
                  秘密の置き場を読む操作は ✅ なしで拒否する（対策2 を子のセッションにも効かせるため）。
  guard.py start  SessionStart。前回の報告以降の「危ない操作 N 件」を bot で統括の部屋へ直接投稿する。
  guard.py classify <tool> <json>   判定だけを見る（試験用・Discord に出さない）

倒し方: 危ない操作の確認が出せないときは止める。記録が書けないだけのときは止めない。
フックの時間切れ（timeout）は「通す」扱いだと実測済み（2026-09-28）なので、待つのは開始から WAIT_SEC まで・
Discord への1回の問い合わせも短く切り、フックの timeout（600秒）まで大きく余裕を残す。
Python 標準ライブラリだけで動く。トークンの値は表示・記録しない。書き換え可能な場所のコードは import しない（監査 C-2）。
"""

import datetime
import json
import os
import re
import sys
import time

T0 = time.time()
HOME = os.path.expanduser("~")
LOCAL_RULES = os.path.join(HOME, ".claude", "ai-office", "local", "guard_rules.py")   # 持ち主の追加規則（更新で触らない置き場）
HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(HOME, ".claude", "channels", "discord", ".env")
ACCESS_FILE = os.path.join(HOME, ".claude", "channels", "discord", "access.json")
STAFF_FILE = os.path.join(HOME, ".claude", "ai-office", "staff.json")
USER_SETTINGS = os.path.join(HOME, ".claude", "settings.json")
STATE_DIR = os.environ.get("AIOFFICE_GUARD_DIR") or os.path.join(HOME, ".claude", "ai-office", "guard")
LOG_FILE = os.path.join(STATE_DIR, "log.jsonl")
REPORT_STATE = os.path.join(STATE_DIR, "last_report.json")
API = "https://discord.com/api/v10"
UA = "DiscordBot (ai-office-guard, 2.0)"
OK_EMOJI, NG_EMOJI = "✅", "❌"
WAIT_SEC = int(os.environ.get("AIOFFICE_GUARD_WAIT", "240"))   # フック開始から数える（監査 M-1）
WAIT_TEXT = ("%d分" % round(WAIT_SEC / 60)) if WAIT_SEC >= 60 else ("%d秒" % WAIT_SEC)
POLL_SEC = 3
MAX_SHOW = 900   # 確認に出す文字数の上限。超えるものは確認を出さずに拒否（監査 H-4）
JST = datetime.timezone(datetime.timedelta(hours=9))

# ---------------------------------------------------------------- 判定の材料

# 秘密の置き場（ファイルのパス）。Read/Grep/Glob・添付で当たれば ✅ なしで拒否
SECRET_PATH_RE = re.compile(
    r"(?i)(^|[\\/])\.env(\.(?!example$|sample$|template$|dist$)[\w.-]+)?$|(^|[\\/])\.dev\.vars$"
    r"|[\\/]\.ssh([\\/]|$)|\.credentials\.json$|\.git-credentials$|(^|[\\/])\.claude\.json$"
    r"|\.wrangler[\\/]config|xdg\.config[\\/]\.wrangler|\.config[\\/]office-backup|\.dpapi$"
    r"|[\\/]\.codex([\\/]|$)|github cli[\\/]hosts\.yml$|channels[\\/]discord[\\/]\.env")

# 秘密の置き場そのもの（Grep/Glob/LS がこれを含むフォルダを指したら拒否・再監査 H-D）
HOME_ = os.path.expanduser("~")
SECRET_LOCATIONS = [os.path.normcase(os.path.join(HOME_, *p.split("/"))) for p in (
    ".claude/channels/discord", ".claude/.credentials.json", ".claude.json", ".ssh", ".config/office-backup",
    "AppData/Roaming/xdg.config/.wrangler", ".codex", ".git-credentials", "AppData/Roaming/GitHub CLI")]

# 8.3 形式の短い名前（CODEX~1 など）。deny の一覧をすり抜けるので、コマンドに出たら ✅（再監査 H-B）
SHORT_NAME_RE = re.compile(r"[A-Za-z0-9_$&#!{}()@'-]{1,6}~\d")   # パス（Read 等の値）用
# コマンド用: 区切りの直後の語だけ・HEAD~1 等の git の書き方と npm の @~ は除く（第3監査の誤爆）
SHORT_CMD_RE = re.compile(r"(?<![A-Za-z0-9_$-])(?!(?:HEAD|ORIG_HEAD|FETCH_HEAD|MERGE_HEAD)~)[A-Za-z0-9_$-]{1,6}~\d")   # 直前が名前の文字でなければ何でも（第4監査 N4-2）
TILDE_SUSPECT_RE = re.compile(r"(?<![@\s=])~(?=[\"'\\]*[\d$`({?*\[])|(?<=[$`)}\"'\\])~(?=[\"'\\]*[\d$`({?*\[])")   # 第6監査 N6-1: 展開で名前を隠した短い名前
# （2026-09-30 関所の見直し）短い名前は NAME~数字 なので、~ のあと（引用符を飛ばして）数字・展開・ワイルドカードが来るときだけ疑う。
# '~/…'（家のフォルダ）や '~'（置き換えの文字）は短い名前にならないので通す
SHORT_PATH_TOKEN_RE = re.compile(r"[\\/][A-Za-z0-9_$&#!{}()@'-]{1,6}~\d|~\d[\\/]")   # git のコマンドではパスの形だけ見る

ENV_TOKEN_RE = re.compile(r"(?i)\$env:DISCORD_BOT_TOKEN|\$\{?DISCORD_BOT_TOKEN\b|%DISCORD_BOT_TOKEN%|os\.environ\[.DISCORD_BOT_TOKEN|environ\.get\(.DISCORD_BOT_TOKEN")   # 環境変数に入れたトークン（B5①）

# コマンドに現れたら ✅（秘密の読み出し）
SECRET_RE = re.compile(
    r"(?i)(^|[\\/\s\"'=:(])\.env(\.(?!example\b|sample\b|template\b|dist\b)[a-z0-9_-]+)?($|[\s\"';|&)<>,])"
    r"|\.dev\.vars|[\\/]\.ssh([\\/\s\"']|$)|\.credentials\.json|\.git-credentials|[\\/]\.claude\.json"
    r"|\.wrangler[\\/]config|xdg\.config[\\/]\.wrangler|\.codex[\\/]auth\.json"
    r"|\.config[\\/]office-backup|\.dpapi\b|unprotect|protecteddata"
    r"|show-password|print-restic-password|restic_password|discord_bot_token|office\.py\s+token\b|find-generic-password|token\.dpapi|\$env:DISCORD|printenv|\bset\s*$|Get-ChildItem\s+Env:|\benv\s*$"
    r"|github cli[\\/]hosts\.yml|\bgh\s+auth\s+token"
    r"|[\\/]\.codex([\\/\s\"']|$)|\.claude[\\/]channels|xdg\.config|\.config[\\/]office")   # フォルダごとの写し（再監査 H-D）

# 見張り自身・起動のしかけ・許可の表・後で動く仕掛け。変えるなら ✅
CONFIG_RE = re.compile(
    r"(?i)discord-guard|discord-ai-office[\\/]guard|ai-office[\\/]guard|channels[\\/]discord|access\.json"
    r"|\.claude[\\/]settings(\.local)?\.json|tools[\\/]guard_hook|tools[\\/]__pycache__|project_guard_snapshot"
    r"|launch_claude|start\.ps1|restart\.ps1|モデル設定|起動時の指示|mcp-needs-auth-cache"
    r"|\bschtasks\b|(register|set|unregister|start|stop|disable)-scheduled(task|job)"
    r"|\breg(\.exe)?\s+(add|delete|import)\b|(set|new|remove)-itemproperty"
    r"|office\.py\s+(hire|hire-all|project|fire|migrate|guard|uninstall|pause)\b|office\.py\s+model\s+[A-Za-z]|\.mcp\.json|\bclaude\s+mcp\s+(add|remove|add-json)"   # 中11: 止める・格下げも ✅（model の表示だけは通す）
    r"|\bcrontab\b|\blaunchctl\s+(load|bootstrap|enable|kickstart|submit)\b|core\.hooksPath|alias\.[^=\s]+=\s*['\"]?!|LaunchAgents|LaunchDaemons|[\\/]Startup[\\/]")   # 中8: 後で動く仕掛け

# 見張り自身・起動の仕掛け・毎回読まれる指示・python の乗っ取り先を「書き換える」コマンド（読むだけ・office.py の実行は通す）。重大2・3
SKILL_TOUCH_RE = re.compile(r"(?i)skills[\\/]discord-ai-office[\\/]|[\\/]\.local[\\/]bin[\\/]|usercustomize|sitecustomize|site-packages|更新コマンド|[\\/]\.claude[\\/]CLAUDE\.md|ai-office[\\/]staff[\\/]|ai-office[\\/]handoff|ai-office[\\/]config\.json|ai-office[\\/]local[\\/]")
WRITE_PROGS = {"cp", "mv", "rm", "sed", "tee", "chmod", "chown", "ln", "install", "truncate", "dd", "rsync", "patch", "touch", "mkdir",
               "set-content", "out-file", "add-content", "copy-item", "move-item", "remove-item", "new-item", "ni", "rename-item", "set-itemproperty"}
WRITE_API_RE = re.compile(r"(?i)open\([^)]*['\"][wax]b?\+?['\"]|write_text|write_bytes|writealltext|writeallbytes|writefilesync|writefile\(|\.write\(|Set-Content|Out-File|Add-Content")

# 別の AI を起動する（子には discord-settings.json が付かない。環境変数を外す書き方もありうる）（監査 C-1）
AGENT_RE = re.compile(
    r"(?i)(^|[\s;&|(\\/\"'])(claude|codex)(\.exe|\.cmd|\.ps1)?(\s|$|[\"'])|@anthropic-ai/claude-code|@openai/codex")
# 起動ではなく「動いているかを調べる」書き方（Name='claude.exe'・Get-Process claude など）。この部分だけ外してから AGENT_RE を見る（2026-09-30 関所の見直し）
PROC_QUERY_RE = re.compile(
    r"(?i)\bname\s*(=|-eq|-like|-match|-ne)\s*['\"](claude|codex)(\.exe)?['\"]"
    r"|\bimagename\s+(eq|ne)\s+(claude|codex)(\.exe)?(?=[\s\"']|$)"
    r"|\b(get-process|gps|pgrep|pidof)\s+(-name\s+)?['\"]?(claude|codex)(\.exe)?['\"]?(?=\s|$|,)")

# 中身が読めない形で実行する（文字列の判定を素通りするため ✅）（監査 H-3）
OPAQUE_RE = re.compile(
    r"(?i)\|\s*(sh|bash|zsh|dash|pwsh|powershell|cmd|iex|invoke-expression)(\.exe)?\b"
    r"|(^|[\s;&|(])(eval|iex|invoke-expression)\s|-e(nc(odedcommand)?)?\s+[A-Za-z0-9+/=]{16,}"
    r"|\bbase64\s+(-d|--decode)\b|frombase64string")

# 外に出す・公開する（監査 H-2 の分を追加）。git の副コマンドは語に割って _git_sub で見る（入れ子の量化子は
# 破滅的バックトラックで判定が止まり、フックの時間切れ＝通すになった・再監査 NEW-C3）。ここには入れ子の量化子を書かない
PUBLISH_RE = re.compile(
    r"(?i)\bwrangler\s+(deploy|publish|rollback|pages\s+deploy|versions\s+deploy|deployments?\s|secret\s+(put|delete|bulk)"
    r"|r2\s+(object\s+(put|delete)|bucket\s+(create|delete))|kv(:key|\s+key)\s+(put|delete)|kv\s+(bulk|namespace\s+delete)"
    r"|d1\s+(execute\b[^|;&]*--remote|delete|migrations\s+apply\b[^|;&]*--remote)|queues\s+delete|delete)"
    r"|\b(npm|pnpm|yarn|bun)\s+publish\b"
    r"|\b(npm|pnpm|yarn|bun|npx)\s+(run\s+|run-script\s+)?[\w:.-]{0,40}(deploy|publish|release|ship|upload)"
    r"|\bmake\s+[\w.-]{0,40}(deploy|publish|release|upload)"   # スクリプト経由の公開（第4監査 N4-5）
    r"|\bvercel\b|\bnetlify\s+deploy\b|\bfirebase\s+deploy\b|\bdocker\s+push\b"
    r"|\bgh\s+(pr\s+(create|merge|close|comment|review)|release\s+(create|upload|delete)|repo\s+(create|delete|edit|sync)"
    r"|issue\s+(create|comment|close)|gist\s+create|secret\s+set|workflow\s+run)"
    r"|\bgh\s+api\b[^|;&]*((-X\s*|--method\s+)(POST|PUT|PATCH|DELETE)|\s(-f|-F|--field|--raw-field|--input)(\s|=))"
    r"|send-mailmessage|\bsmtplib\b|\bsendmail\b|\bmail\s+-s\b"
    r"|requests\.(post|put|patch|delete)\s*\(|method\s*[:=]\s*['\"](POST|PUT|PATCH|DELETE)['\"]"
    r"|\bcurl\b[^|;&]*\s-(?-i:[A-Za-z]*[dFT])(\s|=|$|@|[\"'])"   # curl の -d・-F・-T（-sd のようなまとめ書きも）。-D（見出しの表示）・-f は送信ではない（2026-09-30 関所の見直し）
    r"|\b(curl|wget)\b[^|;&]*(\s(--data\S*|--json|--form\S*|--upload-file|--post-\S+|--method|--body-\S+)(\s|=)|-X\s*(POST|PUT|PATCH|DELETE))"
    r"|\b(invoke-webrequest|invoke-restmethod|iwr|irm)\b[^|;&]*-(method\s+(post|put|patch|delete)|body|infile)\b"
    r"|(^|[\s;&|(])(scp|sftp|rsync|rclone|ftp|tftp|smbclient|pscp|winscp)(\s|$)|\bnet\s+use\b|\baws\s+s3\s+(cp|sync|mv)\b"
    r"|\bgsutil\s+(cp|rsync|mv)\b|\baz\s+storage\b|\brestic\b[^|;&]*\s(backup|copy)\b"
    r"|(^|[\s\"'=(])\\\\[A-Za-z0-9._-]+\\"   # scp/rsync 等の持ち出し・UNC パス（再監査 H-C）
    r"|(^|[\s;&|(])(ssh|nslookup|dig|host|nc|ncat|netcat|telnet)(\.exe)?\s"   # 中7: 別の経路での持ち出し（DNS・生のソケット・ssh）
    r"|urlopen\([^)]*\bdata\s*=|\bhttp\.client\b|\bsocket\.(socket|create_connection)\b|\bwebsocket"
    r"|\b(curl|wget)\b[^|;&]*(\$\(|`|\?[^\s]*=\$)"   # URL にコマンドの結果を埋めて送る
    r"|\b(curl|wget|invoke-webrequest|invoke-restmethod|iwr|irm)\b[^|;&]*\s-(?-i:F)\S*(\s|=)")   # curl -F（フォーム送信・区切り無し）。-f と紛れないよう大文字だけ見る（2026-09-30 関所の見直しに合わせて調整）

# 消す・取り返しがつかない（監査 H-2・L-1 を反映）
DELETE_WORD_RE = re.compile(
    r"(?i)(^|[\s;&|(\\/.:`])(rm|rmdir|shred|remove-item|ri|del|erase|rd|rmtree|unlink|truncate)(\s|$|\()")
DELETE_OTHER_RE = re.compile(
    r"(?i)os\.remove\s*\(|\bfind\b.*\s-delete\b|(rmSync|unlinkSync|rmdirSync)\s*\(|\bfs\.(promises\.)?(rm|unlink|rmdir)\s*\("
    r"|\brestic\b[^|;&]*\b(forget|prune|key|init|migrate|repair|rewrite)\b"
    r"|\brobocopy\b[^|;&]*/(mir|purge|mov|move)\b")

TEMP_RE = re.compile(r"(?i)^(/tmp/|[a-z]:?[\\/].*[\\/]appdata[\\/]local[\\/]temp[\\/]|/c/users/[^/]+/appdata/local/temp/|.*[\\/]scratchpad[\\/])")

READONLY_FIRST = {"cat", "type", "ls", "dir", "head", "tail", "less", "more", "grep", "rg", "wc", "stat", "file",
                  "sha256sum", "md5sum", "get-content", "gc", "select-string", "get-childitem", "gci", "get-item",
                  "test-path", "get-filehash", "diff", "cd", "pwd", "tree", "du"}
READONLY_GIT = {"log", "diff", "show", "status", "blame", "ls-files"}
ECHO_FIRST = {"echo", "printf", "write-host", "write-output"}

# 書き込み系ツールで関所を通すパス
WRITE_GUARD_RE = re.compile(
    r"(?i)discord-guard|ai-office[\\/]guard|channels[\\/]discord|[\\/]\.claude[\\/]settings(\.local)?\.json"
    r"|launch_claude|[\\/]start\.ps1$|[\\/]restart\.ps1$|モデル設定|起動時の指示|更新コマンド|[\\/]\.git[\\/]hooks[\\/]"
    r"|skills[\\/]discord-ai-office[\\/]|[\\/]\.local[\\/]bin[\\/]|site-packages|usercustomize|sitecustomize|\.pth$"   # 監査 重大3: 見張り自身・起動の仕掛け・python の乗っ取り先
    r"|LaunchAgents|LaunchDaemons|[\\/]Programs[\\/]Startup[\\/]|[\\/]\.claude[\\/]CLAUDE\.md$|ai-office[\\/]staff[\\/]|ai-office[\\/]handoff|ai-office[\\/]config\.json|ai-office[\\/]local[\\/]"   # 常駐の仕込み先・毎回読まれる指示（中8・中9）
    r"|[\\/]\.(bashrc|zshrc|zprofile|profile|bash_profile)$|Microsoft\.PowerShell_profile|[\\/]\.aws[\\/]|[\\/]\.npmrc$|[\\/]\.pypirc$"
    r"|[\\/]tools[\\/]guard_hook\.py$|[\\/]tools[\\/]__pycache__[\\/]|[\\/]\.claude\.json$|(^|[\\/])\.mcp\.json$")

# MCP は読み取りと分かる道具だけ記録、ほかは ✅（監査 M-5）。名前のどこかに書き込み系の語があれば、読み取りの頭でも ✅（再監査）
MCP_READ_RE = re.compile(r"(?i)^(get|list|read|search|fetch|query|find|view|describe|lookup|count|check|status|read_me|tabs_context)")
MCP_WRITE_SUB_RE = re.compile(r"(?i)(?:(create|delete|remove|archive|disable|invite)(?!d(?![a-z]))|publish(?!ed(?![a-z]))|submit(?!ted(?![a-z]))"   # archived・disabled・deleted は状態＝読み取り
                              r"|terminate|replace|upload|rename|execute|insert|transfer|purchase|modify|navigate|destroy|erase|wipe|purge"
                              r"|revoke|truncate|flush|overwrite|unsubscribe|reset|clear)")   # 第7監査 E 軸・第8監査 N8-2
MCP_CONNECTOR_RE = re.compile(r"(?i)(and|then|or)")
MCP_WRITE_ANY_RE = re.compile(r"(?i)(create|delete|remove|publish|archive|disable|submit|invite|terminate|replace|upload|rename|execute"
                              r"|insert|transfer|purchase|modify|navigate|destroy|erase|wipe|purge|revoke|truncate|flush|overwrite|reset|clear)")
MCP_READ_NOUNS = {"commit", "reply", "close", "start", "type"}   # get_commit・get_reply_count・get_start_date など（第8監査 N8-1・第9監査で5語に）
MCP_NOUN_TAIL = {"count", "counts", "date", "dates", "time", "times", "id", "ids", "info", "details", "detail", "status",
                 "hash", "sha", "at", "by", "summary"}   # 目的語にもなる語（window・url・log・list・message…）は入れない（第10監査）
MCP_NOUN_HEADS = {"get", "list", "read", "fetch", "describe"}   # 5語を名詞として通すのは、最初の語がちょうどこれで、その直後に5語が来るときだけ（第10監査）   # 第5監査 N5-2・第6監査 N6-3/N6-4
MCP_WRITE_RE = re.compile(r"(?i)(create|delete|remove|update|write|send|post|publish|terminate|kill|replace|set|put|upload|share"
                          r"|move|rename|execute|exec|run|insert|drop|merge|transfer|pay|purchase|invite|edit|modify|add|submit|click|type|navigate"
                          r"|reset|clear|restore|revert|cancel|close|lock|unlock|enable|approve|reject|ban|kick|mute|pin|fork|commit|push|deploy"
                          r"|install|uninstall|import|grant|assign|move|mark|reply|forward|schedule|trigger|start|stop|kill|restart)")
READ_TOOLS = {"Read", "Grep", "Glob", "NotebookRead", "LS"}
QUIET_TOOLS = {"TodoWrite", "TaskOutput", "ToolSearch", "ReadNotifications"}
DISCORD_TOOL_PREFIX = "mcp__plugin_discord_discord__"


def _segments(cmd):
    return [s for s in re.split(r"(?:&&|\|\||[;\n|])", cmd) if s.strip()]


def _forms(seg):
    """同じ操作の書き方ゆれ（引用符・バッククォート・^・\\ の区切り/エスケープ）を全部作る（監査 H-3）"""
    noq = re.sub(r"[\"'`^]", "", seg)
    noext = re.sub(r"(?i)\.(exe|cmd|bat|ps1)(?=\s|$)", "", noq)   # git.exe push・wrangler.cmd deploy（再監査 H-A）
    return {seg, noq, noq.replace("\\", "/"), noq.replace("\\", ""), noext, noext.replace("\\", "/")}


def _hit(rx, seg):
    return any(rx.search(f) for f in _forms(seg))


def _words(seg):
    return re.sub(r"[\"'`^]", "", seg).split()


def _has_redirect(seg):
    for m in re.finditer(r"(?<![0-9&])>{1,2}\s*([^\s&|;]+)", seg):
        if m.group(1).lower() not in ("/dev/null", "$null", "nul", "null"):
            return True
    return False


def _prog(word):
    """実行ファイルの名前（パスと .exe 等を外して小文字）"""
    word = re.sub(r"^[$(`{]+", "", word)   # $(git push)・`git push` の頭（2026-09-30）
    return re.sub(r"(?i)\.(exe|cmd|bat|ps1)$", "", re.split(r"[\\/]", word)[-1]).lower()


GIT_OPT_WITH_VALUE = {"-c", "-C", "--git-dir", "--work-tree", "--namespace", "--exec-path", "--config-env", "--super-prefix"}


def _git_sub(seg):
    """git の副コマンドと残りの語。正規表現を使わず語で数える（再監査 NEW-C3）。git が無ければ (None, [])"""
    w = _words(seg)
    for i, x in enumerate(w):
        if _prog(x) != "git":
            continue
        j = i + 1
        while j < len(w):
            t = w[j]
            if t in GIT_OPT_WITH_VALUE:
                j += 2
            elif t.startswith("-"):
                j += 1
            else:
                return t.rstrip(")`}").lower(), w[j + 1:]
        return "", []
    return None, []


def _git_kind(seg):
    sub, rest = _git_sub(seg)
    if not sub:
        return None
    low = [r.lower() for r in rest]
    if sub == "push":
        if any(r in ("--force", "-f", "--delete", "-d", "--mirror", "--prune") or r.startswith("--force") or r.startswith(":")
               or (":" in r and not r.startswith("http") and "@" not in r) for r in rest):
            return "ask:削除"
        if "--dry-run" in low or "-n" in low:
            return None
        return "ask:外への送信・公開"
    if (sub in ("clean", "rm", "filter-branch", "filter-repo")
            or (sub == "reset" and "--hard" in low)
            or (sub == "checkout" and ("--" in low or "-f" in low or "--force" in low))
            or (sub == "switch" and any(r in ("-f", "--force", "--discard-changes") for r in low))
            or (sub == "restore" and not (("--staged" in low or "-S" in rest) and "--worktree" not in low and "-W" not in rest))
            or (sub == "branch" and any(r in ("-d", "-D", "--delete") for r in rest))
            or (sub == "tag" and any(r in ("-d", "--delete") for r in low))
            or (sub == "stash" and low[:1] in (["drop"], ["clear"]))
            or (sub == "worktree" and low[:1] == ["remove"])
            or (sub == "gc" and any(r.startswith("--prune") for r in low))
            or (sub == "reflog" and low[:1] in (["expire"], ["delete"]))
            or (sub == "update-ref" and "-d" in low)):
        return "ask:削除"
    return None


def _readonly(seg):
    w = _words(seg)
    if not w or _has_redirect(seg):
        return False
    if _prog(w[0]) in READONLY_FIRST:
        return not re.search(r"(?i)\s-(exec|delete|ok)\b", seg)
    sub, _ = _git_sub(seg)
    return _prog(w[0]) == "git" and sub in READONLY_GIT


PS_VALUE_PARAMS = {"-erroraction", "-ea", "-warningaction", "-wa", "-informationaction", "-ia"}   # 値を取るが消す対象ではない
DELETERS = {"rm", "rmdir", "remove-item", "ri", "del", "erase", "rd", "unlink"}
LONE_AMP_RE = re.compile(r"(?<![&>])&(?![&>])")
CD_ANY_RE = re.compile(r"(?i)(^|[\s;&|({`])(cd|pushd|popd|chdir|set-location|push-location|pop-location|sl|source|\.)(\s|$)")   # 単独の &（前を裏で動かして次へ進む）。2>&1・&>・&& は除く


def _in_temp(a, here):
    """a が一時フォルダの中を指すか。相対パスは here（確かな今いる場所）から解き、.. は整理し、
    ジャンクション・リンクは実体に直してから見る（2026-09-30 関所の見直し。以前は .. を含むものを一律に ✅）"""
    if re.search(r"[$`%{}]", a):   # 展開（{a,b} を含む）が入ると実際の場所が分からない
        return False
    a = os.path.expanduser(a).replace("\\", "/")
    m = re.match(r"^/([A-Za-z])/(.*)$", a)   # Git Bash の /c/…
    if m:
        a = m.group(1) + ":/" + m.group(2)
    if a.startswith("/"):
        return a.startswith("/tmp/") and ".." not in a   # Git Bash の /tmp（従来どおり）
    if re.match(r"^[A-Za-z]:(?!/)", a):   # C:x（ドライブごとの今いる場所）は解けない
        return False
    if not re.match(r"^[A-Za-z]:/", a):
        if not here:
            return False
        a = os.path.join(here, a)
    p = os.path.normpath(a)
    try:
        head, tail = p, []
        while head and not os.path.exists(head) and os.path.dirname(head) != head:
            head, t = os.path.dirname(head), os.path.basename(head)
            tail.insert(0, t)
        p = os.path.join(os.path.realpath(head), *tail)
    except Exception:
        return False
    return bool(TEMP_RE.search(p) or TEMP_RE.search(p.replace("\\", "/")))


def _delete_all_temp(seg, here=None):
    """削除の対象が「全部」一時フォルダのときだけ免除（監査 H-3）。
    .. を含むもの・相対パスは、here（確かな今いる場所）から解いて一時フォルダの中に収まるときだけ免除（2026-09-30）"""
    w = _words(seg)
    if not w or _prog(w[0]) not in DELETERS or LONE_AMP_RE.search(seg):   # 消す道具が先頭のときだけ（xargs rm・sudo rm・x & rm は免除しない）
        return False
    args, skip = [], False
    for x in w[1:]:
        if skip:
            skip = False
            continue
        if x.lower() in PS_VALUE_PARAMS:
            skip = True
            continue
        if x.startswith("-") or re.fullmatch(r"/[A-Za-z]", x):   # -rf や cmd の /s /q は除く
            continue
        args.extend(p for p in x.split(",") if p)   # PowerShell の "a","b"（引用符を外すと a,b）は1つずつ見る
    return bool(args) and all(_in_temp(a, here) for a in args)


PKG_RUNNERS = {"npm", "pnpm", "yarn", "bun"}
PKG_BUILTINS = {"install", "i", "ci", "add", "remove", "uninstall", "update", "exec", "x", "dlx", "init", "create",
                "test", "t", "ls", "list", "outdated", "audit", "why", "view", "info", "config", "cache", "link", "pack", "version"}


SCRIPT_RUNNERS = {"python", "python3", "py", "node", "bash", "sh", "zsh", "dash", "pwsh", "powershell", "perl", "ruby", "php", "deno", "bun", "npx"}
SCRIPT_MAX = 256 * 1024


def _script_body(seg, cwd):
    """python X.py / bash X.sh / powershell -File X.ps1 … で実行するファイルの中身（B5④a: Write→実行 の回り込みを見る）。無ければ None"""
    w = _words(seg)
    if not w:
        return None
    rest, path = w[1:], None
    if _prog(w[0]) not in SCRIPT_RUNNERS:
        if re.search(r"(?i)\.(sh|bash|zsh|py|ps1|bat|cmd|js|rb|pl)$", w[0]):   # ./evil.sh・x.bat の直接実行（中8）
            path = w[0]
        elif _prog(w[0]) == "cmd" and len(w) > 2 and w[1].lower() in ("/c", "/k"):
            path = w[2]
        else:
            return None
    while path is None and rest:
        a = rest[0]
        if a.lower() in ("-file", "-f") and len(rest) > 1:
            path = rest[1]; break
        if a == "-m" and len(rest) > 1:   # python -m mod → mod.py（中8）
            path = rest[1].replace(".", os.sep) + ".py"; break
        if a in ("-c", "-e", "-command", "-Command", "--eval", "-p") :
            return None   # 中身はコマンド文字列に直接ある（regex が見る）
        if a.startswith("-"):
            rest = rest[1:]; continue
        path = a; break
    if not path:
        return None
    try:
        q = os.path.expanduser(path.strip("'\""))
        if not os.path.isabs(q):
            q = os.path.join(cwd or os.getcwd(), q)
        if not os.path.isfile(q) or os.path.getsize(q) > SCRIPT_MAX:
            return None
        qn = os.path.normcase(os.path.realpath(q))
        if qn.startswith(os.path.normcase(os.path.realpath(os.path.join(HOME, ".claude", "skills", "discord-ai-office")))):
            return None   # キット自身のスクリプト（office.py 等）は Edit/Write が禁止された場所にあり、コマンドの引数側で判定する
        with open(q, "rb") as f:
            return f.read().decode("utf-8", "replace")   # 全文（256KB まで）。判定側で2万字ずつに分けて見る（エル②: 先頭だけだと後ろに置かれる）
    except Exception:
        return None


def _pkg_script(seg, cwd):
    """npm run X / pnpm X / yarn X の中身（pre/post を含む）。無ければ None（第4監査 N4-5: スクリプト経由の公開を見る）"""
    w = _words(seg)
    if not w or _prog(w[0]) not in PKG_RUNNERS or len(w) < 2:
        return None
    rest = w[1:]
    base = cwd or os.getcwd()
    while rest and rest[0].startswith("-"):   # --prefix dir / -C dir / --cwd dir
        if rest[0] in ("--prefix", "-C", "--cwd", "--dir") and len(rest) > 1:
            base = os.path.join(base, os.path.expanduser(rest[1]))
            rest = rest[2:]
        else:
            rest = rest[1:]
    if not rest:
        return None
    if rest[0] in ("run", "run-script"):
        rest = rest[1:]
    elif rest[0] in PKG_BUILTINS:
        return None
    if not rest:
        return None
    name = rest[0]
    try:
        with open(os.path.join(base, "package.json"), encoding="utf-8-sig") as f:
            scripts = json.load(f).get("scripts") or {}
    except Exception:
        return None
    parts = [scripts.get(k) for k in ("pre" + name, name, "post" + name)]
    return " && ".join(p for p in parts if isinstance(p, str)) or None


SCRIPT_NAME_RE = re.compile(r"(?i)(deploy|publish|release)[\w.-]{0,60}\.(sh|ps1|cmd|bat|py|mjs|js|ts)$")
INTERPRETERS = {"bash", "sh", "zsh", "pwsh", "powershell", "python", "python3", "py", "node", "bun", "deno", "tsx", "ts-node", "cmd", "call", "&", "."}


WRAPPERS = {"sudo", "env", "nice", "time", "nohup", "exec", "command", "start", "call", "xargs", "timeout", "stdbuf", "caffeinate"}


GIT_REFS = {"HEAD", "ORIG_HEAD", "FETCH_HEAD", "MERGE_HEAD", "@"}


def _tilde_suspect(seg):
    """~ の直後が数字・展開・引用符（HEAD~1 などの版の指定は除く）"""
    for f in _forms(seg) | {seg}:
        for m in TILDE_SUSPECT_RE.finditer(f):
            before = re.search(r"[A-Za-z0-9_]*$", f[:m.start()]).group(0)
            if before.upper() in GIT_REFS:
                continue
            if m.start() > 0 and f[m.start() - 1] in "*?" and not re.match(r"~\d", f[m.start():]):   # '*~' は編集の控えファイルのワイルドカード
                continue
            return True
    return False


def _runs_publish_script(seg):
    """deploy.sh などを「実行する」形だけ（cat deploy.sh・git diff release.py は通す・第5監査 N5-3）。
    前に付く sudo・env・VAR=x・nice・time・( などは外して見る（第6監査 N6-2）"""
    w = [x.strip("()") for x in _words(seg)]
    while w and (_prog(w[0]) in WRAPPERS or re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", w[0]) or w[0] in ("", "(")
                 or (w[0].startswith("-") and len(w) > 1) or re.fullmatch(r"\d+[smhd]?", w[0])):
        w = w[1:]
    if not w:
        return False
    if SCRIPT_NAME_RE.search(re.split(r"[\\/]", w[0])[-1]):
        return True
    if _prog(w[0]) in INTERPRETERS:
        return any(SCRIPT_NAME_RE.search(re.split(r"[\\/]", x)[-1]) for x in w[1:] if not x.startswith("-"))
    return False


FILE_HEREDOC_RE = re.compile(
    r"^(?P<head>[^\n]*?(?:&&|;|^)[ \t]*cat[ \t]*>{1,2}[ \t]*(?P<f>\"[^\"\n]+\"|'[^'\n]+'|[^\s<>|;&]+)[ \t]*<<(?P<dash>-?)[ \t]*"
    r"(?P<q>['\"])(?P<tag>[A-Za-z_][A-Za-z0-9_]*)(?P=q)[ \t]*)\n(?P<body>.*?)\n(?P<end>\t*(?P=tag)[ \t]*)(?=\n|$)", re.M | re.S)


def _strip_file_heredocs(cmd):
    """cat > ファイル <<'EOF' … EOF（引用符つき＝中で展開も実行も起きない）の中身は「書き込む文字」なので判定から外す。
    書いたファイルを同じコマンドの中で使う（実行する）ときは外さない（2026-09-30 関所の見直し）"""
    out, pos = [], 0
    for m in FILE_HEREDOC_RE.finditer(cmd):
        name = re.split(r"[\\/]", m.group("f").strip("\"'"))[-1]
        rest = cmd[:m.start()] + m.group("head") + cmd[m.end():]
        if not name or rest.count(name) > 1 or re.search(r"[*?\[]", cmd[m.end():]):   # ヘッダー以外にも名前が出る＝このあと使う／あとにワイルドカード（bash *.sh で実行できる・監査 v0930 L-1）
            continue
        out.append(cmd[pos:m.start()] + m.group("head") + "\n" + m.group("end"))
        pos = m.end()
    return "".join(out) + cmd[pos:] if out else cmd


def _segments_sep(cmd):
    """区切りごとの (部分, 直後の区切り)"""
    parts = re.split(r"(&&|\|\||[;\n|])", cmd)
    return [(parts[i], parts[i + 1] if i + 1 < len(parts) else "") for i in range(0, len(parts), 2) if parts[i].strip()]


def _cd_target(seg, here):
    """cd X / Set-Location X の行き先。確かに移れると言えないとき（展開・裏で動かす・存在しない）は None"""
    w = _words(seg)
    if w and _prog(w[0]) in ("set-location", "sl") and len(w) == 3 and w[1].lower() in ("-path", "-literalpath"):
        w = [w[0], w[2]]
    if len(w) != 2 or not here or re.search(r"[$`%{}]", w[1]) or w[1] == "-" or LONE_AMP_RE.search(seg):
        return None
    a = os.path.expanduser(w[1]).replace("\\", "/")
    m = re.match(r"^/([A-Za-z])/(.*)$", a)
    if m:
        a = m.group(1) + ":/" + m.group(2)
    if a.startswith("/") or re.match(r"^[A-Za-z]:(?!/)", a):
        return None
    p = os.path.normpath(os.path.join(here, a))
    return p if os.path.isdir(p) else None


def _classify_command(cmd, cwd=None, depth=0):
    if len(cmd) > 20000:
        return "ask:長すぎるコマンド", cmd
    if has_secret_value(cmd):   # B5②: 値を素で書いたコマンド（curl -H "Authorization: Bot xxx" など）は確認にも出せないので止める
        return "deny:秘密の値を書いたコマンド", cmd
    full, cmd = cmd, _strip_file_heredocs(cmd)
    if _hit(OPAQUE_RE, cmd):
        return "ask:中身が読めない実行", full
    here = cwd
    sure = cwd if cwd and os.path.isdir(cwd) else None   # 相対パスの削除を解くのに使う「確かな今いる場所」
    for seg, sep in _segments_sep(cmd):
        first = _prog((_words(seg) or [""])[0])
        if first in ("cd", "set-location", "pushd", "sl") and len(_words(seg)) > 1:   # cd X && npm run deploy の X を追う
            try:
                here = os.path.normpath(os.path.join(here or os.getcwd(), os.path.expanduser(_words(seg)[1])))
            except Exception:
                pass
            # 削除の判定に使うのは、次へ確実に進む区切り（&& ; 改行）で、|| を含まないコマンドの、素の cd のときだけ（(cd x) は元に戻る）
            exact = _words(seg)[0].lower() in ("cd", "set-location", "sl", "pushd")
            sure = _cd_target(seg, sure) if exact and sep in ("&&", ";", "\n") and "||" not in cmd else None
        elif CD_ANY_RE.search(seg):   # 追えない場所の移動（{ cd x; }・popd・source など）があれば、以後の相対パスは解かない
            sure = None
        if depth < 4:
            body = _pkg_script(seg, here)
            if body:
                k, _ = _classify_command(body, here, depth + 1)
                if k and k.startswith("ask:"):
                    return k + "（スクリプトの中身）", full + "\n  ↳ " + body[:300]
            body = _script_body(seg, here)
            if body:
                if has_secret_value(body):
                    return "deny:秘密の値を書いたコマンド", full + "\n  ↳ （スクリプトの中に秘密の値）"
                for off in range(0, len(body), 19000):   # 全文を2万字未満ずつ（「長すぎるコマンド」に倒さず、後ろに置いた処理も見る）
                    k, _ = _classify_command(body[off:off + 19000], here, depth + 1)
                    if k and (k.startswith("ask:") or k.startswith("deny:")):
                        return k + ("" if "（スクリプトの中身）" in k else "（スクリプトの中身）"), full + "\n  ↳ " + body[off:off + 300]
        if ENV_TOKEN_RE.search(seg):   # echo $env:DISCORD_BOT_TOKEN のように、環境変数に入れたトークンを表示させる（B5①）
            return "ask:秘密の読み出し", full
        if first in ECHO_FIRST and not _has_redirect(seg) and not LONE_AMP_RE.search(seg) and not re.search(r"\$\(|`", seg):   # echo x & git push・echo $(git push) は echo 扱いにしない（2026-09-30）
            continue
        if _hit(SECRET_RE, seg):
            return "ask:秘密の読み出し", full
        if (_hit(SHORT_PATH_TOKEN_RE, seg) if first == "git" else (_hit(SHORT_CMD_RE, seg) or _tilde_suspect(seg))):   # 第5監査 N5-1: 生の文字列だけでなく _forms で   # git の main~2 は版の指定・パスの形の短縮名は見る（N4-2）
            return "ask:短縮名のパス", full
        if _hit(AGENT_RE, PROC_QUERY_RE.sub(" ", seg)):
            return "ask:別の AI の起動", full
        if not _readonly(seg) and _hit(CONFIG_RE, seg):
            return "ask:設定・見張りの変更", full
        if _hit(SKILL_TOUCH_RE, seg) and (_has_redirect(seg) or first in WRITE_PROGS or WRITE_API_RE.search(seg)):   # 見張り・起動の仕掛けを書き換える（読むだけ・実行は通す）
            return "ask:設定・見張りの変更", full
        if _runs_publish_script(seg):
            return "ask:外への送信・公開", full
        g = _git_kind(seg)
        if g:
            return g, full
        if _hit(PUBLISH_RE, seg) and not (re.search(r"(?i)\bwrangler\b", seg) and re.search(r"\s--dry-run\b", seg)):   # wrangler の試し（--dry-run）は外に出ない
            return "ask:外への送信・公開", full
        if _hit(DELETE_OTHER_RE, seg):
            return "ask:削除", full
        if _hit(DELETE_WORD_RE, seg) and not _delete_all_temp(seg, sure):
            return "ask:削除", full
    return "log", full


def _long_path(p):
    """8.3 の短い名前・ジャンクションを実際の長いパスに（Windows のみ・無ければそのまま）"""
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(32768)
        n = ctypes.windll.kernel32.GetLongPathNameW(p, buf, 32768)
        if n:
            p = buf.value
    except Exception:
        pass
    try:
        return os.path.realpath(p)
    except Exception:
        return p


def _path_forms(v, cwd):
    """判定に使うパスの形: そのまま・絶対・長い名前に直した実パス"""
    out = {v.rstrip("/\\"), v.rstrip("/\\").replace("\\", "/")}
    try:
        a = os.path.expanduser(v)
        if not os.path.isabs(a):
            a = os.path.join(cwd or os.getcwd(), a)
        a = os.path.normpath(a)
        # 存在する一番深い親までを長い名前にして、残りを付け直す（ワイルドカード入りの Glob にも効くように）
        head, tail = a, []
        while head and not os.path.exists(head) and os.path.dirname(head) != head:
            head, t = os.path.dirname(head), os.path.basename(head)
            tail.insert(0, t)
        full = os.path.join(_long_path(head), *tail) if head else a
        out |= {a, full, full.replace("\\", "/")}
    except Exception:
        pass
    return out


def _covers_secret(p):
    """p（フォルダ）が秘密の置き場を含むか・p 自体が置き場の中か"""
    n = os.path.normcase(os.path.normpath(p)).rstrip("\\/")
    for s in SECRET_LOCATIONS:
        if s == n or s.startswith(n + os.sep) or n.startswith(s + os.sep):
            return True
    return False


def _classify_read(tool, ti, cwd):
    keys = {"Read": ("file_path",), "NotebookRead": ("notebook_path",), "Grep": ("path", "glob"),
            "Glob": ("path", "pattern"), "LS": ("path",)}.get(tool, ())
    vals = [ti.get(k) for k in keys if isinstance(ti.get(k), str) and ti.get(k)]
    if tool in ("Grep", "Glob", "LS") and not ti.get("path"):
        vals.append(cwd or os.getcwd())
    for v in vals:
        if SHORT_NAME_RE.search(v):
            return "deny:秘密の読み出し", "%s %s（短縮名）" % (tool, v)
        forms = _path_forms(v, cwd)
        if any(SECRET_PATH_RE.search(f) for f in forms):
            return "deny:秘密の読み出し", "%s %s" % (tool, v)
        if tool == "Grep":   # 中身を読むのは Grep だけ。Glob/LS は名前の一覧なので広いフォルダでも通す（第3監査の誤爆）
            base = re.split(r"[*?\[{]", v, 1)[0] if tool == "Glob" or "*" in v else v
            if any(_covers_secret(f) for f in _path_forms(base or ".", cwd) if os.path.isabs(f)):
                return "deny:秘密の読み出し", "%s %s（秘密の置き場を含むフォルダ）" % (tool, v)
    return None, ""


def classify(tool, ti, cwd=None):
    """(区分, 説明) を返す。区分: None=記録しない / "log"=記録だけ / "ask:<種類>"=✅ を求める / "deny:<種類>"=拒否"""
    if not isinstance(ti, dict):
        ti = {}
    if tool in QUIET_TOOLS:
        return None, ""
    if tool in READ_TOOLS:
        return _classify_read(tool, ti, cwd)   # Grep の pattern（検索語）は見ない（再監査の誤爆）
    if tool.startswith(DISCORD_TOOL_PREFIX):
        for key in ("text", "content", "message", "question"):   # B5②: 返事にトークン・パスワードらしき値がそのまま入っていたら ✅ なしで止める
            if has_secret_value(ti.get(key)):
                return "deny:秘密の返事", "%s（トークン・パスワードらしき値を含む返事）" % tool.split("__")[-1]
        files = ti.get("files") or []
        if isinstance(files, str):
            files = [files]
        for f in files:
            if isinstance(f, str) and (SHORT_NAME_RE.search(f) or _hit(SECRET_RE, f) or any(SECRET_PATH_RE.search(x) for x in _path_forms(f, cwd))):
                return "deny:秘密の添付", "%s %s" % (tool, f)
            if isinstance(f, str) and _attachment_has_secret(f, cwd):   # B5④c: 文字ファイルの中身にトークン・パスワードらしき値
                return "deny:秘密の添付", "%s %s（中身に秘密の値）" % (tool, f)
        if files:
            return "log", "%s 添付 %s" % (tool.split("__")[-1], ", ".join(str(f) for f in files))
        return None, ""   # ふつうの返事は記録しない（件数が埋もれる）
    if tool in ("Bash", "PowerShell"):
        return _classify_command(ti.get("command") or "", cwd)
    if tool in ("Write", "Edit", "MultiEdit", "NotebookEdit"):
        # 第14監査 L14-1: 道具が実際に使う鍵がどちらでも、入力にある宛先は全部照合する
        paths = [v for v in (ti.get("file_path"), ti.get("notebook_path")) if isinstance(v, str) and v]
        p = " / ".join(paths)
        for q in paths:
            # 第13監査 N13-1: 宛先も長い名前・実パスに直してから照合（新しいファイルは存在する親フォルダまで直す）。短い名前の形は ✅ に倒す
            forms = _path_forms(q, cwd)
            if SHORT_NAME_RE.search(q) or any(WRITE_GUARD_RE.search(f) or WRITE_GUARD_RE.search(f.replace("\\", "/")) for f in forms | {q}):
                return "ask:設定・見張りの変更", "%s %s" % (tool, p)
        if has_secret_value(ti.get("content")) or has_secret_value(ti.get("new_string")):   # B5④b: 秘密の値をファイルに書かせない（書いて添付・公開する経路）
            return "deny:秘密の書き込み", "%s %s（トークン・パスワードらしき値を含む中身）" % (tool, p)
        roots = _work_roots()   # B5③: 作業フォルダ限定（起動が AIOFFICE_WORK_ROOTS を渡したときだけ）
        if roots:
            for q in paths:
                if not _under_roots(q, cwd, roots):
                    return "ask:作業フォルダの外への書き込み", "%s %s" % (tool, p)
        return "log", "%s %s" % (tool, p)
    if tool in ("WebFetch", "WebSearch"):
        return "log", "%s %s" % (tool, ti.get("url") or ti.get("query") or "")
    if tool.startswith("mcp__"):
        short = tool.split("__", 2)[2] if tool.count("__") >= 2 else tool.split("__")[-1]   # __ 入りの道具名も全体を見る（第11監査）
        words = re.split(r"[_\-\s.]+", re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", short))   # camelCase も語に割る（N4-3）
        joined = any(MCP_CONNECTOR_RE.fullmatch(w) for w in words if w) or bool(re.search(r"(?i)(get|list|read|fetch|find|search|query|view|check|lookup|describe|count|status)(and|then|or)[a-z]", short))
        ws = [w for w in words if w]
        noun_ok = lambda i, w: (w.lower() in MCP_READ_NOUNS and i == 1 and ws[0].lower() in MCP_NOUN_HEADS
                                and ((i == len(ws) - 1 and ws[0].lower() in ("get", "describe"))
                                     or (i < len(ws) - 1 and ws[i + 1].lower() in MCP_NOUN_TAIL
                                         and not (ws[0].lower() in ("list", "read", "fetch") and ws[i + 1].lower() in ("at", "by")))))   # 第11・第12監査
        write_words = [w for i, w in enumerate(ws) if MCP_WRITE_RE.fullmatch(w) and (joined or not noun_ok(i, w))]   # 第9・第10監査: 頭と位置を見る
        if joined and MCP_WRITE_ANY_RE.search(short):   # つなぎ語があれば過去分詞の除外もしない（get_and_deleted）
            write_words.append("*")
        if MCP_READ_RE.search(short) and not MCP_WRITE_SUB_RE.search(short) and not write_words:   # 第8監査 N8-1: 名詞として読む語だけ個別に通す   # 語ごとに見る（list_skills・get_settings の誤爆）
            return "log", tool
        return "ask:外部の道具", "%s %s" % (tool, json.dumps(ti, ensure_ascii=False))
    return "log", tool


ATTACH_MAX = 2 * 1024 * 1024


def _attachment_has_secret(f, cwd):
    """添付が文字ファイル（2MB 以下・UTF-8 として読める）なら中身に秘密の値が無いか見る。読めなければ False（画像など）"""
    try:
        q = os.path.expanduser(f)
        if not os.path.isabs(q):
            q = os.path.join(cwd or os.getcwd(), q)
        if not os.path.isfile(q) or os.path.getsize(q) > ATTACH_MAX:
            return False
        with open(q, "rb") as fh:
            raw = fh.read()
        if b"\x00" in raw[:4096]:
            return False
        return has_secret_value(raw.decode("utf-8", "replace"))
    except Exception:
        return False


def _work_roots():
    """作業フォルダ限定のとき、書いてよい場所。起動スクリプトが渡す AIOFFICE_WORK_ROOTS（~/ai-office-data・机の上の AIオフィス・起動フォルダ）＋開発部屋の作業フォルダ・メモリ"""
    v = os.environ.get("AIOFFICE_WORK_ROOTS") or ""
    roots = [os.path.normcase(os.path.normpath(os.path.expanduser(x))) for x in v.split(os.pathsep) if x.strip()]
    if not roots:
        return []
    for s in (_load(STAFF_FILE, {}).get("staff") or []):
        for k in ("project", "memory", "dir", "workdir"):
            if isinstance(s.get(k), str) and s[k]:
                roots.append(os.path.normcase(os.path.normpath(os.path.expanduser(s[k]))))
    return roots


def _under_roots(q, cwd, roots):
    if TEMP_RE.search(q) or TEMP_RE.search(q.replace("\\", "/")):
        return True
    for f in _path_forms(q, cwd):
        n = os.path.normcase(os.path.normpath(f))
        if any(n == r or n.startswith(r + os.sep) or n.startswith(r + "/") for r in roots):
            return True
    return False


def _project_guard_blocks(tool, ti):
    """プロジェクトの guard_hook が無条件で止めるもの。書き換え可能な tools/ ではなく、
    守られたこのフォルダの写し（project_guard_snapshot.py）を使う（監査 C-2）"""
    if tool not in ("Bash", "PowerShell"):
        return False
    try:
        sys.path.insert(0, HERE)
        import project_guard_snapshot  # type: ignore
        return bool(project_guard_snapshot._blocked_reason(ti.get("command") or ""))
    except Exception:
        return False


# ---------------------------------------------------------------- 伏せ字

REDACT_RES = [
    (re.compile(r"(?i)(authorization:\s*(bot|bearer|basic)\s+)\S+"), r"\1[伏せ字]"),
    (re.compile(r"(?i)((token|secret|password|passwd|api[_-]?key|access[_-]?key)[\"']?\s*[:=]\s*[\"']?)[^\s\"'&]+"), r"\1[伏せ字]"),
    (re.compile(r"[A-Za-z0-9_\-]{24,}\.[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{20,}"), "[伏せ字]"),      # Discord トークン形
    (re.compile(r"(?i)\b(sk|pk|rk|ghp|gho|github_pat|xox[abp])[-_][A-Za-z0-9_\-]{16,}"), "[伏せ字]"),
    (re.compile(r"\b[A-Fa-f0-9]{40,}\b"), "[伏せ字]"),
]
SECRET_VALUE_RES = REDACT_RES[:4]   # 「値の形がはっきりしている」ものだけ（40桁の16進＝git の SHA は除く）。返事・コマンドに素で書かれていたら止める（B5②）


def has_secret_value(s):
    """トークン・パスワードらしき値が素で書かれているか。$TOKEN・%X%・${...} のような変数の参照や短い仮の値は数えない"""
    if not isinstance(s, str):
        return False
    for r, _ in SECRET_VALUE_RES[:2]:   # 「Authorization: Bot 値」「token=値」は値の中身を見る
        for m in r.finditer(s):
            v = m.group(0)[len(m.group(1)):]
            if len(v) >= 8 and not v.startswith(("$", "%", "{", "(", "<", "[")) and not re.fullmatch(r"(?i)[x*.…_-]+|\[伏せ字\]|your[_-]?token|secret|password|placeholder", v):
                return True
    return any(r.search(s) for r, _ in SECRET_VALUE_RES[2:])   # Discord トークンの形・ghp_/sk- などの決まった頭


def redact(s):
    for rx, rep in REDACT_RES:
        s = rx.sub(rep, s)
    return s


# ---------------------------------------------------------------- 記録

def now_jst():
    return datetime.datetime.now(JST)


def log(rec):
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        rec = dict(rec, t=now_jst().isoformat(timespec="seconds"))
        with open(LOG_FILE, "a", encoding="utf-8", errors="backslashreplace") as f:   # サロゲート文字でも記録を落とさない（N4-8）
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


# ---------------------------------------------------------------- Discord

def _token():
    try:
        with open(TOKEN_FILE, encoding="utf-8") as f:
            for line in f:
                if line.startswith("DISCORD_BOT_TOKEN="):
                    v = line.split("=", 1)[1].strip().strip('"')
                    if v:
                        return v
    except OSError:
        pass
    v = os.environ.get("DISCORD_BOT_TOKEN", "").strip()   # 起動スクリプトが保存庫から復号して渡す（B5①）
    if v:
        return v
    import subprocess
    try:   # 保存庫から直接（フックは別プロセスなので env が無いこともある）
        if os.name == "nt":
            p = os.path.join(HOME, ".claude", "ai-office", "token.dpapi")
            if os.path.exists(p):
                r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                                    "Add-Type -AssemblyName System.Security; $b=[IO.File]::ReadAllBytes('%s'); [Console]::Out.Write([Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect($b,$null,'CurrentUser')))" % p.replace("'", "''")],
                                   capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
                if r.returncode == 0 and r.stdout.strip():
                    return r.stdout.strip()
        else:
            r = subprocess.run(["security", "find-generic-password", "-s", "ai-office-discord", "-w"], capture_output=True, text=True, timeout=30)
            if r.returncode == 0 and r.stdout.strip():
                return r.stdout.strip()
    except Exception:
        pass
    raise RuntimeError("bot トークンが見つからない")


def api(method, path, data=None, token=None, tries=3, timeout=10):
    import urllib.error
    import urllib.request   # ここで読む（ふだんの操作の判定を軽くするため）
    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(API + path, data=body, method=method, headers={
        "Authorization": "Bot " + (token or _token()), "Content-Type": "application/json", "User-Agent": UA})
    for _ in range(tries):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                b = r.read().decode("utf-8")
                return json.loads(b) if b else {}
        except urllib.error.HTTPError as e:
            b = e.read().decode("utf-8", "replace")
            if e.code == 429:
                try:
                    wait = float(json.loads(b).get("retry_after", 1))
                except Exception:
                    wait = 1.5
                time.sleep(min(wait + 0.3, 3))   # 上限つき（監査 M-1）
                continue
            raise RuntimeError("Discord API %s -> HTTP %s" % (method, e.code))
    raise RuntimeError("Discord API: 混雑で送れない")


def _load(p, default):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def owner_ids():
    acc = _load(ACCESS_FILE, {})
    return {str(x) for x in (acc.get("allowFrom") or []) if str(x).isdigit()}


def hq_room():
    try:   # v1001: 部屋の表が壊れていても落とさない（落ちると「関所が動かなかった」という分かりにくい中止になるため。None なら「確認を出せず中止」に倒れる）
        for s in (_load(STAFF_FILE, {}).get("staff") or []):
            if isinstance(s, dict) and s.get("name") == "統括" and s.get("room_id"):
                return str(s["room_id"])
    except Exception:
        pass
    return None


def room_from_transcript(path):
    """最後に指示が来た部屋。利用者の発言（文字列の本文）の <channel …> だけを見る。
    ツールの結果（取り込んだ Web ページ等）の中の chat_id は見ない（監査 M-6）"""
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 1_500_000))
            lines = f.read().decode("utf-8", "replace").splitlines()
        groups = _load(ACCESS_FILE, {}).get("groups") or {}
        for line in reversed(lines):
            try:
                d = json.loads(line)
            except Exception:
                continue
            if d.get("type") != "user":
                continue
            c = (d.get("message") or {}).get("content")
            texts = [c] if isinstance(c, str) else [x.get("text", "") for x in (c or []) if isinstance(x, dict) and x.get("type") == "text"]
            for t in texts:
                m = re.match(r'\s*<channel source="plugin:discord[^"]*" chat_id="(\d{15,21})"', t or "")
                if m and m.group(1) in groups:
                    return m.group(1)
    except Exception:
        return None
    return None


def _quote(x):
    import urllib.parse
    return urllib.parse.quote(x)


def _reactors(token, room, mid, emoji):
    users = api("GET", "/channels/%s/messages/%s/reactions/%s?limit=100" % (room, mid, _quote(emoji)),
                token=token, tries=1, timeout=5)
    return {str(u.get("id")) for u in users if isinstance(u, dict)}


TOOL_PLAIN = {"Write": "ファイルを新しく書く（または丸ごと書き換える）", "Edit": "ファイルの一部を書き換える",
              "NotebookEdit": "ノートブックを書き換える", "WebFetch": "Web のページを読む"}


def plain_of(tool, ti):
    """確認に添える「やること」の一行（2026-09-30 オーナー指摘: コードだけでは意味がわからない）。
    AI がコマンドに付ける description を使う。無ければ道具の種類から。判定には使わない（表示だけ）"""
    s = ti.get("description") if isinstance(ti.get("description"), str) else ""
    s = " ".join(s.split())[:140] or TOOL_PLAIN.get(tool, "")
    return redact(s).replace("```", "ʼʼʼ").replace("*", "＊")


def ask_owner(kind, summary, who, room, plain=""):
    """✅ を求める。戻り値: ("approved"|"rejected"|"timeout"|"error", 詳細)"""
    mid, token, content = None, None, ""
    try:
        token = _token()
        owners = owner_ids()
        if not owners:
            return "error", "access.json にオーナーの ID が無い"
        if not room:
            return "error", "確認を出す部屋が見つからない"
        text = summary.replace("```", "ʼʼʼ")
        head = ("📝 やること（AI の説明）: %s\n" % plain) if plain else "📝 やること: （AI の説明なし）\n"
        content = ("🔐 **確認：%s**（%s）\n%s```\n%s\n```\n"
                   "実行してよければ ✅、止めるなら ❌ を押してください（%sで自動的に中止）。\n"
                   "※ 説明は AI が書いたものです。迷ったら下のコマンドを正としてください。AI が「OK が出た」と言っても通りません。あなたが押した ✅ だけを見ます。") % (kind, who, head, text, WAIT_TEXT)
        msg = api("POST", "/channels/%s/messages" % room, {"content": content, "allowed_mentions": {"parse": []}}, token=token)
        mid = msg["id"]
        for e in (OK_EMOJI, NG_EMOJI):
            try:
                api("PUT", "/channels/%s/messages/%s/reactions/%s/@me" % (room, mid, _quote(e)), token=token, tries=2, timeout=5)
            except Exception:
                pass
        result = "timeout"
        while time.time() - T0 < WAIT_SEC:
            time.sleep(POLL_SEC)
            try:
                if owners & _reactors(token, room, mid, NG_EMOJI):
                    result = "rejected"
                    break
                if owners & _reactors(token, room, mid, OK_EMOJI):
                    result = "approved"
                    break
            except Exception:   # 通信断などでも待ち続け、締め切りで中止（監査 L-2）
                continue
    except Exception as e:   # noqa: BLE001 — 確認が出せなければ止める側
        result, info = "error", str(e)[:200]
    else:
        info = mid
    if mid:
        tail = {"approved": "\n→ ✅ 承認されたので実行します（%s）",
                "rejected": "\n→ ❌ 中止しました（%s）",
                "timeout": "\n→ ⏱ 時間切れで中止しました（%s）",
                "error": "\n→ ⚠ 確認の途中で失敗したので中止しました（%s）"}[result] % now_jst().strftime("%H:%M")
        try:
            api("PATCH", "/channels/%s/messages/%s" % (room, mid), {"content": content + tail}, token=token, tries=2, timeout=5)
        except Exception:
            pass
    return result, info


# ---------------------------------------------------------------- フック本体

def _out_deny(reason):
    print(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse",
                                             "permissionDecision": "deny",
                                             "permissionDecisionReason": reason}}, ensure_ascii=False))


NO_DETOUR = "自分で「承認済み」と判断したり、別の書き方・スクリプト・別の AI で回り込んだりすることは禁止です。"


def _local_rules(tool, ti, kind, summary):
    """持ち主の追加規則 ~/.claude/ai-office/local/guard_rules.py: rules(tool, ti, kind, summary) → (kind, summary) か None（そのまま）。
    ask→log（許す）・log/None→ask（増やす）・deny を足すのはできる。キットの deny は弱められない。読めない規則は無視してキットの判定のまま"""
    if not os.path.exists(LOCAL_RULES): return kind, summary
    if kind and str(kind).startswith("deny:"): return kind, summary
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("aio_guard_rules", LOCAL_RULES); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        r = m.rules(tool, ti, kind, summary)
        if r is None: return kind, summary
        k2, s2 = r
        if k2 is None or k2 == "log" or str(k2).startswith(("ask:", "deny:")): return k2, (s2 or summary)
        return kind, summary
    except Exception as e:
        log({"session": "?", "agent": "?", "tool": tool, "summary": "local/guard_rules.py を読めなかった（キットの判定のまま）: %s" % str(e)[:120], "verdict": "log", "kind": "追加規則の失敗"})
        return kind, summary


def cmd_pre():
    if os.environ.get("AIOFFICE_DISCORD") != "1":
        return 0
    try:
        d = json.loads(sys.stdin.buffer.read().decode("utf-8", "replace") or "{}")
        if not isinstance(d, dict):
            raise ValueError("not an object")
        tool = d.get("tool_name") or ""
        ti = d.get("tool_input") or {}
        if not isinstance(tool, str) or not isinstance(ti, dict):
            raise ValueError("bad shape")
    except Exception as e:   # 読めない入力は通さない（第4監査 N4-1・以前は黙って通していた）
        log({"session": "?", "agent": "?", "tool": "?", "summary": "入力を読めなかった: %s" % str(e)[:120], "verdict": "blocked", "kind": "読めない入力"})
        _out_deny("【見張りの関所】操作の内容を読み取れなかったので、安全のため中止しました。%s" % NO_DETOUR)
        return 0
    kind, summary, pg = _classify_isolated(tool, ti, d.get("cwd"))
    kind, summary = _local_rules(tool, ti, kind, summary)   # 持ち主の追加規則（deny は弱められない）
    if kind is None:
        return 0
    who = d.get("agent_type") or "本体"
    base = {"session": (d.get("session_id") or "")[:8], "agent": who, "tool": tool, "summary": redact(summary[:400])}   # 伏せ字は切ってから（長さの2乗で遅くなるため・第3監査 N3-1）
    if kind == "log":
        log(dict(base, verdict="log"))
        return 0
    verb, k = kind.split(":", 1)
    if verb == "deny":
        log(dict(base, verdict="blocked", kind=k))
        if k.startswith(("秘密の返事", "秘密の値を書いたコマンド", "秘密の書き込み")):
            _out_deny("【見張りの関所・%s】トークン・パスワードらしき値がそのまま入っています。値を書かずに（設定ファイルや環境変数の名前で）やり直してください。%s" % (k, NO_DETOUR))
        elif k == "判定が終わらない":
            _out_deny("【見張りの関所】この操作は判定が %d 秒で終わらなかったので、安全のため中止しました。短く分けてからもう一度実行してください。%s" % (CLS_TIMEOUT, NO_DETOUR))
        else:
            _out_deny("【見張りの関所・%s】Discord 用の Claude は秘密の置き場を読めません（添付も不可・秘密を含むフォルダの検索も不可。フォルダを絞ってください）。必要ならオーナーが PC で扱います。%s" % (k, NO_DETOUR))
        return 0
    if pg:
        log(dict(base, verdict="blocked", kind=k, note="プロジェクトの guard_hook の規則で禁止"))
        _out_deny("【見張りの関所・%s】この操作はオフィスの規則（tools/guard_hook.py）で禁止です。%s" % (k, NO_DETOUR))
        return 0
    if len(summary) > MAX_SHOW or redact(summary) != summary:   # 長いものは or の左で決まり、伏せ字はかからない（N3-1）
        log(dict(base, verdict="blocked", kind=k, note="確認に出せない（長すぎる／秘密らしき値を含む）"))
        _out_deny("【見張りの関所・%s】確認に出すには長すぎるか、トークン・パスワードらしき値がそのまま書かれています。"
                  "オーナーが全文を見て判断できるよう、%d 文字以内で、秘密の値を直接書かない形に分けてから、もう一度実行してください。%s" % (k, MAX_SHOW, NO_DETOUR))
        return 0
    room = room_from_transcript(d.get("transcript_path")) or hq_room()
    result, info = ask_owner(k, summary, who, room, plain_of(tool, ti))
    log(dict(base, verdict=result, kind=k, room=room))
    if result == "approved":
        return 0   # allow は返さない＝ほかの deny 規則はそのまま効く
    reason = {
        "rejected": "オーナーが Discord で ❌ を押したので中止しました。",
        "timeout": "オーナーの ✅ が%s以内に無かったので中止しました。" % WAIT_TEXT,
        "error": "Discord に確認を出せなかったので、安全のため中止しました（%s）。" % info,
    }[result]
    _out_deny("【見張りの関所・%s】%s 実行したいなら、部屋でオーナーに理由を説明し、了解をもらってからもう一度同じ操作をしてください（そのとき改めて ✅ を求めます）。%s" % (k, reason, NO_DETOUR))
    return 0


CLS_TIMEOUT = 20


def _classify_isolated(tool, ti, cwd):
    """判定を別プロセスで動かし、CLS_TIMEOUT 秒で終わらなければ拒否に倒す（再監査 NEW-C3 の保険。
    正規表現の途中では Python のスレッドが割り込めないため、プロセスを分けて打ち切る）"""
    import subprocess
    try:
        r = subprocess.run([sys.executable, os.path.abspath(__file__), "_cls"],
                           input=json.dumps({"tool": tool, "ti": ti, "cwd": cwd}, ensure_ascii=False).encode("utf-8"),
                           capture_output=True, timeout=CLS_TIMEOUT, env=dict(os.environ, PYTHONIOENCODING="utf-8"))
        q = json.loads(r.stdout.decode("utf-8"))
        return q["kind"], q["summary"], q["pg"]
    except Exception:
        return "deny:判定が終わらない", "%s %s" % (tool, json.dumps(ti, ensure_ascii=False)[:300]), False


def _pre_registered():
    """ユーザー設定に guard.py pre が登録されているか（外れていたら報告で知らせる）"""
    s = json.dumps(_load(USER_SETTINGS, {}).get("hooks") or {}, ensure_ascii=False)
    return ("discord-guard/guard.py" in s or "discord-ai-office/guard/guard.py" in s) and " pre" in s   # 原作（momomon）とキット版の両方の名前


def cmd_start():
    if os.environ.get("AIOFFICE_DISCORD") != "1":
        return 0
    try:
        d = json.loads(sys.stdin.buffer.read().decode("utf-8", "replace") or "{}")
    except Exception:
        d = {}
    if d.get("source") not in (None, "startup"):
        return 0
    st = _load(REPORT_STATE, {})
    since, offset = st.get("last") or "", int(st.get("offset") or 0)
    now = now_jst().isoformat(timespec="seconds")
    counts = {"approved": 0, "rejected": 0, "timeout": 0, "error": 0, "blocked": 0}
    total, kinds, end = 0, {}, offset
    try:
        with open(LOG_FILE, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(offset if offset <= size else 0)   # 記録の位置で数える（同じ秒の取りこぼし無し・監査 L-4）
            data = f.read()
            end = f.tell()
        for line in data.decode("utf-8", "replace").splitlines():
            try:
                r = json.loads(line)
            except Exception:
                continue
            total += 1
            v = r.get("verdict")
            if v in counts:
                counts[v] += 1
                kinds[r.get("kind", "?")] = kinds.get(r.get("kind", "?"), 0) + 1
    except FileNotFoundError:
        pass
    danger = sum(counts.values())
    groups = _load(ACCESS_FILE, {}).get("groups") or {}
    open_rooms = [cid for cid, g in groups.items() if not (g or {}).get("allowFrom")]
    period = ("%s 〜 %s" % (since[5:16].replace("T", " "), now[5:16].replace("T", " "))) if since else "記録の始まり 〜 %s" % now[5:16].replace("T", " ")
    lines = ["🛡 **見張りの記録**（%s）" % period,
             "危ない操作 **%d 件**（✅承認 %d・❌中止 %d・⏱時間切れ %d・確認を出せず中止 %d・関所で拒否 %d）" % (
                 danger, counts["approved"], counts["rejected"], counts["timeout"], counts["error"], counts["blocked"]),
             "記録した操作 %d 件（コマンド・書き込み・Web の取得・添付）" % total]
    if kinds:
        lines.append("内訳: " + "・".join("%s %d" % kv for kv in sorted(kinds.items(), key=lambda x: -x[1])))
    if open_rooms:
        lines.append("⚠ 誰でも指示できる部屋があります（許可の表が空）: " + ", ".join("<#%s>" % c for c in open_rooms))
    try:
        import hashlib
        h = lambda f: hashlib.sha256(open(f, "rb").read()).hexdigest()
        if h(os.path.join(HERE, "..", "..", "tools", "guard_hook.py")) != h(os.path.join(HERE, "project_guard_snapshot.py")):
            lines.append("⚠ tools/guard_hook.py が変わっています。PC で ops/discord-guard/project_guard_snapshot.py に写し直してください（見張りは古い規則で判定中）")
    except Exception:
        pass
    if not _pre_registered():
        lines.append("⚠ 関所のフックがユーザー設定から外れています（~/.claude/settings.json の hooks）。いまは記録も確認も効いていません。統括の部屋で「見張りをつけて」と言うと登録し直せます")
    lines.append("※ 件数は関所を通った操作だけです（自作スクリプトの中身などは数えられません）。詳しくは PC の %s" % LOG_FILE.replace(HOME, "~"))
    room = hq_room()
    if not room:
        return 0   # 報告できなければ位置を進めない（監査 M-3）
    try:
        api("POST", "/channels/%s/messages" % room, {"content": "\n".join(lines), "allowed_mentions": {"parse": []}})
    except Exception:
        return 0
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(REPORT_STATE, "w", encoding="utf-8") as f:
            json.dump({"last": now, "offset": end}, f)
    except Exception:
        pass
    return 0


def main(argv):
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass
    if len(argv) >= 2 and argv[1] == "pre":
        return cmd_pre()
    if len(argv) >= 2 and argv[1] == "start":
        return cmd_start()
    if len(argv) >= 2 and argv[1] == "_cls":   # 判定だけを別プロセスで（時間の上限を付けるため）
        q = json.loads(sys.stdin.buffer.read().decode("utf-8"))
        k, s = classify(q["tool"], q["ti"], q.get("cwd"))
        pg = bool(k and k.startswith("ask:") and _project_guard_blocks(q["tool"], q["ti"]))
        sys.stdout.write(json.dumps({"kind": k, "summary": s, "pg": pg}, ensure_ascii=False))
        return 0
    if len(argv) >= 4 and argv[1] == "classify":
        k, s = classify(argv[2], json.loads(argv[3]))
        print(k, "|", redact(s))
        return 0
    print(__doc__)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
