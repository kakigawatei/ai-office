持ち主の置き場 ~/.claude/ai-office/local/ — キットの更新で触りません（自作の改造を守る場所）
作り方: python ~/.claude/skills/discord-ai-office/scripts/office.py local init（このフォルダと例を置く）
有効にする: 例のファイルの「.example」を外す。何が有効かは python …/office.py local status

起動時の指示.txt   … あればデスクトップの「起動時の指示.txt」より優先して使う（キットの更新で上書きされない）
CLAUDE_local.md    … ~/.claude/CLAUDE.md のキットの目印の内側に足す決まり（更新のたび入れ直す・「やめる」で一緒に消える）
office_ext.py      … office.py の命令を足す・差し替える。COMMANDS = {"名前": 関数(args)}（args.rest に残りの引数）／setup(office) でキットの関数を差し替え
guard_rules.py     … 見張りの追加規則。rules(tool, ti, kind, summary) が (kind, summary) を返すと差し替え、None でそのまま
                     kind: None=記録しない／"log"=記録だけ／"ask:種類"=✅ 待ち／"deny:種類"=拒否。キットの deny は弱められません
start_hook.sh / start_hook.ps1 … 起動スクリプトが claude を立ち上げる直前に読む（環境変数など）

注意: この置き場は持ち主の領域＝AI が書くには持ち主の ✅（設定・見張りの変更）が要ります。guard_rules.py と start_hook.* を変えたら python …/office.py guard rehash で合図を取り直す
      （取り直さないと、次の再起動で 🛡⚠️「見張りが変わっている」と統括に出ます）
