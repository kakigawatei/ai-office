---
name: discord-ai-office
description: Use when the user wants to run Claude Code from their phone through Discord with "AI staff" — one Discord room per role (経理／動画／アプリ…), each answered as a different persona; or says 「Discord に部屋を作って」「AI社員を雇って」「新しい担当を増やして」「Discord から指示できるようにして」. Sets up the Discord bot (browser steps for Computer Use / Claude in Chrome), creates the rooms via the Discord API, writes persona files, registers rooms in the Discord plugin's access.json, and installs the operating rules (reply in the same room, copy-paste values alone, 🇦🇧🇨 choices). Built from 株式会社バウ's working setup (2026-07〜09).
---

# discord-ai-office — スマホの Discord から AI 社員に指示する仕組み

「部屋＝社員」。Discord のチャンネルごとに担当（ペルソナ）を置き、上司はスマホでその部屋に書くだけ。
Claude Code の Discord プラグインが全部屋を1つのセッションに橋渡しし、**どの部屋から来たか（chat_id）で人格と正典を切り替える**。

## 0. 構成（3つだけ）
| 部品 | 役割 | 置き場所 |
|---|---|---|
| Discord bot（1つ） | Claude Code の窓口。プラグイン `plugin:discord` が受信・返信 | トークン＝`~/.claude/channels/discord/.env` の `DISCORD_BOT_TOKEN` |
| `access.json` | どの部屋の発言を受けるか（許可） | `~/.claude/channels/discord/access.json` の `groups` |
| 社員台帳＋ペルソナ | 部屋ID → 名前・役割・口調・正典 | `~/.claude/ai-office/staff.json` ＋ `~/.claude/ai-office/staff/<名前>.md` |

Claude Code 側の切替は「メモリ／CLAUDE.md にある対応表を見て、その部屋の人格で答える」だけ（`templates/CLAUDE_snippet.md` を CLAUDE.md に貼る）。

## 1. 初回セットアップ（新しい人が使うとき）
1. **bot を作る（ブラウザ操作＝Computer Use / Claude in Chrome の出番）**: セットアップ（setup_mac.sh / setup_windows.ps1）が `browser/computer_use_setup.txt` を Claude デスクトップアプリに貼らせる。ログイン・2段階認証・最後の「認証」ボタンと、トークンのコピー（1回）だけ人がやる。トークンはターミナルがクリップボードから読む（チャットには出さない）。
2. **プラグインにトークンを入れる**: Claude Code で `/discord:configure`（トークンを貼る）。DM 許可は `/discord:access` で自分のユーザー ID を allowlist に。
3. **起動は必ず** `claude --channels plugin:discord@claude-plugins-official`（無いと受信だけ死ぬ＝片道。MCP ログに `not in --channels list`）。
4. **部屋と社員を作る**: `python scripts/office.py hire "ジョー" "経理・会計" --emoji 🧾 --project "C:\...\uriage-dashboard"` を社員の数だけ。カテゴリ「AIオフィス」を作り、部屋を作り、ペルソナ md を書き、access.json に登録し、部屋に挨拶を投稿する。
5. **CLAUDE.md に貼る**: `templates/CLAUDE_snippet.md` の内容を `~/.claude/CLAUDE.md` に追記（部屋→担当の切替ルールと返事の作法）。
6. **Claude Code を起動し直す**（access.json を読み直す）→ 各部屋に「◯◯、テスト」と書いて返事が来れば完成。

## 2. 社員を増やす（日常）
```
python scripts/office.py hire "さくら" "山形出店担当" --emoji 🌸 --tone "新入社員らしく丁寧、短く" --project "C:\Users\...\yamagata-shutten"
```
→ 部屋「さくら【山形出店担当】」＋ `~/.claude/ai-office/staff/さくら.md` ＋ access.json 登録。上司は次の発言からその部屋で指示できる。

## 2b. 開発部屋・デスクトップアプリからの引き継ぎ（2026-09-27〜）
- `office.py migrate` … 引き継ぎ診断（読むだけ）。~/.claude/skills・CLAUDE.md・~/.claude/projects（会話ログの cwd とメモリ件数）を一覧にし、机の上に「引き継ぎ診断.txt」、~/.claude/ai-office/migrate.json に候補を書く。セットアップの最後にも自動で走り、候補があれば「引き継いで」の案内を出す
- `office.py project "部屋の名前" [--dir <パス|診断の番号>]` … カテゴリ「開発」に部屋を作り、作業フォルダ（無ければ ~/ai-office-dev/<英数字の名前> を作って git init。日本語のフォルダ名はメモリ置き場の名前がぶつかるので使わない）とメモリの置き場を結ぶ。ペルソナは templates/project_room.md
- メモリの置き場は Claude Code と同じ規則: `~/.claude/projects/<git リポジトリの一番上（外ならそのフォルダ）の英数字以外を - にした名前>/memory/`。だからデスクトップアプリで同じフォルダを開くと同じメモリになる。引き継ぎメモは そのメモリの handoff.md（MEMORY.md に索引1行）
- `office.py hire ... --skill <スキル名>` … スキルを社員にする（ペルソナに「この社員の道具」を足す）。`office.py fire "名前"` … 社員を外す（台帳と access.json から外す・部屋とペルソナは残す・統括は不可）
- `office.py watch-replies` … 返事の見張り（5分おき・launchd com.aioffice.watch／タスク AIOffice_ReplyWatch）。人の発言から10分返事が無い部屋に「⚠️ もう一度送って」を1回だけ。🌙予告から15分は黙る。状態 ~/.claude/ai-office/watch_replies.json
- 再起動は「再起動の時刻 = 04:00, 15:00」のように何回でも（会話が大きくなって通信切れ ECONNRESET で返事が出なくなるのを防ぐ・2026-09-28 開発くんで発生）
- 許可の表（access.json）は発言のたびに読み直されるので、部屋を足しても再起動は要らない
- 買った人向けの説明: 机の上の「Discordで開発する使い方.txt」

## 3. 運用の作法（同梱の CLAUDE_snippet が守らせること）
1. 返事は Discord の `reply` ツールで、**指示が来た部屋に**返す。地の文は届かない＝未完了。話題で勝手に別の部屋へ振り替えない。
2. 上司がコピペする値（URL・コマンド・ID・文章案）は、**値だけ・単独メッセージ・コードフェンス無し**。案内は別メッセージ。
3. 選択肢は `office.py ask <部屋ID> "質問" "A" "B" "C"` で 🇦🇧🇨 を出してタップで答えてもらう（`run_in_background` で待つ。押されたら `2\tB` のように標準出力に出る）。
4. 「たぶん」で「できました」と言わない。受け側で見えた所まで確認して報告。10分超の作業は「やること3行」を先に返す。
5. 秘密（トークン・パスワード）は部屋に貼らない。ファイル名は半角英数（添付が開けない事故を防ぐ）。
6. 時刻は UTC で届く → +9h（JST）で話す。

## 4. スクリプト
- `scripts/office.py hire-all --file 社員名簿.txt` … 名簿（名前|役割|絵文字|engine|正典|口調）を一括で雇う。既存は名前でスキップ。最後に `NEW=n`
- `scripts/office.py links [--out <dir>] [--post hq]` … 部屋リンク一覧 links.md/links.html（`discord://discord.com/channels/<guild>/<room>`＝iPhone ショートカット「URLを開く」用）。--post で統括部屋に「名前」→「リンク」を1部屋ずつ投稿
- `scripts/office.py backup [--out <dir>]` … 設定・台帳・ペルソナ・メモリ・スキルを zip（.env／token は入れない・14世代）
- `scripts/office.py notice "本文"` … 統括部屋（config.json の hq_room）へ投稿
- `scripts/start.ps1` / `restart.ps1` / `register_task.ps1` … Desktop\AIオフィス\起動.bat・再起動.bat の本体と 04:00 タスク登録（**.ps1 は UTF-8 BOM 必須**）
- `scripts/office.py whoami` … bot と参加サーバー
- `scripts/office.py setup --guild <ID>` … staff.json の社員ぶんの部屋を一括作成
- `scripts/office.py hire ...` … 社員を1人雇う（部屋・ペルソナ・許可・挨拶）
- `scripts/office.py list` … 社員一覧
- `scripts/office.py say <部屋ID> "本文"` … Claude Code が落ちていても届く投稿（Windows タスクスケジューラのリマインドに）
- `scripts/office.py ask <部屋ID> "質問" "A" "B" ...` … 🇦🇧🇨 で選ばせて結果を返す
- `scripts/office.py model [auto|名前] [--restart]` … モデル切替（スマホから「モデルを変えて」）。引数なしで設定と実物を表示
- `scripts/office.py new-session --file <引き継ぎ書.md>` … 「新しいセッションにして」: handoff.md に置いて再起動（次の起動だけが読む・印は start.* が消す）。`RESTART=started|not_started`
- `scripts/office.py usage [--days 7] [--post]` … 使用量の目安（会話記録の usage を message.id で重複除去して集計・直近5h/7日・最も多かった5時間との比・モデル別・日ごと）。公式の枠％ではない
- `scripts/office.py guard on|off|status [--restart] [--work-only]` … 見張り（関所・上級者向け・原作 momomon）。`guard/guard.py pre` をユーザー settings.json の PreToolUse に登録（AIOFFICE_DISCORD=1 の Claude にだけ効く）・`~/.claude/ai-office/guard/settings.json`（deny＋SessionStart 🛡）を settings= で起動に渡す。危ない操作は統括に 🔐、秘密の置き場・秘密の値を書いた返事/コマンドは ✅ なしで拒否。--work-only で作業フォルダの外への書き込みも 🔐。試験 `guard/test_guard.py`（348件）

## 4b. 机の上（買った人が触る場所）＝ Desktop\AIオフィス起動.bat（道具チェック→トークン→名簿から部屋→リンク一覧→`claude --channels` 起動・二重起動しない）／再起動.bat（🌙予告→停止→backup→claude update→起動→☀️）／社員名簿.txt／起動時の指示.txt（起動直後に Claude へ渡す：引き継ぎを読む・cron を張り直す・03:50 に引き継ぎ書更新 cron・☀️投稿）／更新コマンド.txt／links.html／backups\／logs\。設定は `~/.claude/ai-office/config.json`（guild・hq_room・codex_dir・codex_bridge_autostart）

## 5. 落とし穴（実体験）
- .ps1 に日本語を書くなら UTF-8 BOM を付ける（無いと Windows PowerShell が cp932 で読んで構文エラー）。.bat は BOM 無し＋先頭 `chcp 65001`
- 起動時の `--channels` 忘れ＝受信だけ死ぬ。
- Discord REST の 403 は User-Agent 未設定（`DiscordBot (...)` を付ける・office.py は対応済み）。
- bot 自身の発言はプラグインが捨てる（bot→bot は届かない）。別プロセスから司令塔に渡したい時は Firestore 等の別経路か、上司の部屋に「📨」として投稿してもらう。
- 絵文字投票は「bot 自身が先に置いた分」を除いて数える（office.py ask は投票者の ID で判定）。
- 対応表が古いのに「部屋が無い」と答えない。`GET /guilds/<id>/channels` で実際の部屋を見てから言う。
- 長い処理を `run_in_background` に任せると数十分で殺されることがある → 別プロセス（Start-Process／nohup）へ。

## 6. 売り物にするときの形（案）
- 同梱: このフォルダ一式＋ `README_for_buyers.md`（日本語・スクショ無しでも追える手順）。
- 買った人の作業は「bot を作る（ブラウザ指示文を貼る）→ /discord:configure → hire を打つ → CLAUDE.md に貼る」の4つ。
- 差別化は「部屋＝社員」の設計と、運用の作法（スマホ完結・🇦🇧🇨・値だけ単独）を最初から同梱している点。
