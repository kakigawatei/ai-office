---
name: discord-ai-office
description: Use when the user wants to run Claude Code from their phone through Discord with "AI staff" — one Discord room per role (経理／動画／アプリ…), each answered as a different persona; or says 「Discord に部屋を作って」「AI社員を雇って」「新しい担当を増やして」「Discord から指示できるようにして」. Sets up the Discord bot (browser steps for Computer Use / Claude in Chrome), creates the rooms via the Discord API, writes persona files, registers rooms in the Discord plugin's access.json, and installs the operating rules (reply in the same room, copy-paste values alone, 🇦🇧🇨 choices). Built from 株式会社バウ's working setup (2026-07〜09).
---

# discord-ai-office — スマホの Discord から AI 社員に指示する仕組み

「部屋＝社員」。Discord のチャンネルごとに担当（ペルソナ）を置き、上司はスマホでその部屋に書くだけ。
Claude Code の Discord プラグインが全部屋を1つのセッションに橋渡しし、**どの部屋から来たか（chat_id）で人格と正典を切り替える**。

## 0. 構成（3つだけ）
| 部品 | 役割 | 置き場所 |
|---|---|---|
| Discord bot（1つ） | Claude Code の窓口。プラグイン `plugin:discord` が受信・返信 | トークン＝`~/.claude/channels/discord/.env` の `DISCORD_BOT_TOKEN` |
| `access.json` | どの部屋の発言を受けるか（許可） | `~/.claude/channels/discord/access.json` の `groups` |
| 社員台帳＋ペルソナ | 部屋ID → 名前・役割・口調・正典 | `~/.claude/ai-office/staff.json` ＋ `~/.claude/ai-office/staff/<名前>.md` |

Claude Code 側の切替は「メモリ／CLAUDE.md にある対応表を見て、その部屋の人格で答える」だけ（`templates/CLAUDE_snippet.md` を CLAUDE.md に貼る）。

## 1. 初回セットアップ（買った人の流れ・2026-09-30 の版）
1. **1行インストーラ**: Windows は PowerShell に `irm https://kakigawatei.github.io/ai-office/install.ps1 | iex`、Mac はターミナルに `curl -fsSL https://kakigawatei.github.io/ai-office/install.sh -o /tmp/aioffice_install.sh && bash /tmp/aioffice_install.sh`。キットを `~/ai-office-kit` に展開し、設定シート.txt を開いて Enter 待ち → `setup_windows.ps1` / `setup_mac.sh`
2. **セットアップが自動でやること**: 道具チェック（python・claude・プラグイン部品）→ Claude ログイン → bot 作成の指示文（`browser/computer_use_setup.txt`）をデスクトップアプリに貼らせる（人は Discord のログイン・「認証」ボタン・**トークンを1回コピー**だけ）→ `.env` に保存（Win は icacls で本人だけ）→ 持ち主の ID を設定シートのサーバー名で照合して access.json に → 社員名簿から部屋・ペルソナ・許可を作る（`office.py hire-all`）→ `snippet-install`（CLAUDE.md の作法ブロック）→ `guard rehash` → `--channels` 付きで起動 → 統括に 🎉 Congratulations
3. **2回目以降**: デスクトップの 起動／再起動／お休み／やめる。毎日 4時・15時に自動で バックアップ→更新（許可一覧の行だけ）→ 再起動。更新は同じ1行を貼り直すだけ（設定・名簿・起動時の指示は保持、.bak と日付つきの控え）
4. 手で `/discord:configure` や CLAUDE.md への貼り付けは要らない（古い手順）。DM の許可は setup が `dmPolicy=allowlist`＋持ち主で作る

## 2. 社員を増やす（日常）
```
python scripts/office.py hire "さくら" "山形出店担当" --emoji 🌸 --tone "新入社員らしく丁寧、短く" --project "C:\Users\...\yamagata-shutten"
```
→ 部屋「さくら【山形出店担当】」＋ `~/.claude/ai-office/staff/さくら.md` ＋ access.json 登録。上司は次の発言からその部屋で指示できる。

## 2b. 開発部屋・デスクトップアプリからの引き継ぎ（2026-09-27〜）
- `office.py migrate` … 引き継ぎ診断（読むだけ）。~/.claude/skills・CLAUDE.md・~/.claude/projects（会話ログの cwd とメモリ件数）を一覧にし、デスクトップに「引き継ぎ診断.txt」、~/.claude/ai-office/migrate.json に候補を書く。セットアップの最後にも自動で走り、候補があれば「引き継いで」の案内を出す
- `office.py project "部屋の名前" [--dir <パス|診断の番号>]` … カテゴリ「開発」に部屋を作り、作業フォルダ（無ければ ~/ai-office-dev/<英数字の名前> を作って git init。日本語のフォルダ名はメモリ置き場の名前がぶつかるので使わない）とメモリの置き場を結ぶ。ペルソナは templates/project_room.md
- メモリの置き場は Claude Code と同じ規則: `~/.claude/projects/<git リポジトリの一番上（外ならそのフォルダ）の英数字以外を - にした名前>/memory/`。だからデスクトップアプリで同じフォルダを開くと同じメモリになる。引き継ぎメモは そのメモリの handoff.md（MEMORY.md に索引1行）
- `office.py hire ... --skill <スキル名>` … スキルを社員にする（ペルソナに「この社員の道具」を足す）。`office.py fire "名前"` … 社員を外す（台帳と access.json から外す・部屋とペルソナは残す・統括は不可）
- `office.py watch-replies` … 返事の見張り（5分おき・launchd com.aioffice.watch／タスク AIOffice_ReplyWatch）。人の発言から10分返事が無い部屋に「⚠️ もう一度送って」を1回だけ。🌙予告から15分は黙る。状態 ~/.claude/ai-office/watch_replies.json
- 再起動は「再起動の時刻 = 04:00, 15:00」のように何回でも（会話が大きくなって通信切れ ECONNRESET で返事が出なくなるのを防ぐ・2026-09-28 開発くんで発生）
- 許可の表（access.json）は発言のたびに読み直されるので、部屋を足しても再起動は要らない
- 買った人向けの説明: デスクトップの「Discordで開発する使い方.txt」

## 3. 運用の作法（同梱の CLAUDE_snippet が守らせること）
1. 返事は Discord の `reply` ツールで、**指示が来た部屋に**返す。地の文は届かない＝未完了。話題で勝手に別の部屋へ振り替えない。
2. 上司がコピペする値（URL・コマンド・ID・文章案）は、**値だけ・単独メッセージ・コードフェンス無し**。案内は別メッセージ。
3. 選択肢は `office.py ask <部屋ID> "質問" "A" "B" "C"` で 🇦🇧🇨 を出してタップで答えてもらう（`run_in_background` で待つ。押されたら `2\tB` のように標準出力に出る）。
4. 「たぶん」で「できました」と言わない。受け側で見えた所まで確認して報告。10分超の作業は「やること3行」を先に返す。
5. 秘密（トークン・パスワード）は部屋に貼らない。ファイル名は半角英数（添付が開けない事故を防ぐ）。
6. 時刻は UTC で届く → +9h（JST）で話す。

### 設計の原則（2026-09-30・momomon の運用報告から）
- 基本は自動、確認は「取り返しのつかない操作」と「上司が決めること」だけ。ひと言・部屋の移動・確認を上司に求めない
- 定型の知らせは短く1通・二重に出さない。人数など機械が数えられるものは機械が数えて渡す（office.py hello）
- 落ち着いた開発部屋は消さずに休止（office.py archive）。数えない・03:50 の引き継ぎ更新の対象外

## 4. スクリプト
- `scripts/office.py hire-all --file 社員名簿.txt [--no-notice-room]` … 名簿（名前|役割|絵文字|engine|正典|口調）を一括で雇う。既存は名前でスキップ。最後に `NEW=n`
- `scripts/office.py hire-all`／`setup` は「お知らせ」の部屋（kind=notice・📣）も一緒に作り、config.json の notice_room に登録する（設定シートの「お知らせ部屋 = なし」なら --no-notice-room で作らない）。hello_counts の社員数には数えない（C1 2026-09-30）
- `scripts/office.py links [--out <dir>] [--post hq]` … 部屋リンク一覧 links.md/links.html（`discord://discord.com/channels/<guild>/<room>`＝iPhone ショートカット「URLを開く」用）。--post で統括部屋に「名前」→「リンク」を1部屋ずつ投稿
- `scripts/office.py backup [--out <dir>]` … 設定・台帳・ペルソナ・メモリ・スキルを zip（.env／token は入れない・14世代）
- `scripts/office.py notice "本文" [--hq]` … お知らせ部屋（config.json の notice_room）へ投稿。本文が ⚠/⚠️/🛡⚠️ で始まるか --hq なら統括部屋（hq_room）へ
- `scripts/start.ps1` / `restart.ps1` / `register_task.ps1` … Desktop\AIオフィス\起動.bat・再起動.bat の本体と 04:00 タスク登録（**.ps1 は UTF-8 BOM 必須**）
- `scripts/office.py whoami` … bot と参加サーバー
- `scripts/office.py setup --guild <ID>` … staff.json の社員ぶんの部屋を一括作成
- `scripts/office.py hire ...` … 社員を1人雇う（部屋・ペルソナ・許可・挨拶）
- `scripts/office.py list` … 社員一覧
- `scripts/office.py say <部屋ID> "本文"` … Claude Code が落ちていても届く投稿（Windows タスクスケジューラのリマインドに）
- `scripts/office.py ask <部屋ID> "質問" "A" "B" ...` … 🇦🇧🇨 で選ばせて結果を返す
- `scripts/office.py model [auto|名前] [--restart]` … モデル切替（スマホから「モデルを変えて」）。引数なしで設定と実物を表示
- `scripts/office.py new-session --file <引き継ぎ書.md>` … 「新しいセッションにして」: handoff.md に置いて再起動（次の起動だけが読む・印は start.* が消す）。`RESTART=started|not_started`
- `scripts/office.py token protect|unprotect|status|get` … トークンを暗号化保存庫（Win DPAPI ~/.claude/ai-office/token.dpapi／Mac キーチェーン ai-office-discord）へ。token() は .env→env→保存庫。start.* が復号して DISCORD_BOT_TOKEN を渡す（プラグインは env 優先）。get は起動・setup 用（見張りでは秘密扱い）
- `scripts/office.py manifest write|diff` … 正の一覧 manifest.json（ビルド時に write・Mac のビルド手順に入れる）／更新時に setup が diff で「利用者が変えたファイル」を検出→ backups/skill_<日時>/CHANGED.txt＋統括に通知
- `scripts/office.py local init|status` … 持ち主の置き場 `~/.claude/ai-office/local/`（更新で触らない）: 起動時の指示.txt（優先）／CLAUDE_local.md（snippet-install が目印の内側に足す）／office_ext.py（COMMANDS・setup）／guard_rules.py（rules・deny は弱められない）／start_hook.sh|ps1（起動直前に読む）。local/ 全体が WRITE_GUARD（AI が書くには ✅ 設定・見張りの変更）・guard_rules.py と start_hook.* は guard verify の合図にも入る
- `scripts/office.py hello` … 起動の人数（社員／開発部屋／休止）。start.* が指示文の末尾に付ける ／ `scripts/office.py archive "<開発部屋>" [--off]` … 休止／解除
- `scripts/office.py usage [--days 7] [--post] [--nick [on|off]] [--week N] [--5h N]` … 使用量の目安（会話記録の usage を message.id で重複除去して集計・直近5h/7日・最も多かった5時間との比・モデル別・日ごと）。公式の枠％ではない。`--nick`＝このサーバーでの自分のニックネームに「｜5h NN% 週 MM%」を書く（週＝直近7日の重み÷ config usage_limit_7d か学習した usage_peak_7d）（元の名前は config.json の nick_base に控え・32文字で切る・目安が出せなければ触らない）。`watch-replies` の最後で config usage_nick が off でなければ5分おき（usage_nick_at から4分未満は飛ばす）に自動更新。`--nick off` で名前を戻して止める（C4 2026-09-30 momomon要望・masa🇦）
- `scripts/office.py guard on|off|status [--restart] [--work-only]` … 見張り（関所・上級者向け・原作 momomon）。`guard/guard.py pre` をユーザー settings.json の PreToolUse に登録（AIOFFICE_DISCORD=1 の Claude にだけ効く）・`~/.claude/ai-office/guard/settings.json`（deny＋SessionStart 🛡）を settings= で起動に渡す。危ない操作は 🔐 を操作の中身（コマンド・書き込み先が開発の部屋の作業フォルダの下→その部屋、次に cwd、次に最後に指示が来た部屋、無ければ統括）に合わせて出す部屋を選び、統括以外に出したときは統括にも1行だけ短報（AIOFFICE_GUARD_ROOM=hq で常に統括に戻せる・C2 2026-09-30 masa決定）。秘密の置き場・秘密の値を書いた返事/コマンドは ✅ なしで拒否。--work-only で作業フォルダの外への書き込みも 🔐。試験 `guard/test_guard.py`（472件）

## 4b. デスクトップ（買った人が触る場所）＝ Desktop\AIオフィス起動.bat（道具チェック→トークン→名簿から部屋→リンク一覧→`claude --channels` 起動・二重起動しない）／再起動.bat（🌙予告→停止→backup→claude update→起動→☀️）／社員名簿.txt／起動時の指示.txt（起動直後に Claude へ渡す：引き継ぎを読む・cron を張り直す・03:50 に引き継ぎ書更新 cron・☀️投稿）／更新コマンド.txt／links.html／backups\／logs\。設定は `~/.claude/ai-office/config.json`（guild・hq_room・notice_room・codex_dir・codex_bridge_autostart）

## 5. 落とし穴（実体験）
- .ps1 に日本語を書くなら UTF-8 BOM を付ける（無いと Windows PowerShell が cp932 で読んで構文エラー）。.bat は BOM 無し＋先頭 `chcp 65001`
- 起動時の `--channels` 忘れ＝受信だけ死ぬ。
- Discord REST の 403 は User-Agent 未設定（`DiscordBot (...)` を付ける・office.py は対応済み）。
- bot 自身の発言はプラグインが捨てる（bot→bot は届かない）。別プロセスから司令塔に渡したい時は Firestore 等の別経路か、上司の部屋に「📨」として投稿してもらう。
- 絵文字投票は「bot 自身が先に置いた分」を除いて数える（office.py ask は投票者の ID で判定）。
- 対応表が古いのに「部屋が無い」と答えない。`GET /guilds/<id>/channels` で実際の部屋を見てから言う。
- 長い処理を `run_in_background` に任せると数十分で殺されることがある → 別プロセス（Start-Process／nohup）へ。

## 6. 売り物の形（2026-09-30 時点・決定事項は memory discord-ai-office-skill.md）
- 売り場 Brain・9,800円（明鏡限定 4,980 3日間→12,800→19,800）・紹介料 50%・返金なし・サポートは購入者 Discord の共通部屋
- 同梱＝1行インストーラ＋キット（この skill・デスクトップの AIオフィス・設定シート・README・README_for_buyers）。配布は GitHub Pages（kakigawatei.github.io/ai-office/：kit.zip／install.sh／install.ps1／model.txt）。公開は masa の「公開して」のあと、ai-office-pages を push し公開先の md5 を照合
- 差別化＝部屋＝社員、スマホ完結の作法（🇦🇧🇨・値だけ単独）、デスクトップで育てた Claude をそのまま使う開発部屋、見張り（上級者向け）、モデル自動追随、新しいセッション、使用量の目安
- 販売名義は未決（個人事業かバウ）。Discord・Claude の商標注記と「うっかり防止（壁ではない）」の説明を必ず載せる
