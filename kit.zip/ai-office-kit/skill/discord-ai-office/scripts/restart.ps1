﻿# restart.ps1 — AIオフィス 定期再起動（統括部屋に予告 → Claude Code を落とす → バックアップ → 更新 → 起動）
#   使い方: 再起動.bat から呼ばれる（タスクスケジューラの 04:00 も同じ）。 -Office <Desktop\AIオフィス のパス>
param([string]$Office = (Join-Path ([Environment]::GetFolderPath("Desktop")) "AIオフィス"), [switch]$NoUpdate, [switch]$Hold)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Continue"
$Skill = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office"
$Py    = Join-Path $Skill "scripts\office.py"
$Logs  = Join-Path $Office "logs"; New-Item -ItemType Directory -Force $Logs | Out-Null
$Log   = Join-Path $Logs ("restart_" + (Get-Date -Format "yyyyMMdd") + ".log")
$env:PYTHONUTF8 = "1"
function Say($m) { $line = "[" + (Get-Date -Format "HH:mm:ss") + "] " + $m; Write-Host $line; Add-Content -Path $Log -Value $line -Encoding UTF8 }

Say "=== AIオフィス 再起動 ==="
$hhmm = Get-Date -Format "HH:mm"
& python $Py notice ("🌙 " + $hhmm + " 定期再起動に入ります（バックアップ→更新→起動。5分ほど返事が止まります）") 2>&1 | ForEach-Object { Say ("  " + $_) }

# ① Claude Code（Discord 付き）とその窓を落とす
$procs = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" }
foreach ($p in $procs) { Say ("停止: " + $p.ProcessId + " " + $p.Name); Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep 5
$left = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "--channels plugin:discord" }
foreach ($p in $left) { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue }
Say "Claude Code を停止しました"

# ② バックアップ（zip・トークンは入れない）
& python $Py backup --out (Join-Path $Office "backups") 2>&1 | ForEach-Object { Say ("  " + $_) }

# ③ 更新
if (-not $NoUpdate) {
  Say "claude update ..."
  try { $u = & claude update 2>&1 | Out-String; Say ("  " + $u.Trim()) } catch { Say ("  claude update 失敗: " + $_) }
  $UpdF = Join-Path $Office "更新コマンド.txt"
  if (Test-Path $UpdF) {
    foreach ($line in (Get-Content $UpdF -Encoding UTF8)) {
      $line = $line.Trim(); if (-not $line -or $line.StartsWith("#")) { continue }
      Say ("更新: " + $line)
      try { Invoke-Expression $line 2>&1 | ForEach-Object { Say ("  " + $_) } } catch { Say ("  失敗: " + $_) }
    }
  }
}

# ④ 起動
& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $Skill "scripts\start.ps1") -Office $Office
$alive = $true
for ($n = 1; $n -le 15; $n++) { Start-Sleep 2; if (-not (Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" })) { $alive = $false } }   # 30秒動き続けているか
if ($alive) { & python $Py notice ("☀️ " + (Get-Date -Format "HH:mm") + " 再起動しました。引き継ぎを読んで続きから動きます") 2>&1 | ForEach-Object { Say ("  " + $_) } }
else { & python $Py notice ("⚠️ " + (Get-Date -Format "HH:mm") + " 再起動で Claude が立ち上がりませんでした。パソコンの「AIオフィス」フォルダの 起動.bat をダブルクリックしてください") 2>&1 | ForEach-Object { Say ("  " + $_) } }
Say "=== 再起動 完了 ==="
if ($Hold) { Read-Host "Enter で閉じる" | Out-Null }
