﻿# register_task.ps1 — 毎朝の定期再起動をタスクスケジューラに登録する
#   使い方:  powershell -ExecutionPolicy Bypass -File register_task.ps1 [-Time 04:00] [-Remove]
#   bat や日本語のパスを通さず、restart.ps1 を直接動かす（引数は1本の文字列で渡す＝引用符が崩れない）
param([string]$Time = "04:00", [string]$Office = "", [switch]$Remove)
$name = "AIOffice_DailyRestart"
$Time = -join ($Time.ToCharArray() | ForEach-Object { if ([int]$_ -ge 0xFF10 -and [int]$_ -le 0xFF19) { [char]([int]$_ - 0xFF10 + 48) } elseif ($_ -eq [char]0xFF1A) { ":" } else { $_ } })   # 全角の「０４：００」も受ける
Unregister-ScheduledTask -TaskName "AIオフィス 定期再起動" -Confirm:$false -ErrorAction SilentlyContinue   # 以前の名前（bat 経由）を片付ける
if ($Remove) { Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName "AIOffice_ReplyWatch" -Confirm:$false -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName "AIOffice_Watchdog" -Confirm:$false -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName "AIOffice_AtLogon" -Confirm:$false -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName "AIOffice_RestartNow" -Confirm:$false -ErrorAction SilentlyContinue; Write-Host "削除しました"; exit }
$ps1 = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\restart.ps1"
if (-not (Test-Path $ps1)) { Write-Host "restart.ps1 が見つかりません: $ps1"; exit 1 }
try {
  $a = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ('-NoProfile -ExecutionPolicy Bypass -File "' + $ps1 + '"')
  $t = @(); foreach ($x in ($Time -split "[,，、 ]+")) { if ($x) { $t += New-ScheduledTaskTrigger -Daily -At $x } }   # "04:00, 15:00" のように何回でも
  $s = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries   # スリープ明けなど、時刻を過ぎていたら起きたときに動かす
  Register-ScheduledTask -TaskName $name -Action $a -Trigger $t -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: 毎日 $Time に 再起動（$name）"
  # 返事の見張り（5分おき・窓を出さない pythonw）
  $py = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\office.py"
  $pyw = (Get-Command pythonw -ErrorAction SilentlyContinue).Source; if (-not $pyw) { $pyw = (Get-Command python).Source }
  $wa = New-ScheduledTaskAction -Execute $pyw -Argument ('"' + $py + '" watch-replies')
  $wt = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
  Register-ScheduledTask -TaskName "AIOffice_ReplyWatch" -Action $wa -Trigger $wt -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: 返事の見張り（5分おき・AIOffice_ReplyWatch）"
  # 見回り（5分おき・窓なし）: Discord の部品が落ちていたら、ネットが戻り次第つなぎ直す（momomon さん報告 F-40）
  $vbs = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\watchdog.vbs"
  $da = New-ScheduledTaskAction -Execute "wscript.exe" -Argument ('"' + $vbs + '"')
  $dt = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
  Register-ScheduledTask -TaskName "AIOffice_Watchdog" -Action $da -Trigger $dt -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: 見回り（5分おき・AIOffice_Watchdog）"
  # ログイン時の起動（停電・OS 更新・再起動のあと、ログインすれば自動で立ち上がる）
  $ls = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\start.ps1"
  $la = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $ls + '"')
  $lt = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
  Register-ScheduledTask -TaskName "AIOffice_AtLogon" -Action $la -Trigger $lt -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: ログイン時の起動（AIOffice_AtLogon）"
  # 「今すぐ再起動」（予定なし・office.py model --restart などが起こす。Claude の中から直接再起動すると自分ごと止まるため）
  $ra = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $ps1 + '" -NoUpdate')
  Register-ScheduledTask -TaskName "AIOffice_RestartNow" -Action $ra -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: 今すぐ再起動（AIOffice_RestartNow・スマホからのモデル切替用）"
} catch { Write-Host ("登録に失敗しました: " + $_); exit 1 }
