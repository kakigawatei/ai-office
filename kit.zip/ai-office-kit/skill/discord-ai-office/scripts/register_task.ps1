﻿# register_task.ps1 — 毎朝の定期再起動をタスクスケジューラに登録する
#   使い方:  powershell -ExecutionPolicy Bypass -File register_task.ps1 [-Time 04:00] [-Remove]
#   bat や日本語のパスを通さず、restart.ps1 を直接動かす（引数は1本の文字列で渡す＝引用符が崩れない）
param([string]$Time = "04:00", [string]$Office = "", [switch]$Remove)
$name = "AIOffice_DailyRestart"
Unregister-ScheduledTask -TaskName "AIオフィス 定期再起動" -Confirm:$false -ErrorAction SilentlyContinue   # 以前の名前（bat 経由）を片付ける
if ($Remove) { Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue; Unregister-ScheduledTask -TaskName "AIOffice_ReplyWatch" -Confirm:$false -ErrorAction SilentlyContinue; Write-Host "削除しました"; exit }
$ps1 = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\restart.ps1"
if (-not (Test-Path $ps1)) { Write-Host "restart.ps1 が見つかりません: $ps1"; exit 1 }
try {
  $a = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ('-NoProfile -ExecutionPolicy Bypass -File "' + $ps1 + '"')
  $t = @(); foreach ($x in ($Time -split "[,，、 ]+")) { if ($x) { $t += New-ScheduledTaskTrigger -Daily -At $x } }   # "04:00, 15:00" のように何回でも
  $s = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries   # スリープ明けなど、時刻を過ぎていたら起きたときに動かす
  Register-ScheduledTask -TaskName $name -Action $a -Trigger $t -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: 毎日 $Time に 再起動（$name）"
  # 返事の見張り（5分おき・窓を出さない pythonw）
  $py = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\office.py"
  $pyw = (Get-Command pythonw -ErrorAction SilentlyContinue).Source; if (-not $pyw) { $pyw = (Get-Command python).Source }
  $wa = New-ScheduledTaskAction -Execute $pyw -Argument ('"' + $py + '" watch-replies')
  $wt = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 3650)
  Register-ScheduledTask -TaskName "AIOffice_ReplyWatch" -Action $wa -Trigger $wt -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: 返事の見張り（5分おき・AIOffice_ReplyWatch）"
} catch { Write-Host ("登録に失敗しました: " + $_); exit 1 }
