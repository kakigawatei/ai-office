﻿# register_task.ps1 — 毎朝の定期再起動をタスクスケジューラに登録する（1回だけ実行）
#   使い方:  powershell -ExecutionPolicy Bypass -File register_task.ps1 [-Time 04:00] [-Office <Desktop\AIオフィス>] [-Remove]
param([string]$Time = "04:00", [string]$Office = (Join-Path $env:USERPROFILE "Desktop\AIオフィス"), [switch]$Remove)
$name = "AIオフィス 定期再起動"
if ($Remove) { schtasks /Delete /TN $name /F; exit }
$bat = Join-Path $Office "再起動.bat"
if (-not (Test-Path $bat)) { Write-Host "再起動.bat が見つかりません: $bat"; exit 1 }
schtasks /Create /TN $name /TR "`"$bat`"" /SC DAILY /ST $Time /F /RL LIMITED
Write-Host "登録しました: 毎日 $Time に $bat"
schtasks /Query /TN $name /FO LIST
