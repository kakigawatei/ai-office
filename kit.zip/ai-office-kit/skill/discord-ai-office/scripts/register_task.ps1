﻿# register_task.ps1 — 毎朝の定期再起動をタスクスケジューラに登録する
#   使い方:  powershell -ExecutionPolicy Bypass -File register_task.ps1 [-Time 04:00] [-Remove]
#   bat や日本語のパスを通さず、restart.ps1 を直接動かす（引数は1本の文字列で渡す＝引用符が崩れない）
param([string]$Time = "04:00", [string]$Office = "", [switch]$Remove)
$name = "AIOffice_DailyRestart"
Unregister-ScheduledTask -TaskName "AIオフィス 定期再起動" -Confirm:$false -ErrorAction SilentlyContinue   # 以前の名前（bat 経由）を片付ける
if ($Remove) { Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue; Write-Host "削除しました"; exit }
$ps1 = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\restart.ps1"
if (-not (Test-Path $ps1)) { Write-Host "restart.ps1 が見つかりません: $ps1"; exit 1 }
try {
  $a = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ('-NoProfile -ExecutionPolicy Bypass -File "' + $ps1 + '"')
  $t = New-ScheduledTaskTrigger -Daily -At $Time
  $s = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries   # スリープ明けなど、時刻を過ぎていたら起きたときに動かす
  Register-ScheduledTask -TaskName $name -Action $a -Trigger $t -Settings $s -Force -ErrorAction Stop | Out-Null
  Write-Host "登録しました: 毎日 $Time に 再起動（$name）"
} catch { Write-Host ("登録に失敗しました: " + $_); exit 1 }
