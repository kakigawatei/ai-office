﻿# watchdog.ps1 — Discord 用 Claude の見回り（momomon さん作・2026-09-29 キットに標準搭載）
#   5分おきにタスクスケジューラ（AIOffice_Watchdog・watchdog.vbs 経由で窓を出さない）から呼ばれる。
#   Discord の部品（bun）が止まっている／Claude 自体がいないときに、ネットが戻っていれば restart.ps1 でつなぎ直す。
#   きっかけ: 2026-09-29 04:01 の再起動直後にネットが一瞬切れ、部品が止まったまま 13:12 まで誰も気づかなかった。
param([switch]$DryRun, [string]$Simulate = "")   # -Simulate nobun / noclaude / nonet / ok は判定の試験用（何も起動しない）
$ErrorActionPreference = "Continue"
$Office = Join-Path ([Environment]::GetFolderPath("Desktop")) "AIオフィス"
$Logs = Join-Path $Office "logs"; New-Item -ItemType Directory -Force $Logs | Out-Null
$Log = Join-Path $Logs ("watchdog_" + (Get-Date -Format "yyyyMM") + ".log")
$State = Join-Path $env:USERPROFILE ".claude\ai-office\guard\watchdog_last_restart.txt"
$Restart = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office\scripts\restart.ps1"
function Say($m) { Add-Content -Path $Log -Value ("[" + (Get-Date -Format "MM-dd HH:mm:ss") + "] " + $m) -Encoding UTF8; if ($DryRun -or $Simulate) { Write-Host $m } }

# お休み中（office.py pause）は起こさない
if ((Test-Path (Join-Path $env:USERPROFILE ".claude\ai-office\paused.json")) -and -not $Simulate) { exit 0 }
# 再起動の最中（04:00 の定期再起動・手動の 再起動.bat・自分が起こした再起動）は何もしない
$busy = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq "powershell.exe" -and $_.CommandLine -match "(restart|start)\.ps1" -and $_.CommandLine -notmatch "watchdog" }
if ($busy -and -not $Simulate) { exit 0 }

$claude = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq "claude.exe" -and $_.CommandLine -match "--channels" })
$bun = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq "bun.exe" -and $_.CommandLine -match "claude-plugins-official[\\/]discord" })
if ($Simulate -match "nobun") { $bun = @() }; if ($Simulate -match "noclaude") { $claude = @(); $bun = @() }; if ($Simulate -match "^ok$" -and $claude.Count -eq 0) { $claude = @(1) ; $bun = @(1) }

$problem = ""
if ($claude.Count -eq 0) { $problem = "Discord 用 Claude が動いていない" }
elseif ($bun.Count -eq 0) {
  $age = if ($Simulate) { 999 } else { ((Get-Date) - ($claude | Sort-Object CreationDate | Select-Object -First 1).CreationDate).TotalMinutes }
  if ($age -ge 3) { $problem = "Discord の部品（bun）が止まっている（Claude は動いている・起動から " + [int]$age + " 分）" }
}
if (-not $problem) { exit 0 }

$net = if ($Simulate -match "nonet") { $false } else { [bool](Test-NetConnection discord.com -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue) }
if (-not $net) { Say ("異常: " + $problem + " → ネットがまだつながらないので待つ"); exit 0 }

# 直前に自分で再起動したなら、15分は待つ（再起動が繰り返し失敗して回り続けないように）
$last = $null; try { $last = [datetime](Get-Content $State -ErrorAction Stop) } catch {}
if ($last -and ((Get-Date) - $last).TotalMinutes -lt 15 -and -not $Simulate) { Say ("異常: " + $problem + " → 15分以内に再起動済みなので待つ"); exit 0 }

Say ("異常: " + $problem + " → つなぎ直す")
if ($DryRun -or $Simulate) { Say "（試験のため再起動はしない）"; exit 0 }
New-Item -ItemType Directory -Force (Split-Path $State) | Out-Null
Set-Content -Path $State -Value (Get-Date -Format "o") -Encoding UTF8
& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $Restart -NoUpdate -Reason "Discord の接続が切れていたので、つなぎ直します"
Say "再起動を実行した"
