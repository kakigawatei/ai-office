﻿# start.ps1 — AIオフィス 起動（初回セットアップ込み）
#   使い方: 起動.bat から呼ばれる。 -Office <Desktop\AIオフィス のパス>
#   やること: ①道具チェック ②bot トークン確認 ③名簿から部屋を一括作成 ④新しい部屋があればリンク一覧を統括部屋へ ⑤Claude Code を Discord 付きで起動
param([string]$Office = (Join-Path ([Environment]::GetFolderPath("Desktop")) "AIオフィス"), [switch]$NoLaunch, [switch]$Hold)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Continue"
$Skill  = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office"
$Py     = Join-Path $Skill "scripts\office.py"
$Cfg    = Join-Path $env:USERPROFILE ".claude\ai-office\config.json"
$TokenF = Join-Path $env:USERPROFILE ".claude\channels\discord\.env"
$Logs   = Join-Path $Office "logs"; New-Item -ItemType Directory -Force $Logs | Out-Null
$Log    = Join-Path $Logs ("start_" + (Get-Date -Format "yyyyMMdd") + ".log")
$env:PYTHONUTF8 = "1"
function Say($m) { $line = "[" + (Get-Date -Format "HH:mm:ss") + "] " + $m; Write-Host $line; Add-Content -Path $Log -Value $line -Encoding UTF8 }
function Done($code) { if ($Hold) { Write-Host ""; Write-Host "（Claude は別の窓で動いています。この窓は閉じて大丈夫です）"; Read-Host "Enter で閉じる" | Out-Null }; exit $code }

Say "=== AIオフィス 起動 ==="
# ① 道具チェック（node は要らない・ネイティブ版 claude とプラグイン用 bun）
$env:Path = ((Join-Path $env:USERPROFILE ".local\bin"), (Join-Path $env:USERPROFILE ".bun\bin"), [Environment]::GetEnvironmentVariable("Path","Machine"), [Environment]::GetEnvironmentVariable("Path","User")) -join ";"
$need = @()
foreach ($t in @("python", "claude")) { if (-not (Get-Command $t -ErrorAction SilentlyContinue)) { $need += $t } }
if ($need.Count -gt 0) { Say ("足りない道具: " + ($need -join ", ") + " … セットアップの1行をもう一度貼り直してください"); Done 1 }
Say "道具OK: python / claude"

# ② bot トークン
if (-not (Test-Path $TokenF) -or -not (Select-String -Path $TokenF -Pattern "DISCORD_BOT_TOKEN=\S" -Quiet)) {
  Say "Discord bot のトークンがまだ入っていません。セットアップをもう一度やってください:"
  Say "  キットのフォルダ（%USERPROFILE%\ai-office-kit）の「はじめに.bat」をダブルクリック（または販売ページの Windows 用の1行を貼り直す）"
  if ($Hold) { Read-Host "Enter で閉じる" | Out-Null }; exit
}
Say "bot トークンOK"
& python $Py allow-basics 2>&1 | Where-Object { $_ -notmatch "^ALLOW_ADDED=0" } | ForEach-Object { Say ("  " + $_) }   # Discord の道具と作業場所の許可（auto でも返事が止まらない）
& python $Py resume 2>&1 | Where-Object { $_ -notmatch "^RESUME=" } | ForEach-Object { Say ("  " + $_) }   # お休み中なら、自動再起動と見張りを戻す
$HO = Join-Path $env:USERPROFILE ".claude\ai-office"   # 引き継ぎメモ handoff.md は「新しいセッションにして」直後の1回だけ読む（印は Claude を実際に起動する直前だけ扱う・v1.6.1）

# ③ 名簿から部屋を一括作成（既存はスキップ）
$Roster = Join-Path $Office "社員名簿.txt"
$newRooms = 0
if (Test-Path $Roster) {
  $out = & python $Py hire-all --file $Roster 2>&1
  $out | ForEach-Object { Say ("  " + $_) }
  $m = ($out | Select-String -Pattern "^NEW=(\d+)")
  if ($m) { $newRooms = [int]$m.Matches[0].Groups[1].Value }
  if ($out -match "HTTP 403") { Say "★ bot の権限不足です。上の URL を開いて認証してから、もう一度 起動.bat"; if ($Hold) { Read-Host "Enter で閉じる" | Out-Null }; exit }
} else { Say "社員名簿.txt が無いので部屋作成はスキップ" }

# ④ リンク一覧（常に書き出し・新しい部屋があった時だけ統括部屋に投稿）
& python $Py links --out $Office 2>&1 | ForEach-Object { Say ("  " + $_) }
if ($newRooms -gt 0) { & python $Py links --post hq 2>&1 | ForEach-Object { Say ("  " + $_) } }

# ⑤ Claude Code 起動（すでに Discord 付きで動いていれば起動しない）
$running = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" }
if ($running) { Say "Claude Code（Discord付き）はすでに動いています。二重起動しません。"; if (-not $NoLaunch -and -not $Hold) { Start-Sleep 3 }; Done 0 }
if ($NoLaunch) { Say "（-NoLaunch のため起動はしない）"; exit }
# Discord 連携（プラグイン）の部品がそろっているか確かめ、足りなければ入れ直す（途中で止まった install で空フォルダが残ると bot がオフラインのままになる）
function Heal-Plugin {
  $base = Join-Path $env:USERPROFILE ".claude\plugins\cache\claude-plugins-official\discord"
  $pd = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1
  if (-not $pd) { return "none" }
  $nm = Join-Path $pd.FullName "node_modules"
  $bad = { if (-not (Test-Path $nm)) { return 1 }
    $dirs = @(Get-ChildItem $nm -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne ".bin" -and $_.Name -ne ".cache" })
    $pk = @(); foreach ($d in $dirs) { if ($d.Name.StartsWith("@")) { $pk += @(Get-ChildItem $d.FullName -Directory -ErrorAction SilentlyContinue) } else { $pk += $d } }
    if ($pk.Count -lt 5) { return 1 }
    @($pk | Where-Object { -not (Test-Path (Join-Path $_.FullName "package.json")) }).Count }   # 中身の無い部品フォルダの数
  if ((& $bad) -eq 0) { return "ok" }
  for ($t = 1; $t -le 2; $t++) {
    Remove-Item -Recurse -Force $nm -ErrorAction SilentlyContinue
    cmd /c ("cd /d `"" + $pd.FullName + "`" && bun install --no-summary >nul 2>&1")
    if ((& $bad) -eq 0) { return "fixed" }
  }
  return "broken"
}
$h = Heal-Plugin
if ($h -eq "fixed") { Say "Discord 連携の部品を入れ直しました" } elseif ($h -eq "broken") { Say "★ Discord 連携の部品を入れられませんでした（ネットや容量を確認して、もう一度 起動.bat）" }
$Work = Join-Path $env:USERPROFILE "Desktop"; if (-not (Test-Path $Work)) { $Work = $env:USERPROFILE }
$WorkOnly = $false   # [作業フォルダ限定] モデル設定.txt の workonly=1 で、見張りが Write/Edit の宛先を見る（B5③）
$WorkDir = ""   # [起動フォルダ] モデル設定.txt の workdir= で起動フォルダを指定（無ければ従来どおり）
# 初回の画面（テーマ選び・フォルダを信頼するか・全画面表示を試す？・Claude in Chrome を使う？）を先に済ませる＝無人の再起動でも止まらない
$CJ = Join-Path $env:USERPROFILE ".claude.json"
& python -c "import json,os,sys; p,w=sys.argv[1],sys.argv[2]; c=json.load(open(p,encoding='utf-8')) if os.path.exists(p) else {}; c['hasCompletedOnboarding']=True; c.setdefault('theme','dark'); c['fullscreenUpsellSeenCount']=max(99,c.get('fullscreenUpsellSeenCount',0)); c.setdefault('claudeInChromeDefaultEnabled',False); pr=c.setdefault('projects',{}); [pr.setdefault(k,{}).__setitem__('hasTrustDialogAccepted',True) for k in {w, w.replace(chr(92),'/')}]; json.dump(c,open(p,'w',encoding='utf-8'),ensure_ascii=False,indent=2)" $CJ $Work
# [F-33] ほかの Claude セッション（PC のデスクトップアプリ等）が Discord 部品の接続に失敗すると、mcp-needs-auth-cache.json に
#   「認証が要る」印が残り、次の起動で Discord に接続しないまま動く（2026-09-28 01:43 の印で 01:55 の再起動が未接続）。起動の直前に discord の印だけ消す
& python -c "import json,os,sys; p=sys.argv[1]; c=json.load(open(p,encoding='utf-8-sig')) if os.path.exists(p) else None; k=[x for x in (c or {}) if x=='plugin:discord:discord' or x.startswith('plugin:discord:')]; [c.pop(x) for x in k]; (json.dump(c,open(p,'w',encoding='utf-8')) if k else None); print('needs-auth の印を消した: ' + ','.join(k) if k else 'needs-auth の印なし')" (Join-Path $env:USERPROFILE ".claude\mcp-needs-auth-cache.json") 2>&1 | ForEach-Object { Say ("  " + $_) }
$PromptF = Join-Path $Office "起動時の指示.txt"; $LocalPF = Join-Path $env:USERPROFILE ".claude\ai-office\local\起動時の指示.txt"; if (Test-Path $LocalPF) { $PromptF = $LocalPF }   # local/ にあればそちら（更新で触らない置き場）
$Model = "auto"; $Effort = "high"
$MF = Join-Path $Office "モデル設定.txt"
$GuardSettings = ""   # [見張り] モデル設定.txt の settings= で Discord 用だけの設定ファイル（秘密を読ませない一覧・関所のフック）を渡す
$Perm = "auto"   # 権限モード: モデル設定.txt の permission= で変える（manual / auto / acceptEdits / bypassPermissions など）。bypassPermissions のときは settings= で見張りの設定を渡すこと
if (Test-Path $MF) { foreach ($l in (Get-Content $MF -Encoding UTF8)) { if ($l -match "^model=(.+)$") { $Model = $Matches[1].Trim() }; if ($l -match "^effort=(.+)$") { $Effort = $Matches[1].Trim() }; if ($l -match "^permission=(manual|default|acceptEdits|auto|plan|dontAsk|bypassPermissions)\s*$") { $Perm = $Matches[1] }; if ($l -match "^workdir=(.+)$") { $WorkDir = $Matches[1].Trim() }; if ($l -match "^workonly=1\s*$") { $WorkOnly = $true }; if ($l -match "^settings=(.+)$") { $GuardSettings = $Matches[1].Trim() } } }
if ($WorkDir -and (Test-Path $WorkDir)) { $Work = $WorkDir }   # [起動フォルダ]
if ($Model -ne "auto" -and $Model -notmatch "^[A-Za-z][A-Za-z0-9.-]{1,40}$") { Say ("★ モデル設定.txt の model= が変な値なので auto にします: " + $Model); $Model = "auto" }   # 監査 中5: 起動ファイルに埋め込むので検査
if ($Effort -notin @("low", "medium", "high", "max")) { $Effort = "high" }
if ($Model -eq "auto") {   # auto＝公開ページの推奨1行に追随（英数字・ピリオド・ハイフンだけ受け付ける）。取れなければ前回の値、それも無ければ opus
  $RecF = Join-Path $env:USERPROFILE ".claude\ai-office\recommended_model.txt"
  try { $rec = ((Invoke-WebRequest -UseBasicParsing -Uri "https://kakigawatei.github.io/ai-office/model.txt" -TimeoutSec 6).Content -split "`n")[0].Trim(); if ($rec -match "^(?i)(opus|sonnet|haiku|claude-(opus|sonnet|haiku|fable)-[0-9][0-9a-z.-]{0,30})$") { [IO.File]::WriteAllText($RecF, $rec + "`n") } else { Say ("★ 公開ページのモデル名が許可一覧に無いので使いません: " + $rec) } } catch {}
  $Model = "opus"; if (Test-Path $RecF) { $r2 = (Get-Content $RecF -First 1).Trim(); if ($r2 -match "^[A-Za-z][A-Za-z0-9.-]{1,40}$") { $Model = $r2 } }
  Say ("モデル auto → " + $Model)
}
if (-not $GuardSettings -and $Perm -eq "bypassPermissions") { Say "★ 全許可なのに見張りの設定（settings=）がありません"; & python $Py notice "⚠️ 全許可のまま、見張りの設定（モデル設定.txt の settings=）なしで起動します。秘密を読ませない一覧と起動時の 🛡 報告が効きません" 2>&1 | ForEach-Object { Say ("  " + $_) } }   # [見張り] 再監査 M-2
if ($GuardSettings -and -not (Test-Path $GuardSettings)) { Say ("★ 見張りの設定ファイルがありません: " + $GuardSettings); & python $Py notice "⚠️ 見張りの設定ファイルが見つからないまま起動します（秘密を読ませない一覧と起動時の 🛡 報告が効きません。関所はユーザー設定側で動きます）。PC で ops/discord-guard を確かめてください" 2>&1 | ForEach-Object { Say ("  " + $_) } }   # [見張り] 監査 M-2
if (-not $GuardSettings) { $GuardSettings = Join-Path $Skill "templates\discord-settings.json" }   # 既定＝秘密（.env・鍵）を読ませない一覧だけ。Discord 用の起動にだけ効く（警告の判定より後に置く）
$Launch = Join-Path $env:USERPROFILE ".claude\ai-office\launch_claude.ps1"; New-Item -ItemType Directory -Force (Split-Path $Launch) | Out-Null
$L = @(
  '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; [Console]::InputEncoding=[System.Text.Encoding]::UTF8; chcp 65001 | Out-Null',
  '$Host.UI.RawUI.WindowTitle = "AIオフィス 起動中（この窓は閉じない）"',
  'foreach ($k in @(Get-ChildItem Env: | Where-Object { $_.Name -match "^(CLAUDE|ANTHROPIC_|MCP_|DISABLE_AUTOUPDATER$|DISABLE_MICROCOMPACT$)" } | ForEach-Object Name)) { if (-not [Environment]::GetEnvironmentVariable($k, "User") -and -not [Environment]::GetEnvironmentVariable($k, "Machine")) { Remove-Item "Env:$k" -ErrorAction SilentlyContinue } }',   # [K-10] 親（デスクトップアプリ等）から引き継いだ Claude 用の環境変数を消す。残すと子セッション扱い・Discord 未接続になる（F-19/F-26）
  '$env:MCP_TIMEOUT = "180000"',
  ('$lh = "' + (Join-Path $env:USERPROFILE ".claude\ai-office\local\start_hook.ps1") + '"; if (Test-Path $lh) { . $lh }'),   # 持ち主の起動フック（環境変数など・更新で触らない）
  '$env:AIOFFICE_DISCORD = "1"',   # [見張り] Discord 用の Claude だという目印（guard.py はこれが無いと何もしない）
  ('$tf = "' + (Join-Path $env:USERPROFILE ".claude\channels\discord\.env") + '"; $td = "' + (Join-Path $env:USERPROFILE ".claude\ai-office\token.dpapi") + '"; if (-not ((Test-Path $tf) -and (Select-String -Path $tf -Pattern "DISCORD_BOT_TOKEN=\S" -Quiet)) -and (Test-Path $td)) { Add-Type -AssemblyName System.Security; $env:DISCORD_BOT_TOKEN = [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($td), $null, "CurrentUser")) }'),   # [B5①] 暗号化保存庫から復号して環境変数で渡す（値はファイルに書かない）
  $(if ($WorkOnly) { '$env:AIOFFICE_WORK_ROOTS = "' + (((Join-Path $env:USERPROFILE "ai-office-data") + ";" + $Office + ";" + $Work).Replace('"', '')) + '"' } else { "" }),   # [作業フォルダ限定] B5③
  ('$env:Path = "' + (Join-Path $env:USERPROFILE ".local\bin") + ';' + (Join-Path $env:USERPROFILE ".bun\bin") + ';" + $env:Path'),
  ("Set-Location '" + $Work.Replace("'", "''") + "'"),
  ("`$pf = '" + $PromptF + "'"),
  '$p = if (Test-Path $pf) { (Get-Content $pf -Raw -Encoding UTF8).Trim() } else { "" }',
  ('$h = (& python "' + $Py + '" hello 2>$null | Where-Object { $_ -match "^HELLO=" } | ForEach-Object { $_ -replace "^HELLO=", "" } | Select-Object -First 1); if ($p -and $h) { $p = $p + "`n（起動スクリプトが数えた今の人数: " + $h + "。統括への報告はこの数字を使い、自分で数え直さない）" }'),   # momomon K-33
  ('$nid = (& python "' + $Py + '" hello 2>$null | Where-Object { $_ -match "^NOTICE=" } | ForEach-Object { $_ -replace "^NOTICE=", "" } | Select-Object -First 1); if ($p -and $nid) { $p = $p + "`n（お知らせの部屋: <#" + $nid + ">）" }'),   # C1 2026-09-30
  ('$m = "' + $Model + '"; $e = "' + $Effort + '"'),
  ('$pa = @(' + $(if ($Perm) { "'--permission-mode', '" + $Perm + "'" } else { "" }) + ')'),   # 
  $(if ($GuardSettings -and (Test-Path $GuardSettings)) { "`$pa += @('--settings', '" + $GuardSettings.Replace("'", "''") + "')" } else { "" }),   # [見張り]
  'if ($p) { claude $p --model $m --effort $e @pa --channels plugin:discord@claude-plugins-official } else { claude --model $m --effort $e @pa --channels plugin:discord@claude-plugins-official }'   # 指示文・モデルは --channels より前
)
if (Test-Path (Join-Path $Logs "debug.on")) { $L = $L[0..($L.Count-2)] + @(("`$pa += @('--debug-file', '" + (Join-Path $Logs ("claude_debug_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")) + "')")) + $L[-1] }   #  logs\debug.on があるときだけ詳しい記録を取る（原因調べ用）
$L += 'exit 0'   # [K-8] 終了コード0で抜けると Windows Terminal が窓を閉じる
[IO.File]::WriteAllText($Launch, ($L -join "`r`n") + "`r`n", (New-Object System.Text.UTF8Encoding($true)))
# [K-12] タスクスケジューラ経由だと既定ターミナルへの引き渡しが失敗し、見えない窓で動いた（F-23）。wt.exe があれば新しい窓を明示して開く
if (Test-Path (Join-Path $HO "handoff.pending")) { Remove-Item -Force (Join-Path $HO "handoff.pending"); Say "引き継ぎメモあり（この起動で読む）" } elseif (Test-Path (Join-Path $HO "handoff.md")) { Move-Item -Force (Join-Path $HO "handoff.md") (Join-Path $HO "handoff_old.md") }   # 「新しいセッションにして」直後の1回だけ読む（印が無い起動では脇にどける）
$Wt = Join-Path $env:LOCALAPPDATA "Microsoft\WindowsApps\wt.exe"
if (Test-Path $Wt) { Start-Process $Wt -ArgumentList "-w new powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$Launch`"" }   # -NoExit なし＝Claude が止まれば窓も閉じる（K-8）
else { Start-Process powershell.exe -ArgumentList "-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$Launch`"" -WindowStyle Minimized }   # Q22: 窓はタスクバーにしまう（Hidden にはしない＝F-23 の再発防止）
Say "Claude Code を起動しました（Discord プラグイン付き）"

# ⑥ Codex 社員がいる場合の橋（config の codex_bridge_autostart が true のときだけ）
$cfgObj = $null; if (Test-Path $Cfg) { try { $cfgObj = Get-Content $Cfg -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $cfgObj = $null } }   #  $cfg は $Cfg と同じ変数（大文字小文字を区別しない）なので名前を分けた
if ($cfgObj -and $cfgObj.codex_bridge_autostart -and $cfgObj.codex_dir -and (Test-Path (Join-Path $cfgObj.codex_dir "codex_bridge.py"))) {
  $cb = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "codex_bridge.py" }
  if (-not $cb) { Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", "`$env:PYTHONUTF8='1'; Set-Location '$($cfgObj.codex_dir)'; python -u codex_bridge.py"; Say "codex_bridge.py を起動しました" }
}
Say "=== 起動 完了 ==="
if ($Hold) { Done 0 } else { Start-Sleep 3 }
