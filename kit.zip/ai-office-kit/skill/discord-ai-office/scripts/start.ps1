﻿# start.ps1 — AIオフィス 起動（初回セットアップ込み）
#   使い方: 起動.bat から呼ばれる。 -Office <Desktop\AIオフィス のパス>
#   やること: ①道具チェック ②bot トークン確認 ③名簿から部屋を一括作成 ④新しい部屋があればリンク一覧を統括部屋へ ⑤Claude Code を Discord 付きで起動
param([string]$Office = (Join-Path $env:USERPROFILE "Desktop\AIオフィス"), [switch]$NoLaunch)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Continue"
$Skill  = Join-Path $env:USERPROFILE ".claude\skills\discord-ai-office"
$Py     = Join-Path $Skill "scripts\office.py"
$Cfg    = Join-Path $env:USERPROFILE ".claude\ai-office\config.json"
$TokenF = Join-Path $env:USERPROFILE ".claude\channels\discord\.env"
$Logs   = Join-Path $Office "logs"; New-Item -ItemType Directory -Force $Logs | Out-Null
$Log    = Join-Path $Logs ("start_" + (Get-Date -Format "yyyyMMdd") + ".log")
$env:PYTHONUTF8 = "1"
function Say($m) { $line = "[" + (Get-Date -Format "HH:mm:ss") + "] " + $m; Write-Host $line; Add-Content -Path $Log -Value $line -Encoding UTF8 }

Say "=== AIオフィス 起動 ==="
# ① 道具チェック（node は要らない・ネイティブ版 claude とプラグイン用 bun）
$env:Path = ((Join-Path $env:USERPROFILE ".local\bin"), (Join-Path $env:USERPROFILE ".bun\bin"), [Environment]::GetEnvironmentVariable("Path","Machine"), [Environment]::GetEnvironmentVariable("Path","User")) -join ";"
$need = @()
foreach ($t in @("python", "claude")) { if (-not (Get-Command $t -ErrorAction SilentlyContinue)) { $need += $t } }
if ($need.Count -gt 0) { Say ("足りない道具: " + ($need -join ", ") + " … セットアップの1行をもう一度貼り直してください"); exit 1 }
Say "道具OK: python / claude"

# ② bot トークン
if (-not (Test-Path $TokenF) -or -not (Select-String -Path $TokenF -Pattern "DISCORD_BOT_TOKEN=\S" -Quiet)) {
  Say "Discord bot のトークンがまだ入っていません。"
  Say "  1) bot を作る: $Skill\browser\create_bot_instruction.txt を Claude in Chrome に貼る（ログインと最後の認証だけ自分で押す）"
  Say "  2) これから開く Claude Code の画面で  /discord:configure  と打ってトークンを貼る"
  Say "  3) 続けて  /discord:access  で自分の Discord ユーザーIDを許可する"
  Say "  4) 終わったら Claude Code を閉じて、もう一度 起動.bat"
  Start-Process notepad.exe (Join-Path $Skill "browser\create_bot_instruction.txt")
  Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", "claude"
  Read-Host "Enter で閉じる"; exit
}
Say "bot トークンOK"

# ③ 名簿から部屋を一括作成（既存はスキップ）
$Roster = Join-Path $Office "社員名簿.txt"
$newRooms = 0
if (Test-Path $Roster) {
  $out = & python $Py hire-all --file $Roster 2>&1
  $out | ForEach-Object { Say ("  " + $_) }
  $m = ($out | Select-String -Pattern "^NEW=(\d+)")
  if ($m) { $newRooms = [int]$m.Matches[0].Groups[1].Value }
  if ($out -match "HTTP 403") { Say "★ bot の権限不足です。上の URL を開いて認証してから、もう一度 起動.bat"; Read-Host "Enter で閉じる"; exit }
} else { Say "社員名簿.txt が無いので部屋作成はスキップ" }

# ④ リンク一覧（常に書き出し・新しい部屋があった時だけ統括部屋に投稿）
& python $Py links --out $Office 2>&1 | ForEach-Object { Say ("  " + $_) }
if ($newRooms -gt 0) { & python $Py links --post hq 2>&1 | ForEach-Object { Say ("  " + $_) } }

# ⑤ Claude Code 起動（すでに Discord 付きで動いていれば起動しない）
$running = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" }
if ($running) { Say "Claude Code（Discord付き）はすでに動いています。二重起動しません。"; if (-not $NoLaunch) { Start-Sleep 3 }; exit }
if ($NoLaunch) { Say "（-NoLaunch のため起動はしない）"; exit }
$Work = Join-Path $env:USERPROFILE "Desktop"; if (-not (Test-Path $Work)) { $Work = $env:USERPROFILE }
# 初回の画面（テーマ選び・フォルダを信頼するか・全画面表示を試す？・Claude in Chrome を使う？）を先に済ませる＝無人の再起動でも止まらない
$CJ = Join-Path $env:USERPROFILE ".claude.json"
& python -c "import json,os,sys; p,w=sys.argv[1],sys.argv[2]; c=json.load(open(p,encoding='utf-8')) if os.path.exists(p) else {}; c['hasCompletedOnboarding']=True; c.setdefault('theme','dark'); c['fullscreenUpsellSeenCount']=max(99,c.get('fullscreenUpsellSeenCount',0)); c.setdefault('claudeInChromeDefaultEnabled',False); pr=c.setdefault('projects',{}); [pr.setdefault(k,{}).__setitem__('hasTrustDialogAccepted',True) for k in {w, w.replace(chr(92),'/')}]; json.dump(c,open(p,'w',encoding='utf-8'),ensure_ascii=False,indent=2)" $CJ $Work
$PromptF = Join-Path $Office "起動時の指示.txt"
$Launch = Join-Path $env:USERPROFILE ".claude\ai-office\launch_claude.ps1"; New-Item -ItemType Directory -Force (Split-Path $Launch) | Out-Null
$L = @(
  '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; [Console]::InputEncoding=[System.Text.Encoding]::UTF8; chcp 65001 | Out-Null',
  '$Host.UI.RawUI.WindowTitle = "AIオフィス 起動中（この窓は閉じない）"',
  ('$env:Path = "' + (Join-Path $env:USERPROFILE ".local\bin") + ';' + (Join-Path $env:USERPROFILE ".bun\bin") + ';" + $env:Path'),
  ("Set-Location '" + $Work + "'"),
  ("`$pf = '" + $PromptF + "'"),
  '$p = if (Test-Path $pf) { (Get-Content $pf -Raw -Encoding UTF8).Trim() } else { "" }',
  'if ($p) { claude $p --channels plugin:discord@claude-plugins-official } else { claude --channels plugin:discord@claude-plugins-official }'   # 指示文は --channels より前
)
[IO.File]::WriteAllText($Launch, ($L -join "`r`n") + "`r`n", (New-Object System.Text.UTF8Encoding($true)))
Start-Process powershell.exe -ArgumentList "-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$Launch`"" -WindowStyle Normal
Say "Claude Code を起動しました（Discord プラグイン付き）"

# ⑥ Codex 社員がいる場合の橋（config の codex_bridge_autostart が true のときだけ）
try { $cfg = Get-Content $Cfg -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $cfg = $null }
if ($cfg -and $cfg.codex_bridge_autostart -and $cfg.codex_dir -and (Test-Path (Join-Path $cfg.codex_dir "codex_bridge.py"))) {
  $cb = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "codex_bridge.py" }
  if (-not $cb) { Start-Process powershell.exe -ArgumentList "-NoExit", "-Command", "`$env:PYTHONUTF8='1'; Set-Location '$($cfg.codex_dir)'; python -u codex_bridge.py"; Say "codex_bridge.py を起動しました" }
}
Say "=== 起動 完了 ==="
Start-Sleep 3
