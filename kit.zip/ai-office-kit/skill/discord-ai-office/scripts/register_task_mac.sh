#!/bin/bash
# register_task_mac.sh — 定期再起動（1日に何回でも）と「返事の見張り」（5分おき）を launchd に登録する（Mac 用）
#   bash register_task_mac.sh ["04:00, 15:00"] [AIオフィス フォルダ]   /   bash register_task_mac.sh --remove
LABEL="com.aioffice.restart"; PL="$HOME/Library/LaunchAgents/$LABEL.plist"
WL="com.aioffice.watch"; WPL="$HOME/Library/LaunchAgents/$WL.plist"
SL="com.aioffice.start"; SPL="$HOME/Library/LaunchAgents/$SL.plist"
if [ "$1" = "--remove" ]; then launchctl unload "$PL" "$WPL" "$SPL" 2>/dev/null; rm -f "$PL" "$WPL" "$SPL"; echo "削除しました"; exit 0; fi
T="${1:-04:00}"; OFFICE="${2:-$HOME/Desktop/AIオフィス}"
T="$(/usr/bin/python3 -c "import sys,unicodedata;print(unicodedata.normalize('NFKC',sys.argv[1]))" "$T" 2>/dev/null || printf '%s' "$T")"   # 全角の「０４：００」も受ける
LOGS="$HOME/.claude/ai-office/logs"; mkdir -p "$LOGS"   # launchd からはデスクトップに書けないので、ログはここ
CAL=""; for t in $(echo "$T" | tr "，、, " "\n\n\n\n"); do [ -z "$t" ] && continue; H=$((10#${t%%:*})); M=$((10#${t##*:}))
  CAL="$CAL<dict><key>Hour</key><integer>$H</integer><key>Minute</key><integer>$M</integer></dict>"; done
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PL" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$HOME/.claude/skills/discord-ai-office/scripts/restart.sh</string><string>$OFFICE</string></array>
  <key>StartCalendarInterval</key><array>$CAL</array>
  <key>StandardOutPath</key><string>$LOGS/launchd.log</string><key>StandardErrorPath</key><string>$LOGS/launchd.log</string>
</dict></plist>
EOF
launchctl unload "$PL" 2>/dev/null; launchctl load "$PL" && echo "✓ 登録しました: 毎日 $T に 再起動"
cat > "$WPL" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$WL</string>
  <key>ProgramArguments</key><array><string>/usr/bin/python3</string><string>$HOME/.claude/skills/discord-ai-office/scripts/office.py</string><string>watch-replies</string></array>
  <key>EnvironmentVariables</key><dict><key>PYTHONUTF8</key><string>1</string></dict>
  <key>StartInterval</key><integer>300</integer>
  <key>StandardOutPath</key><string>$LOGS/watch.log</string><key>StandardErrorPath</key><string>$LOGS/watch.log</string>
</dict></plist>
EOF
launchctl unload "$WPL" 2>/dev/null; launchctl load "$WPL" && echo "✓ 返事の見張りを登録しました（5分おき）"
cat > "$SPL" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$SL</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$HOME/.claude/skills/discord-ai-office/scripts/start.sh</string><string>$OFFICE</string></array>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>$LOGS/login_start.log</string><key>StandardErrorPath</key><string>$LOGS/login_start.log</string>
</dict></plist>
EOF
launchctl unload "$SPL" 2>/dev/null; launchctl load "$SPL" && echo "✓ ログイン時の起動を登録しました（停電や OS 更新のあと、ログインすれば自動で立ち上がる）"
echo "※ Mac がスリープしていると動きません。システム設定 → ディスプレイ／バッテリー で「スリープしない」にしてください"
