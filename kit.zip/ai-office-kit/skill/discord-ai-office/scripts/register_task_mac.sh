#!/bin/bash
# register_task_mac.sh — 毎朝の定期再起動を launchd に登録する（Mac 用・1回だけ）
#   bash register_task_mac.sh [HH:MM=04:00] [AIオフィス フォルダ]   /   bash register_task_mac.sh --remove
LABEL="com.aioffice.restart"; PL="$HOME/Library/LaunchAgents/$LABEL.plist"
if [ "$1" = "--remove" ]; then launchctl unload "$PL" 2>/dev/null; rm -f "$PL"; echo "削除しました"; exit 0; fi
T="${1:-04:00}"; H=$((10#${T%%:*})); M=$((10#${T##*:})); OFFICE="${2:-$HOME/Desktop/AIオフィス}"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PL" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$HOME/.claude/skills/discord-ai-office/scripts/restart.sh</string><string>$OFFICE</string></array>
  <key>StartCalendarInterval</key><dict><key>Hour</key><integer>$H</integer><key>Minute</key><integer>$M</integer></dict>
  <key>StandardOutPath</key><string>$OFFICE/logs/launchd.log</string><key>StandardErrorPath</key><string>$OFFICE/logs/launchd.log</string>
</dict></plist>
EOF
launchctl unload "$PL" 2>/dev/null; launchctl load "$PL" && echo "✓ 登録しました: 毎日 $T に 再起動"
echo "※ Mac がスリープしていると動きません。システム設定 → ディスプレイ／バッテリー で「スリープしない」にしてください"
