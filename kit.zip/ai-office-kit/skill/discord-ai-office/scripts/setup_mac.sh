#!/bin/bash
# setup_mac.sh — AIオフィス まとめてセットアップ（Mac）。インストーラ（ターミナルに1行）から呼ばれる
#   bash setup_mac.sh <キットのフォルダ>
# 途中で止まっても、もう一度同じ1行で頭から通せる（入っているものは飛ばす）
KIT="$1"; SHEET="$KIT/設定シート.txt"
SK="$HOME/.claude/skills/discord-ai-office"; DESK="$HOME/Desktop/AIオフィス"
CH="$HOME/.claude/channels/discord"; LOGD="$DESK/logs"
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"; export PYTHONUTF8=1
printf '\033]0;AIオフィス セットアップ\007'
step() { echo ""; echo "━━ $* ━━"; }
fail() { echo ""; echo "✗ $*"; echo "（この画面のスクショを送ってください）"; exit 1; }
val() { grep -E "^[[:space:]]*$1[[:space:]]*=" "$SHEET" | head -1 | sed -E 's/^[^=]*=[[:space:]]*//; s/[[:space:]]+$//'; }
SERVER="$(val サーバー名)"; SERVER="${SERVER:-AIオフィス}"
BOT="$(val bot名)"; BOT="${BOT:-AI社員}"
RT="$(val 再起動の時刻)"; RT="${RT:-04:00}"

step "1/8 ファイルを置く"
mkdir -p "$HOME/.claude/skills"; rm -rf "$SK"; cp -R "$KIT/skill/discord-ai-office" "$SK"; chmod +x "$SK"/scripts/*.sh
[ -d "$DESK" ] || cp -R "$KIT/AIオフィス" "$DESK"; rm -f "$DESK"/*.bat; chmod +x "$DESK"/*.command;   # Mac では Windows 用 .bat は置かない
 mkdir -p "$LOGD"
sed -n '/^\[社員名簿\]/,$p' "$SHEET" | tail -n +2 > "$DESK/社員名簿.txt"
echo "✓ スキル・机の上の AIオフィス・社員名簿（$(grep -c '|' "$DESK/社員名簿.txt") 人）"

step "2/8 Python・git（Apple の開発ツール）"
if ! /usr/bin/python3 -c "print(1)" >/dev/null 2>&1; then
  echo "Apple の開発ツールを入れます。出てくる窓で「インストール」を押してください（10分ほど・終わるまでここで待ちます）"
  xcode-select --install 2>/dev/null
  for i in $(seq 1 120); do /usr/bin/python3 -c "print(1)" >/dev/null 2>&1 && break; sleep 15; done
  /usr/bin/python3 -c "print(1)" >/dev/null 2>&1 || fail "開発ツールが入りませんでした"
fi
PY=/usr/bin/python3; echo "✓ $($PY --version)・git $(git --version 2>/dev/null | awk '{print $3}')"

step "3/8 Claude Code（CLI 版）"
if ! command -v claude >/dev/null 2>&1; then
  echo "Claude Code を入れます（公式のインストーラ・1〜2分）"; curl -fsSL https://claude.ai/install.sh | bash >/dev/null 2>&1
  export PATH="$HOME/.local/bin:$PATH"
fi
command -v claude >/dev/null 2>&1 || fail "Claude Code が入りませんでした"
echo "✓ $(claude --version 2>/dev/null)"

step "4/8 Claude にログイン"
if [ -z "${AIO_TEST:-}" ] && ! claude auth status 2>/dev/null | grep -q '"loggedIn": *true'; then   # AIO_TEST＝作り手の動作確認用（ログインと画面を開くのを飛ばす）
  echo "ブラウザが開きます。いつもの Claude のアカウントでログイン →「承認」してください"
  claude auth login
  claude auth status 2>/dev/null | grep -q '"loggedIn": *true' || fail "ログインが確認できませんでした"
fi
echo "✓ ログイン済み"

step "5/8 Bun と Discord 連携（プラグイン）"
if ! command -v bun >/dev/null 2>&1; then curl -fsSL https://bun.sh/install | bash >/dev/null 2>&1; export PATH="$HOME/.bun/bin:$PATH"; fi
command -v bun >/dev/null 2>&1 || fail "Bun が入りませんでした"
claude plugin marketplace list 2>/dev/null | grep -q claude-plugins-official || claude plugin marketplace add anthropics/claude-plugins-official >/dev/null 2>&1
claude plugin install discord@claude-plugins-official >/dev/null 2>&1
claude plugin list 2>/dev/null | grep -q "discord@claude-plugins-official" || fail "Discord プラグインが入りませんでした"
echo "✓ Bun $(bun --version)・Discord プラグイン"

step "6/8 bot を作って招待（ここだけ Claude アプリの画面操作）"
mkdir -p "$CH"
if ! grep -q "DISCORD_BOT_TOKEN=." "$CH/.env" 2>/dev/null; then
  sed -e "s/{SERVER}/$SERVER/g" -e "s/{BOT}/$BOT/g" "$SK/browser/computer_use_setup.txt" | pbcopy
  RECOPY="$DESK/指示文をもう一度コピー.command"   # コピーが上書きされた時（iPhone でコピーすると Mac にも入る）用
  { echo '#!/bin/bash'; printf 'sed -e "s/{SERVER}/%s/g" -e "s/{BOT}/%s/g" "$HOME/.claude/skills/discord-ai-office/browser/computer_use_setup.txt" | pbcopy
' "$SERVER" "$BOT"; echo 'echo "指示文をコピーしました。Claude アプリの新しいチャットに ⌘V → 送信"'; } > "$RECOPY"; chmod +x "$RECOPY"
  drain() { while read -r -t 1 _; do :; done; }   # 間違って貼られた複数行を捨てる（流れ続けないように）
  echo ""
  echo "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
  echo "┃  ⚠ このターミナルには、何も貼らなくて大丈夫です                  ┃"
  echo "┃                                                              ┃"
  echo "┃  ① いま手前に出る「Claude」アプリで「新しいチャット」を開く      ┃"
  echo "┃  ② そこに ⌘V（指示文はもうコピーしてあります）→ 送信             ┃"
  echo "┃  ③ Claude が Discord の準備をします（認証ボタンだけ自分で押す）   ┃"
  echo "┃  ④ 最後に、画面に出たトークン（長い英数字）を自分でコピーする    ┃"
  echo "┃     マウスでドラッグ、または3回クリックで選んで ⌘C               ┃"
  echo "┃     （「コピー」ボタンは効かないことが多い）ここが自動で読み取る   ┃"
  echo "┃  ※ 作業中は iPhone でコピーしない（Mac のコピーに上書きされる）   ┃"
  echo "┃     上書きされたら 机の上 AIオフィス の「指示文をもう一度コピー」  ┃"
  echo "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
  echo "（サーバー名「${SERVER}」・bot「${BOT}」）"
  if [ -z "${AIO_TEST:-}" ]; then sleep 2; open -a "Claude" 2>/dev/null || open "https://claude.ai"; fi
  drain
  istok() { printf '%s' "$1" | grep -Eq '^[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{20,}$'; }
  tokok() { [ -n "${AIO_TEST:-}" ] && return 0; [ "$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bot $1" -H "User-Agent: DiscordBot (ai-office, 1.0)" https://discord.com/api/v10/users/@me)" = "200" ]; }
  TOKEN=""; WARNED=""; LASTCB="$(pbpaste 2>/dev/null | tr -d '[:space:]')"
  istok "$LASTCB" && tokok "$LASTCB" && LASTCB=""   # 前回の有効なトークンが残っていれば使う
  echo "トークンを待っています…（コピーすれば自動で読み取ります。ここに ⌘V → Enter でも OK）"
  T0=$(date +%s); N=0
  while [ -z "$TOKEN" ]; do
    CB="$(pbpaste 2>/dev/null | tr -d '[:space:]')"   # クリップボードを1秒ごとに見る
    if [ "$CB" != "$LASTCB" ]; then
      LASTCB="$CB"
      if istok "$CB"; then
        if tokok "$CB"; then TOKEN="$CB"; printf '' | pbcopy; echo "（コピーされたトークンを読み取りました）"; break
        else echo "⚠ コピーされたトークンでは Discord につながりませんでした。Bot の「Reset Token」でもう一度出してコピーしてください"; fi
      fi
    fi
    N=$((N+1)); [ $N -gt $(( ($(date +%s) - T0) * 3 + 20 )) ] && fail "入力が閉じられました（ターミナルを閉じた？）"   # bash 3.2 は時間切れも入力終わりも 1 を返す→回る速さで見分ける
    T=""; read -r -s -t 1 T || continue
    T="$(printf '%s' "$T" | tr -d '[:space:]')"; [ -z "$T" ] && continue
    if istok "$T"; then
      tokok "$T" && { TOKEN="$T"; break; }
      echo "⚠ このトークンでは Discord につながりませんでした。Bot の「Reset Token」でもう一度出してください"
    else
      drain; [ -z "$WARNED" ] && echo "⚠ それはトークンではありません。指示文は Claude アプリに貼ります（ここには貼らない）"; WARNED=1
    fi
  done
  T="$TOKEN"
  echo "✓ トークンを確認しました"
  # ユーザーID は聞かない: bot が入ったサーバーの「持ち主」を Discord から読む
  DUID=""
  for i in $(seq 1 45); do
    DUID=$($PY - "$T" <<'EOF'
import json, sys, urllib.request
t = sys.argv[1]
def g(u):
    r = urllib.request.Request("https://discord.com/api/v10" + u, headers={"Authorization": "Bot " + t, "User-Agent": "DiscordBot (ai-office, 1.0)"})
    return json.load(urllib.request.urlopen(r, timeout=15))
try:
    gs = g("/users/@me/guilds")
    if len(gs) >= 1: print(g("/guilds/" + gs[0]["id"])["owner_id"])
except Exception: pass
EOF
)
    [ -n "$DUID" ] && break
    [ -n "${AIO_TEST:-}" ] && { DUID="123456789012345678"; break; }
    [ $((i % 3)) -eq 1 ] && echo "  bot のサーバー参加を待っています…（招待の「認証」まで進めてください）"; sleep 20
  done
  [ -n "$DUID" ] || fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）"
  echo "✓ サーバーの持ち主を確認しました（あなたのID: ${DUID}）"
  umask 077; printf 'DISCORD_BOT_TOKEN=%s\n' "$TOKEN" > "$CH/.env"; chmod 600 "$CH/.env"; unset TOKEN
  $PY - "$CH/access.json" "$DUID" <<'EOF'
import json, os, sys
p, uid = sys.argv[1], sys.argv[2].strip()
a = json.load(open(p)) if os.path.exists(p) else {}
a["dmPolicy"] = "allowlist"; a.setdefault("allowFrom", []); a.setdefault("groups", {}); a.setdefault("pending", {})
if uid and uid not in a["allowFrom"]: a["allowFrom"].append(uid)
json.dump(a, open(p, "w"), ensure_ascii=False, indent=2)
EOF
  echo "✓ トークンと許可を保存しました"
else
  echo "✓ bot トークンは設定済み"
fi
BOTNAME=$($PY "$SK/scripts/office.py" whoami 2>&1 | head -1)
echo "$BOTNAME" | grep -q "^bot:" || fail "トークンで Discord につながりませんでした（${BOTNAME}）"
echo "✓ $BOTNAME"

step "7/8 部屋と社員を作る"
CM="$HOME/.claude/CLAUDE.md"; grep -q "discord-ai-office スキル" "$CM" 2>/dev/null || { printf "\n" >> "$CM"; cat "$SK/templates/CLAUDE_snippet.md" >> "$CM"; }
for i in $(seq 1 30); do   # bot の招待が終わるまで待つ（サーバーに入っていないと部屋を作れない）
  [ "$($PY "$SK/scripts/office.py" whoami 2>/dev/null | grep -c '^guild:')" -ge 1 ] && break
  [ $((i % 3)) -eq 1 ] && echo "  bot のサーバー参加を待っています…（Claude アプリで招待の「認証」まで進めてください）"; sleep 20
done
[ "$($PY "$SK/scripts/office.py" whoami 2>/dev/null | grep -c '^guild:')" -ge 1 ] || fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）"
OUT=$($PY "$SK/scripts/office.py" hire-all --file "$DESK/社員名簿.txt" 2>&1)
echo "$OUT" | grep -q "HTTP 403" && { echo "$OUT" | tail -4; fail "bot の権限が足りません。上の URL を開いて「認証」してから、もう一度同じ1行"; }
echo "$OUT" | grep -q "^NEW=" || { echo "$OUT" | tail -6; fail "部屋を作れませんでした"; }
$PY "$SK/scripts/office.py" links --out "$DESK" --post hq >/dev/null 2>&1 || fail "リンク一覧を送れませんでした"
echo "✓ 部屋 $(grep -c '|' "$DESK/社員名簿.txt") つ・統括の部屋に部屋ごとのリンクを送りました"

step "8/8 毎朝の再起動を入れて、起動"
bash "$SK/scripts/register_task_mac.sh" "$RT" "$DESK" </dev/null 2>&1 | grep "登録しました" || fail "毎朝の再起動を登録できませんでした"
bash "$SK/scripts/start.sh" "$DESK" </dev/null > "$LOGD/setup_start.log" 2>&1   # 質問が出ても待たない（入力なし＝すぐ抜ける）
grep -q "Claude Code を起動しました\|すでに動いています" "$LOGD/setup_start.log" || { tail -5 "$LOGD/setup_start.log"; fail "Claude を起動できませんでした"; }
OK=1; for i in $(seq 1 15); do sleep 2; pgrep -f "claude.*--channels" >/dev/null || OK=""; done   # 30秒動き続けているか
[ -n "$OK" ] || fail "Claude が起動してすぐ止まりました（新しく開いたターミナルの窓の赤い文字をスクショしてください）"
echo "✓ Claude を起動しました（新しいターミナルの窓・30秒動作を確認）"
echo ""
echo "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊"
echo ""
echo "      🎉  Congratulations!  セットアップ完了です  🎉"
echo ""
echo "  AIオフィスが完成しました。このまま使えます。"
echo ""
echo "  ▶ 次にあなたがすること"
echo "    スマホの Discord で「秘書」の部屋に「テスト」と送ってみてください。"
echo "    返事が来たら、もう社員が働いています 🙌"
echo ""
echo "  ・このウィンドウは閉じて大丈夫です（Claude は別の窓で動いています）"
echo "  ・Claude が動いている窓は閉じないでください"
echo "  ・パソコンは電源につないで、スリープしない設定にしておいてください"
echo ""
echo "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊"
