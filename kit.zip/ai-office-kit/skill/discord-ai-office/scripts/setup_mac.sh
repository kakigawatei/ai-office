#!/bin/bash
# setup_mac.sh — AIオフィス まとめてセットアップ（Mac）。インストーラ（ターミナルに1行）から呼ばれる
#   bash setup_mac.sh <キットのフォルダ>
# 途中で止まっても、もう一度同じ1行で頭から通せる（入っているものは飛ばす）
KIT="$1"; SHEET="$KIT/設定シート.txt"
SK="$HOME/.claude/skills/discord-ai-office"; DESK="$HOME/Desktop/AIオフィス"
CH="$HOME/.claude/channels/discord"; LOGD="$DESK/logs"
aio_pg() { LC_ALL=C pgrep -U "$(id -u)" -f "claude.*--channels" >/dev/null 2>&1; [ $? -ne 1 ]; }   # Discord 付き Claude が動いているか。日本語の環境だと pgrep が読めずに失敗する（起動時の指示の日本語）→ LC_ALL=C。失敗（終了コード 2 以上）は「わからない＝動いている扱い」にして、二重起動や「立ち上がりませんでした」の誤報を出さない（v1.6 開発くんの試し その2）
aio_kill() { LC_ALL=C pkill "$@" -U "$(id -u)" -f "claude.*--channels" >/dev/null 2>&1; }
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"; export PYTHONUTF8=1
printf '\033]0;AIオフィス セットアップ\007'
step() { echo ""; echo "━━ $* ━━"; }
fail() { echo ""; echo "✗ $*"; echo "（この画面のスクショを送ってください）"
  if [ -n "${BZ:-}" ]; then echo "  更新の直前に戻すには: デスクトップの AIオフィス の「戻す」をダブルクリック →「更新の直前」（控え: ${BZ}）"
  elif [ -f "$HOME/.claude/ai-office/preinstall/info.txt" ] && [ -f "$SK/scripts/office.py" ]; then echo "  入れる前に戻すには: デスクトップの AIオフィス の「やめる」をダブルクリック（入れる前の控えを見て、キットが足した分だけを外します）"; fi
  exit 1; }
val() { grep -E "^[[:space:]]*$1[[:space:]]*=" "$SHEET" | head -1 | sed -E 's/^[^=]*=[[:space:]]*//; s/[[:space:]]+$//'; }
SERVER="$(val サーバー名)"; SERVER="${SERVER:-AIオフィス}"
BOT="$(val bot名)"; BOT="${BOT:-AI社員}"
RT="$(val 再起動の時刻)"; RT="${RT:-04:00}"
MODEL="$(val モデル)"; MODEL="${MODEL:-auto}"; EFFORT="$(val 考える深さ)"; EFFORT="${EFFORT:-high}"
NOTICE="$(val お知らせ部屋)"   # C1 2026-09-30: 「なし」なら hire-all に --no-notice-room を渡す（既定＝作る）
USAGENICK="$(val 使用量を名前に)"   # C4 2026-09-30: 「なし」なら usage --nick off を呼ぶ（既定＝あり）

step "1/8 ファイルを置く"
PRE="$HOME/.claude/ai-office/preinstall"
if [ ! -d "$SK" ] && [ ! -f "$PRE/info.txt" ]; then   # 最初に入れる前の控え（1回だけ・上書きしない）。「やめる」はこれを見て、入れる前からあった物を残しキットが足した分だけを外す。Python が無い PC でも取れるようシェルだけで（2026-10-02 テスター向け・office.py preinstall と同じ形）
  mkdir -p "$HOME/.claude/ai-office" && mkdir -p -m 700 "$PRE"
  {
    echo "at=$(date '+%Y-%m-%d %H:%M:%S')"; echo "by=setup_mac.sh"
    for pair in "CLAUDE.md:$HOME/.claude/CLAUDE.md" "settings.json:$HOME/.claude/settings.json" "access.json:$CH/access.json" \
                "installed_plugins.json:$HOME/.claude/plugins/installed_plugins.json" "known_marketplaces.json:$HOME/.claude/plugins/known_marketplaces.json"; do
      n="${pair%%:*}"; s="${pair#*:}"
      if [ -f "$s" ]; then cp -p "$s" "$PRE/$n" && echo "had_$n=1"; else echo "had_$n=0"; fi
    done
    [ -f "$CH/.env" ] && echo "had_env=1" || echo "had_env=0"
    command -v claude >/dev/null 2>&1 && echo "had_claude_cli=1" || echo "had_claude_cli=0"
    command -v bun >/dev/null 2>&1 && echo "had_bun=1" || echo "had_bun=0"
    echo "had_kit=0"
    echo "skills=$(ls -1 "$HOME/.claude/skills" 2>/dev/null | tr '\n' ',' | sed 's/,$//')"
  } > "$PRE/info.txt.tmp"
  : > "$PRE/history.txt"; [ -d "$HOME/.claude/projects" ] && find "$HOME/.claude/projects" -type f -name '*.jsonl' -exec stat -f '%m %z %N' {} + 2>/dev/null | sed "s#^\([0-9]* [0-9]*\) $HOME/#\1 #" > "$PRE/history.txt"   # 会話の履歴は一覧だけ（中身は写さない）
  mv "$PRE/info.txt.tmp" "$PRE/info.txt" && echo "✓ 入れる前の控え: ${PRE}（会話の履歴 $(grep -c . "$PRE/history.txt") 件を記録。やめるときは、これを見て入れる前に戻します）"
fi
mkdir -p "$HOME/.claude/skills"
BK=""; BZ=""
PY0="$(command -v python3 2>/dev/null || echo /usr/bin/python3)"   # 手順2より前に使う（v1.6: ここで $PY が空のまま manifest diff を呼び、改造の検出が動いていなかった）
NEWPY="$KIT/skill/discord-ai-office/scripts/office.py"
if [ -d "$SK" ]; then   # 更新: ①全体の控え（戻す用）②前のスキルを丸ごと控える（5世代）③持ち主が変えていたファイルを見つけたら、上書きの前に止まって聞く（v1.6 momomon R-1）
  BZ="$("$PY0" "$NEWPY" backup --tag before-update --skill "$SK" --desk "$DESK" 2>/dev/null | sed -n 's/^BACKUP=//p')"
  if [ -n "$BZ" ]; then echo "✓ 更新の前の控え: ${BZ}（困ったらデスクトップの AIオフィス の「戻す」で戻せます）"; else echo "⚠ 更新の前の全体の控えを取れませんでした（スキルの控えは取ります）"; fi
  BK="$HOME/.claude/ai-office/backups/skill_$(date +%Y%m%d_%H%M)"; mkdir -p "$HOME/.claude/ai-office/backups"; cp -R "$SK" "$BK"
  ls -dt "$HOME/.claude/ai-office/backups"/skill_* 2>/dev/null | tail -n +6 | xargs rm -rf 2>/dev/null
  [ -f "$HOME/.claude/CLAUDE.md" ] && cp "$HOME/.claude/CLAUDE.md" "$BK/CLAUDE.md.before"   # 決まりの違い（R-4）を更新の報告に出すため
  "$PY0" "$NEWPY" manifest diff --dir "$SK" --out "$BK/CHANGED.txt" 2>/dev/null | grep -v "^CHANGED=" ; :
  if [ -s "$BK/CHANGED.txt" ]; then
    echo ""; echo "⚠ 前の版で、あなたが変えていたキットのファイルがあります。更新すると新しい版で置き換わります（控え: ${BK}）:"; sed 's/^/   /' "$BK/CHANGED.txt"
    echo "   残したい直しは ~/.claude/ai-office/local/ に移すと、更新で消えません（統括に「local に移して」と頼めます）"
    if [ "${AIOFFICE_FORCE:-}" != "1" ]; then
      ANS=""; { read -r -p "このまま置き換えて更新するなら「はい」と打って Enter（やめるならそのまま Enter）: " ANS </dev/tty; } 2>/dev/null
      case "$ANS" in
        はい|hai|y|Y|yes) echo "  → 置き換えて続けます（控えはあります）";;
        *) "$PY0" "$SK/scripts/office.py" notice "⚠️ 更新を止めました: あなたが変えていたキットのファイルが $(grep -c . "$BK/CHANGED.txt") 件あります（控え: ${BK}）。直しを local/ に移すか、置き換えてよければもう一度更新して「はい」" >/dev/null 2>&1
           echo ""; echo "更新をやめました。何も変えていません。直しを local/ に移してから、もう一度同じ1行で更新してください"; echo "（置き換えてよいときは、1行の前に AIOFFICE_FORCE=1 を付けても進めます）"; exit 0;;
      esac
    fi
  fi
fi
rm -rf "$SK.new"   # 新しい版を横に置いてから差し替える（v1.6 までは先に消していた＝写す途中で失敗すると空になった）
cp -R "$KIT/skill/discord-ai-office" "$SK.new" && [ -f "$SK.new/scripts/office.py" ] && [ -f "$SK.new/VERSION" ] || { rm -rf "$SK.new"; fail "新しい版を置けませんでした（空き容量・権限）。前の版はそのまま残っています"; }
if [ -d "$SK" ]; then mv "$SK" "$SK.old.$$" || { rm -rf "$SK.new"; fail "前の版を差し替えられませんでした。前の版はそのまま残っています"; }; fi
mv "$SK.new" "$SK" || { [ -d "$SK.old.$$" ] && mv "$SK.old.$$" "$SK"; fail "新しい版に差し替えられませんでした。前の版に戻しました"; }
rm -rf "$SK.old.$$"; chmod +x "$SK"/scripts/*.sh
for d in "$KIT"/skill/*/; do   # 同梱スキル（例 invoice-inbox）: 無いときだけ入れる。使っているうちに育てた自分の版は上書きしない（2026-10-01）
  n="$(basename "$d")"; [ "$n" = "discord-ai-office" ] && continue
  if [ -d "$HOME/.claude/skills/$n" ]; then echo "  同梱スキル $n はもう入っています（あなたの版を残しました。新しい版は ${d}）"
  else cp -R "$d" "$HOME/.claude/skills/$n"; echo "  ✓ 同梱スキル $n を入れました"; fi
done
[ -d "$DESK" ] || cp -R "$KIT/AIオフィス" "$DESK"; rm -f "$DESK"/*.bat; chmod +x "$DESK"/*.command;   # Mac では Windows 用 .bat は置かない
for f in "お休み.command" "やめる.command" "戻す.command"; do cp "$KIT/AIオフィス/$f" "$DESK/$f"; chmod +x "$DESK/$f"; done   # あとから足したボタン
for f in "起動時の指示.txt" "Discordで開発する使い方.txt"; do   # キット側の説明は毎回新しくする（前のは .bak）
  [ -f "$DESK/$f" ] && ! cmp -s "$KIT/AIオフィス/$f" "$DESK/$f" && { cp "$DESK/$f" "$DESK/$f.bak"; cp "$DESK/$f" "$DESK/$f.bak_$(date +%Y%m%d_%H%M)"; }; cp "$KIT/AIオフィス/$f" "$DESK/$f"; done   # 前のものは .bak（最新）と日付つきの両方で残す
 mkdir -p "$LOGD"
# 社員名簿: デスクトップの名簿を自分で直している人（キットの初期値と違う）は残す。初回や初期値のままなら設定シートから作る
if [ ! -f "$DESK/社員名簿.txt" ] || cmp -s "$KIT/AIオフィス/社員名簿.txt" "$DESK/社員名簿.txt"; then sed -n '/^\[社員名簿\]/,$p' "$SHEET" | tail -n +2 > "$DESK/社員名簿.txt"; fi
# モデル設定: 初回だけ設定シートから作る。2回目以降はこのファイルが正（スマホからの切替や自分で足した行を消さない）
MF="$DESK/モデル設定.txt"
[ -f "$MF" ] || printf "# model=auto は公開ページの推奨モデルに自動で追随（opus / sonnet などと書けば固定）。permission=auto は確認を減らす auto mode（毎回確認は manual）\nmodel=%s\neffort=%s\npermission=auto\n" "$MODEL" "$EFFORT" > "$MF"
echo "✓ スキル・デスクトップの AIオフィス・社員名簿（$(grep -c '|' "$DESK/社員名簿.txt") 人）"

step "2/8 Python・git（Apple の開発ツール）"
if ! /usr/bin/python3 -c "print(1)" >/dev/null 2>&1; then
  echo "Apple の開発ツールを入れます。出てくる窓で「インストール」を押してください（10分ほど・終わるまでここで待ちます）"
  xcode-select --install 2>/dev/null
  for i in $(seq 1 120); do /usr/bin/python3 -c "print(1)" >/dev/null 2>&1 && break; sleep 15; done
  /usr/bin/python3 -c "print(1)" >/dev/null 2>&1 || fail "開発ツールが入りませんでした"
fi
PY=/usr/bin/python3; echo "✓ $($PY --version)・git $(git --version 2>/dev/null | awk '{print $3}')"

step "3/8 Claude Code（CLI 版）"
if ! command -v claude >/dev/null 2>&1; then
  echo "Claude Code を入れます（公式のインストーラ・1〜2分）"; curl -fsSL https://claude.ai/install.sh | bash >/dev/null 2>&1
  export PATH="$HOME/.local/bin:$PATH"
fi
command -v claude >/dev/null 2>&1 || fail "Claude Code が入りませんでした"
echo "✓ $(claude --version 2>/dev/null)"

step "4/8 Claude にログイン"
if [ -z "${AIO_TEST:-}" ] && ! claude auth status 2>/dev/null | grep -q '"loggedIn": *true'; then   # AIO_TEST＝作り手の動作確認用（ログインと画面を開くのを飛ばす）
  echo "ブラウザが開きます。いつもの Claude のアカウントでログイン →「承認」してください"
  claude auth login
  claude auth status 2>/dev/null | grep -q '"loggedIn": *true' || fail "ログインが確認できませんでした"
fi
echo "✓ ログイン済み"

step "5/8 Bun と Discord 連携（プラグイン）"
if ! command -v bun >/dev/null 2>&1; then curl -fsSL https://bun.sh/install | bash >/dev/null 2>&1; export PATH="$HOME/.bun/bin:$PATH"; fi
command -v bun >/dev/null 2>&1 || fail "Bun が入りませんでした"
claude plugin marketplace list 2>/dev/null | grep -q claude-plugins-official || claude plugin marketplace add anthropics/claude-plugins-official >/dev/null 2>&1
claude plugin install discord@claude-plugins-official >/dev/null 2>&1
claude plugin list 2>/dev/null | grep -q "discord@claude-plugins-official" || fail "Discord プラグインが入りませんでした"
echo "✓ Bun $(bun --version)・Discord プラグイン"

step "6/8 bot を作って招待（ここだけ Claude アプリの画面操作）"
mkdir -p "$CH"
have_token() { grep -q "DISCORD_BOT_TOKEN=." "$CH/.env" 2>/dev/null || security find-generic-password -s ai-office-discord -w >/dev/null 2>&1; }   # .env かキーチェーン（B5①）
if [ -z "${AIO_TEST:-}" ] && have_token; then   # 保存済みのトークンが死んでいたら作り直す（ネットの不調では消さない）
  OLDC=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bot $($PY "$SK/scripts/office.py" token get 2>/dev/null)" -H "User-Agent: DiscordBot (ai-office, 1.0)" https://discord.com/api/v10/users/@me)
  [ "$OLDC" = "401" ] && { echo "⚠ 保存されていたトークンが使えなくなっていたので、bot の準備からやり直します"; mv -f "$CH/.env" "$CH/.env.old" 2>/dev/null; security delete-generic-password -s ai-office-discord >/dev/null 2>&1; }
fi
if ! have_token; then
  sed -e "s/{SERVER}/$SERVER/g" -e "s/{BOT}/$BOT/g" "$SK/browser/computer_use_setup.txt" | pbcopy
  RECOPY="$DESK/指示文をもう一度コピー.command"   # コピーが上書きされた時（iPhone でコピーすると Mac にも入る）用
  { echo '#!/bin/bash'; printf 'sed -e "s/{SERVER}/%s/g" -e "s/{BOT}/%s/g" "$HOME/.claude/skills/discord-ai-office/browser/computer_use_setup.txt" | pbcopy
' "$SERVER" "$BOT"; echo 'echo "指示文をコピーしました。Claude アプリの新しいチャットに ⌘V → 送信"'; } > "$RECOPY"; chmod +x "$RECOPY"
  drain() { while read -r -t 1 _; do :; done; }   # 間違って貼られた複数行を捨てる（流れ続けないように）
  echo ""
  echo "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
  echo "┃  ⚠ このターミナルには、何も貼らなくて大丈夫です                  ┃"
  echo "┃                                                              ┃"
  echo "┃  ① いま手前に出る「Claude」アプリで「新しいチャット」を開く      ┃"
  echo "┃  ② そこに ⌘V（指示文はもうコピーしてあります）→ 送信             ┃"
  echo "┃  ③ Claude が Discord の準備をします（認証ボタンだけ自分で押す）   ┃"
  echo "┃  ④ 最後に、画面に出たトークン（長い英数字）を自分でコピーする    ┃"
  echo "┃     マウスでドラッグ、または3回クリックで選んで ⌘C               ┃"
  echo "┃     （「コピー」ボタンは効かないことが多い）ここが自動で読み取る   ┃"
  echo "┃  ※ 作業中は iPhone でコピーしない（Mac のコピーに上書きされる）   ┃"
  echo "┃     上書きされたら デスクトップ AIオフィス の「指示文をもう一度コピー」  ┃"
  echo "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
  echo "（サーバー名「${SERVER}」・bot「${BOT}」）"
  if [ -z "${AIO_TEST:-}" ]; then sleep 2; open -a "Claude" 2>/dev/null || open "https://claude.ai"; fi
  drain
  istok() { printf '%s' "$1" | grep -Eq '^[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{20,}$'; }
  tokok() { [ -n "${AIO_TEST:-}" ] && return 0; [ "$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bot $1" -H "User-Agent: DiscordBot (ai-office, 1.0)" https://discord.com/api/v10/users/@me)" = "200" ]; }
  TOKEN=""; WARNED=""; LASTCB="$(pbpaste 2>/dev/null | tr -d '[:space:]')"
  istok "$LASTCB" && tokok "$LASTCB" && LASTCB=""   # 前回の有効なトークンが残っていれば使う
  echo "トークンを待っています…（コピーすれば自動で読み取ります。ここに ⌘V → Enter でも OK）"
  T0=$(date +%s); N=0
  while [ -z "$TOKEN" ]; do
    CB="$(pbpaste 2>/dev/null | tr -d '[:space:]')"   # クリップボードを1秒ごとに見る
    if [ "$CB" != "$LASTCB" ]; then
      LASTCB="$CB"
      if istok "$CB"; then
        if tokok "$CB"; then TOKEN="$CB"; printf '' | pbcopy; echo "（コピーされたトークンを読み取りました）"; break
        else echo "⚠ コピーされたトークンでは Discord につながりませんでした。Bot の「Reset Token」でもう一度出してコピーしてください"; fi
      fi
    fi
    N=$((N+1)); [ $N -gt $(( ($(date +%s) - T0) * 3 + 20 )) ] && fail "入力が閉じられました（ターミナルを閉じた？）"   # bash 3.2 は時間切れも入力終わりも 1 を返す→回る速さで見分ける
    T=""; read -r -s -t 1 T || continue
    T="$(printf '%s' "$T" | tr -d '[:space:]')"; [ -z "$T" ] && continue
    if istok "$T"; then
      tokok "$T" && { TOKEN="$T"; break; }
      echo "⚠ このトークンでは Discord につながりませんでした。Bot の「Reset Token」でもう一度出してください"
    else
      drain; [ -z "$WARNED" ] && echo "⚠ それはトークンではありません。指示文は Claude アプリに貼ります（ここには貼らない）"; WARNED=1
    fi
  done
  T="$TOKEN"
  echo "✓ トークンを確認しました"
  # ユーザーID は聞かない: bot が入ったサーバーの「持ち主」を Discord から読む
  DUID=""
  for i in $(seq 1 45); do
    DUID=$($PY - "$T" "$SERVER" <<'EOF'
import json, sys, urllib.request
t = sys.argv[1]; server = sys.argv[2] if len(sys.argv) > 2 else ""
def g(u):
    r = urllib.request.Request("https://discord.com/api/v10" + u, headers={"Authorization": "Bot " + t, "User-Agent": "DiscordBot (ai-office, 1.0)"})
    return json.load(urllib.request.urlopen(r, timeout=15))
try:
    gs = g("/users/@me/guilds")
    hit = [x for x in gs if x.get("name") == server]   # 設定シートのサーバー名で照合（別のサーバーにも入っていると違う人が持ち主になる・監査 小）
    if not hit and len(gs) == 1: hit = gs
    if hit: print(g("/guilds/" + hit[0]["id"])["owner_id"])
    elif len(gs) > 1: sys.stderr.write("bot は %d 個のサーバーに入っていますが、設定シートの「%s」が見つかりません\n" % (len(gs), server))
except Exception: pass
EOF
)
    [ -n "$DUID" ] && break
    [ -n "${AIO_TEST:-}" ] && { DUID="123456789012345678"; break; }
    [ $((i % 3)) -eq 1 ] && echo "  bot のサーバー参加を待っています…（招待の「認証」まで進めてください）"; sleep 20
  done
  [ -n "$DUID" ] || fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）"
  echo "✓ サーバーの持ち主を確認しました（あなたのID: ${DUID}）"
  umask 077; printf 'DISCORD_BOT_TOKEN=%s\n' "$TOKEN" > "$CH/.env"; chmod 600 "$CH/.env"; unset TOKEN
  $PY - "$CH/access.json" "$DUID" <<'EOF'
import json, os, sys
p, uid = sys.argv[1], sys.argv[2].strip()
a = json.load(open(p)) if os.path.exists(p) else {}
a["dmPolicy"] = "allowlist"; a.setdefault("allowFrom", []); a.setdefault("groups", {}); a.setdefault("pending", {})
if uid and uid not in a["allowFrom"]: a["allowFrom"].append(uid)
json.dump(a, open(p, "w"), ensure_ascii=False, indent=2)
EOF
  echo "✓ トークンと許可を保存しました"
else
  echo "✓ bot トークンは設定済み"
fi
BOTNAME=$($PY "$SK/scripts/office.py" whoami 2>&1 | head -1)
echo "$BOTNAME" | grep -q "^bot:" || fail "トークンで Discord につながりませんでした（${BOTNAME}）"
echo "✓ $BOTNAME"

step "7/8 部屋と社員を作る"
$PY "$SK/scripts/office.py" snippet-install 2>&1 | grep -v "^SNIPPET=" ; :
[ -d "$HOME/.claude/ai-office/local" ] && { echo "✓ 持ち主の置き場（更新で触らない）:"; $PY "$SK/scripts/office.py" local status 2>&1 | grep -v "^LOCAL=" ; :; }
$PY "$SK/scripts/office.py" guard rehash 2>&1 | grep -v "^GUARD_VERIFY=" ; :
$PY "$SK/scripts/office.py" version --announce 2>&1 | sed -n "s/^AIオフィス /  ✓ 版: /p" ; :   # 更新が入っていればお知らせの部屋に ⬆️（Q34）
[ -z "${AIO_TEST:-}" ] && [ "${AIOFFICE_TOKEN_PROTECT:-}" = "1" ] && { $PY "$SK/scripts/office.py" token protect 2>&1 | grep -v "^TOKEN_STORE=" ; :; }   # [B5①] トークンをキーチェーンへ（.env から消す）。実機で env 渡しの接続を確かめるまでは手動（office.py token protect）・自動化は次の版   # 更新で本体が変わったので、見張りの合図を取り直す   # CLAUDE.md の作法ブロックを今の版に（更新でも新しい決まりが届く）
for i in $(seq 1 30); do   # bot の招待が終わるまで待つ（サーバーに入っていないと部屋を作れない）
  [ "$($PY "$SK/scripts/office.py" whoami 2>/dev/null | grep -c '^guild:')" -ge 1 ] && break
  [ $((i % 3)) -eq 1 ] && echo "  bot のサーバー参加を待っています…（Claude アプリで招待の「認証」まで進めてください）"; sleep 20
done
[ "$($PY "$SK/scripts/office.py" whoami 2>/dev/null | grep -c '^guild:')" -ge 1 ] || fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）"
NOARG=""; [ "$NOTICE" = "なし" ] && NOARG="--no-notice-room"
OUT=$($PY "$SK/scripts/office.py" hire-all --file "$DESK/社員名簿.txt" $NOARG 2>&1)
echo "$OUT" | grep -q "HTTP 403" && { echo "$OUT" | tail -4; fail "bot の権限が足りません。上の URL を開いて「認証」してから、もう一度同じ1行"; }
echo "$OUT" | grep -q "^NEW=" || { echo "$OUT" | tail -6; fail "部屋を作れませんでした"; }
NEWN="$(echo "$OUT" | sed -n 's/^NEW=//p' | tail -1)"
if [ -z "$BK" ] || [ "${NEWN:-0}" != "0" ]; then   # リンク一覧を統括に送るのは、最初に入れたときと部屋が増えたときだけ（更新のたびに10通流れていた・開発くんの試し B）
  $PY "$SK/scripts/office.py" links --out "$DESK" --post hq >/dev/null 2>&1 || fail "リンク一覧を送れませんでした"
  echo "✓ 部屋 $(grep -c '|' "$DESK/社員名簿.txt") つ・統括の部屋に部屋ごとのリンクを送りました"
else
  $PY "$SK/scripts/office.py" links --out "$DESK" >/dev/null 2>&1; echo "✓ 部屋 $(grep -c '|' "$DESK/社員名簿.txt") つ（増えた部屋なし・リンク一覧はデスクトップの links.html）"
fi
if [ -n "$BK" ]; then   # 何が変わったか（上書きした直し・決まりの違い・フック）。Discord につながるのを確かめてから送る（v1.6 は手順7の頭で送って届かなかった）
  RP="$($PY "$SK/scripts/office.py" update-report --bk "$BK" --zip "$BZ" --out "$DESK" --post 2>&1)"
  echo "$RP" | sed -n 's/^REPORT=/  ✓ 更新の報告: /p'
  echo "$RP" | grep -q "^REPORT_POST=failed" && echo "  ⚠ 統括に ⚠️ を送れませんでした。デスクトップの AIオフィス/更新の報告.txt を読んでください"
fi
[ "$USAGENICK" = "なし" ] && { $PY "$SK/scripts/office.py" usage --nick off 2>&1 | tail -1 ; :; }   # C4 2026-09-30

step "8/8 毎朝の再起動を入れて、起動"
bash "$SK/scripts/register_task_mac.sh" "$RT" "$DESK" </dev/null 2>&1 | grep "登録しました" || fail "毎朝の再起動を登録できませんでした"
if aio_pg; then
  if [ -n "${CLAUDECODE:-}" ]; then echo "⚠ Claude の中から実行しているので止めません。あとでデスクトップの「再起動」をダブルクリックすると新しい版で動きます"
  else echo "  動いている Claude を止めて、新しい版で起動し直します"; aio_kill; for i in $(seq 1 20); do aio_pg || break; sleep 1; done; aio_pg && aio_kill -9; sleep 2; fi
fi
bash "$SK/scripts/start.sh" "$DESK" </dev/null > "$LOGD/setup_start.log" 2>&1   # 質問が出ても待たない（入力なし＝すぐ抜ける）
grep -q "Claude Code を起動しました\|すでに動いています" "$LOGD/setup_start.log" || { tail -5 "$LOGD/setup_start.log"; fail "Claude を起動できませんでした"; }
OK=1; for i in $(seq 1 15); do sleep 2; aio_pg || OK=""; done   # 30秒動き続けているか
[ -n "$OK" ] || fail "Claude が起動してすぐ止まりました（新しく開いたターミナルの窓の赤い文字をスクショしてください）"
echo "✓ Claude を起動しました（新しいターミナルの窓・30秒動作を確認）"
step "健康診断"
DR="$($PY "$SK/scripts/office.py" doctor --net 2>&1)"; echo "$DR" | grep -v "^DOCTOR="
if ! echo "$DR" | grep -q "^DOCTOR=ok"; then
  if [ -n "$BZ" ] && [ -z "${AIO_TEST:-}" ]; then   # 更新の後に問題があれば、更新の直前に戻すかを聞く（勝手には戻さない）
    ANS=""; { read -r -p "更新の直前に戻しますか？ 戻すなら「はい」と打って Enter（このまま使うならそのまま Enter）: " ANS </dev/tty; } 2>/dev/null
    case "$ANS" in はい|hai|y|Y|yes) $PY "$SK/scripts/office.py" restore "$BZ" --yes; exit 0;; esac
    echo "  このまま進めます。あとで戻すときはデスクトップの AIオフィス の「戻す」→「更新の直前」"
  else
    echo "  ✗ の行をスクショして送ってください。入れる前に戻すときはデスクトップの AIオフィス の「やめる」"
  fi
fi
TROOM=$($PY "$SK/scripts/office.py" test-room --file "$DESK/社員名簿.txt" 2>/dev/null | tail -1); TROOM="${TROOM:-統括}"   # 名簿の2人目（統括の次）の部屋
NCAND=$($PY "$SK/scripts/office.py" migrate --out "$DESK" 2>/dev/null | sed -n 's/^CANDIDATES=//p'); NCAND="${NCAND:-0}"   # 引き継ぎ診断（読むだけ・失敗しても先へ）
echo ""
echo "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊"
echo ""
echo "      🎉  Congratulations!  セットアップ完了です  🎉"
echo ""
echo "  AIオフィスが完成しました。このまま使えます。"
echo ""
echo "  ▶ 次にあなたがすること"
echo "    スマホの Discord で「${TROOM}」の部屋に「テスト」と送ってみてください。"
echo "    返事が来たら、もう社員が働いています 🙌"
echo ""
echo "  ・🔐 最後に1つだけ（大事）: Discord の 設定 → マイアカウント → 「2段階認証を有効にする」。乗っ取られると他人が AI 社員に指示できてしまいます。バックアップコードは紙かパスワード管理に"
echo "  ・このウィンドウは閉じて大丈夫です（Claude は別の窓で動いています）"
echo "  ・Claude が動いている窓は閉じないでください"
echo "  ・パソコンは電源につないで、スリープしない設定にしておいてください"
if [ "$NCAND" -gt 0 ] 2>/dev/null; then
echo ""
echo "  📦 デスクトップアプリで開発していたプロジェクトが ${NCAND} 個見つかりました"
echo "     （デスクトップの AIオフィス フォルダの「引き継ぎ診断.txt」）"
echo "     統括の部屋に「引き継いで」と送ると、そのまま Discord の開発部屋にできます"
fi
echo ""
echo "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊"
