# -*- coding: utf-8 -*-
"""discord-ai-office: Discord に「AI社員の部屋」を作り、社員（ペルソナ）を雇い、部屋⇔担当の対応表を管理する。

  python office.py whoami                         … bot と参加サーバーを確認
  python office.py setup  --guild <GUILD_ID> [--category "AIオフィス"]
                                                  … カテゴリを作り、staff.json の社員ぶんの部屋を作る（既存はスキップ）
  python office.py hire   "名前" "役割（1行）" [--tone "口調"] [--emoji 🧭] [--guild <GUILD_ID>] [--project <パス>] [--engine claude|codex]
                                                  … 部屋を作る＋ペルソナ定義を書く＋access.json に登録＋部屋に挨拶
  python office.py hire-all --file 社員名簿.txt   … 名簿（1行1人）をまとめて雇う。既存はスキップ。最後に NEW=<新規数> を出力
  python office.py links  [--out <フォルダ>] [--post <CHANNEL_ID>|hq]
                                                  … 部屋ごとのリンク一覧（links.md / links.html）を書く。--post で「名前→リンク」を1部屋ずつ投稿
  python office.py backup [--out <フォルダ>]     … 設定・台帳・ペルソナ・メモリを zip に退避（トークンは入れない）
  python office.py list                           … 社員一覧（部屋ID・役割・engine）
  python office.py say    <CHANNEL_ID> "本文"     … 部屋に1通投稿（Claude Code が落ちていても届く）
  python office.py notice "本文"                  … 統括部屋（config.json の hq_room）に投稿
  python office.py hire   "名前" "役割" --skill <スキル名>
                                                  … スキルを社員にする（その部屋ではそのスキルの手順で仕事をする）
  python office.py fire   "名前"                  … 社員を外す（台帳と許可から外す。部屋とペルソナは消さない）。統括は外せない
  python office.py migrate [--out <フォルダ>] [--short]
                                                  … 引き継ぎ診断: デスクトップアプリ／CLI で育てたスキル・CLAUDE.md・プロジェクトごとのメモリを一覧にする（読むだけ）
  python office.py project "部屋の名前" [--dir <フォルダ>] [--emoji 🛠]
                                                  … 開発部屋: チャンネル＋作業フォルダ＋引き継ぎメモを作る。その部屋の AI はデスクトップと同じメモリを読み書きする
  python office.py ask    <CHANNEL_ID> "質問" "選択肢A" "選択肢B" ["選択肢C"...]
                                                  … 🇦🇧🇨 で選ばせて、押された選択肢を標準出力に返す（run_in_background で使う）

置き場所: 社員台帳 ~/.claude/ai-office/staff.json ／ ペルソナ ~/.claude/ai-office/staff/<名前>.md ／ 設定 ~/.claude/ai-office/config.json
bot トークン: ~/.claude/channels/discord/.env の DISCORD_BOT_TOKEN=（Claude Code の Discord プラグインと共用・コピーを持たない）
engine=codex の社員は access.json に入れず、codex-staff/rooms.json（codex_bridge.py が見る表）に登録する。
"""
import io, json, os, re, sys, time, urllib.request, urllib.error, argparse, datetime, zipfile

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HOME = os.path.expanduser("~")
TOKEN_FILE = os.path.join(HOME, ".claude", "channels", "discord", ".env")
ACCESS_FILE = os.path.join(HOME, ".claude", "channels", "discord", "access.json")
OFFICE_DIR = os.path.join(HOME, ".claude", "ai-office")
STAFF_FILE = os.path.join(OFFICE_DIR, "staff.json")
STAFF_DIR = os.path.join(OFFICE_DIR, "staff")
CONFIG_FILE = os.path.join(OFFICE_DIR, "config.json")
SKILL_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
TEMPLATE = os.path.join(SKILL_DIR, "templates", "persona.md")
API = "https://discord.com/api/v10"
FLAGS = ["\U0001F1E6", "\U0001F1E7", "\U0001F1E8", "\U0001F1E9", "\U0001F1EA", "\U0001F1EB"]  # 🇦🇧🇨🇩🇪🇫


def token():
    if not os.path.exists(TOKEN_FILE):
        sys.exit("bot トークンが見つかりません: %s に DISCORD_BOT_TOKEN=... を置いてください（Claude Code の /discord:configure で入る）" % TOKEN_FILE)
    for line in io.open(TOKEN_FILE, encoding="utf-8"):
        if line.startswith("DISCORD_BOT_TOKEN="):
            return line.split("=", 1)[1].strip().strip('"')
    sys.exit("DISCORD_BOT_TOKEN が .env にありません")


def api(method, path, data=None):
    req = urllib.request.Request(API + path, data=(json.dumps(data).encode("utf-8") if data is not None else None), method=method,
                                 headers={"Authorization": "Bot " + token(), "Content-Type": "application/json", "User-Agent": "DiscordBot (discord-ai-office, 1.1)"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                body = r.read().decode("utf-8")
                return json.loads(body) if body else {}
        except urllib.error.HTTPError as e:
            b = e.read().decode("utf-8", "replace")
            if e.code == 429:
                time.sleep(float(json.loads(b).get("retry_after", 1)) + 0.5); continue
            hint = ""
            if e.code == 403 and "50013" in b:
                try: app_id = api("GET", "/users/@me")["id"]
                except SystemExit: app_id = "<APPLICATION_ID>"
                hint = ("\n→ bot に権限が足りません（チャンネルの管理など）。次の URL をサーバー管理者が開いてサーバーを選び「認証」すると権限が足されます:\n"
                        "https://discord.com/oauth2/authorize?client_id=%s&scope=bot&permissions=117840" % app_id)
            sys.exit("Discord API %s %s -> HTTP %s: %s%s" % (method, path, e.code, b[:300], hint))
    sys.exit("Discord API: 3回リトライしても失敗")


def load_json(p, default):
    if not os.path.exists(p): return default
    return json.load(io.open(p, encoding="utf-8"))


def save_json(p, obj):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    io.open(p, "w", encoding="utf-8").write(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def config():
    return load_json(CONFIG_FILE, {})


def hq_room():
    c = config()
    if c.get("hq_room"): return c["hq_room"]
    for s in load_json(STAFF_FILE, {"staff": []})["staff"]:
        if s["name"] == "統括": return s["room_id"]
    sys.exit("統括部屋が未設定です: %s に {\"hq_room\": \"<チャンネルID>\"} を書いてください" % CONFIG_FILE)


def guild_of(args):
    if getattr(args, "guild", None): return args.guild
    staff = load_json(STAFF_FILE, {})
    if staff.get("guild"): return staff["guild"]
    if config().get("guild"): return config()["guild"]
    gs = api("GET", "/users/@me/guilds")
    if len(gs) == 1: return gs[0]["id"]
    sys.exit("--guild <サーバーID> を指定してください。候補: " + ", ".join("%s=%s" % (g["id"], g["name"]) for g in gs))


def cmd_whoami(args):
    me = api("GET", "/users/@me"); print("bot:", me["username"], "id:", me["id"])
    for g in api("GET", "/users/@me/guilds"):
        print("guild:", g["id"], g["name"])


def ensure_category(gid, name):
    for c in api("GET", "/guilds/%s/channels" % gid):
        if c["type"] == 4 and c["name"] == name: return c["id"]
    c = api("POST", "/guilds/%s/channels" % gid, {"name": name, "type": 4})
    print("カテゴリ作成:", name, c["id"]); return c["id"]


def ensure_room(gid, name, parent_id=None, topic=""):
    for c in api("GET", "/guilds/%s/channels" % gid):
        if c["type"] == 0 and c["name"] == name: return c["id"], False
    body = {"name": name, "type": 0, "topic": topic[:1000]}
    if parent_id: body["parent_id"] = parent_id
    c = api("POST", "/guilds/%s/channels" % gid, body)
    return c["id"], True


def register_access(channel_id):
    acc = load_json(ACCESS_FILE, {"dmPolicy": "allowlist", "allowFrom": [], "groups": {}, "pending": {}})
    acc.setdefault("groups", {})
    if channel_id not in acc["groups"]:
        acc["groups"][channel_id] = {"requireMention": False, "allowFrom": []}
        save_json(ACCESS_FILE, acc); print("access.json に登録:", channel_id)
    else:
        print("access.json 登録済み:", channel_id)


def register_codex(channel_id, name, role):
    """engine=codex の社員は codex_bridge.py の rooms.json に登録（Claude 側の access.json には入れない）"""
    cdir = config().get("codex_dir") or os.path.join(HOME, "Desktop", "codex-staff")
    rf = os.path.join(cdir, "rooms.json")
    if not os.path.isdir(cdir):
        print("codex-staff フォルダが無いので rooms.json は未登録:", cdir); return
    rooms = load_json(rf, {})
    if channel_id in rooms:
        print("rooms.json 登録済み:", channel_id); return
    rooms[channel_id] = {"name": name, "mode": "own", "role": role}
    save_json(rf, rooms); print("rooms.json に登録（codex）:", channel_id)


def write_persona(name, role, tone, emoji, room_id, project):
    os.makedirs(STAFF_DIR, exist_ok=True)
    tpl = io.open(TEMPLATE, encoding="utf-8").read() if os.path.exists(TEMPLATE) else "# {name}\n役割: {role}\n"
    md = tpl.format(name=name, role=role, tone=tone or "丁寧で短い。結論→根拠→次の一手。", emoji=emoji or "🙂", room_id=room_id,
                    project=project or "（未設定）", date=datetime.date.today().isoformat())
    p = os.path.join(STAFF_DIR, name + ".md")
    if not os.path.exists(p):
        io.open(p, "w", encoding="utf-8", newline="\n").write(md); print("ペルソナ作成:", p)
    else:
        print("ペルソナ既存（上書きしない）:", p)
    return p


def hire_one(name, role, tone=None, emoji=None, guild=None, category=None, room=None, project=None, engine="claude", quiet=False, skill=None):
    """1人雇う。戻り値 (room_id, created)"""
    class A: pass
    a = A(); a.guild = guild
    gid = guild_of(a)
    staff = load_json(STAFF_FILE, {"guild": gid, "category": category or "AIオフィス", "staff": []})
    staff["guild"] = gid
    existing = next((s for s in staff["staff"] if s["name"] == name), None)
    cat = ensure_category(gid, staff.get("category") or category or "AIオフィス")
    if existing and existing.get("room_id"):
        rid, created = existing["room_id"], False
        room_name = existing.get("room_name") or room or "%s【%s】" % (name, role.split("・")[0][:12])
    else:
        room_name = room or "%s【%s】" % (name, role.split("・")[0][:12])
        rid, created = ensure_room(gid, room_name, cat, topic="担当: %s ／ %s" % (name, role))
    print("部屋:", room_name, rid, "(新規)" if created else "(既存)")
    if engine == "codex":
        register_codex(rid, name, role)
    else:
        register_access(rid)
    ppath = write_persona(name, role, tone, emoji, rid, project)
    if skill:
        sk = os.path.join(SKILLS_DIR, skill, "SKILL.md")
        txt = io.open(ppath, encoding="utf-8").read()
        if "この社員の道具" not in txt:
            io.open(ppath, "a", encoding="utf-8", newline="\n").write(
                "\n## この社員の道具（スキル）\n- スキル「%s」（%s）。この部屋の仕事は、まずこのスキルの SKILL.md を読んで、その手順で行う。%s\n"
                % (skill, sk, "" if os.path.exists(sk) else "※いまこのパソコンに見つからない（~/.claude/skills に入れてから）"))
    entry = {"name": name, "role": role, "emoji": emoji or "", "room_id": rid, "room_name": room_name, "engine": engine,
             "persona": (existing or {}).get("persona") or ppath, "project": project or (existing or {}).get("project", ""),
             "hired": (existing or {}).get("hired") or datetime.date.today().isoformat()}
    if skill or (existing or {}).get("skill"): entry["skill"] = skill or existing.get("skill")
    staff["staff"] = [s for s in staff["staff"] if s["name"] != name] + [entry]
    save_json(STAFF_FILE, staff); print("staff.json 更新:", STAFF_FILE)
    if created and not quiet:
        api("POST", "/channels/%s/messages" % rid, {"content": "%s %s です。この部屋では「%s」として動きます。指示はこの部屋にそのまま書いてください。" % (emoji or "🙂", name, role)})
    return rid, created


def cmd_hire(args):
    hire_one(args.name, args.role, args.tone, args.emoji, args.guild, args.category, args.room, args.project, args.engine, args.quiet, args.skill)
    print("\n次にやること: この部屋に「%s、テスト」と書いて返事が来れば完了（再起動は不要。許可の表は発言のたびに読み直される）。" % args.name)


def parse_roster(path):
    """社員名簿.txt: 1行1人。区切りは | か ｜。列＝ 名前 | 役割 | 絵文字 | engine(claude/codex) | 正典パス | 口調   （後ろの列は省略可）"""
    rows = []
    for raw in io.open(path, encoding="utf-8-sig"):
        line = raw.strip()
        if not line or line.startswith("#"): continue
        cols = [c.strip() for c in re.split(r"[|｜]", line)]
        while len(cols) < 6: cols.append("")
        name, role, emoji, engine, project, tone = cols[:6]
        if not name or not role: print("名簿の行を読めません（名前と役割が必要）:", line); continue
        rows.append({"name": name, "role": role, "emoji": emoji, "engine": (engine or "claude").lower(), "project": project, "tone": tone})
    return rows


def cmd_hire_all(args):
    rows = parse_roster(args.file)
    staff = load_json(STAFF_FILE, {"staff": []})
    known = {s["name"]: s for s in staff["staff"]}
    new = 0
    for r in rows:
        if r["name"] in known and known[r["name"]].get("room_id") and not args.refresh:
            print("既存（スキップ）:", r["name"]); continue
        rid, created = hire_one(r["name"], r["role"], r["tone"] or None, r["emoji"] or None, args.guild, None, None, r["project"] or None, r["engine"], args.quiet)
        new += 1 if created else 0
    print("NEW=%d" % new)


def room_links(s, gid):
    dm = (s.get("room_name") or "").startswith("（DM") or s.get("dm")
    base = "%s/%s" % ("@me" if dm else gid, s["room_id"])
    return "https://discord.com/channels/" + base, "discord://discord.com/channels/" + base


HTML_HEAD = """<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes"><title>AIオフィス</title>
<style>body{font-family:-apple-system,"Hiragino Sans","Noto Sans JP",sans-serif;margin:0;padding:16px;background:#111;color:#eee}
h1{font-size:20px;margin:8px 0 16px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}
a.room{display:block;background:#1f2937;border-radius:16px;padding:18px 12px;text-decoration:none;color:#fff;text-align:center;box-shadow:0 2px 6px #0006}
a.room .e{font-size:34px;display:block}a.room .n{font-size:17px;font-weight:700;display:block;margin-top:6px}a.room .r{font-size:12px;color:#9ca3af;display:block;margin-top:2px}
.how{margin-top:28px;font-size:13px;color:#cbd5e1;line-height:1.7}.how code{background:#222;padding:1px 5px;border-radius:4px}
button{margin-top:6px;font-size:12px;background:#374151;color:#eee;border:0;border-radius:8px;padding:4px 8px}</style></head><body>
<h1>🏢 AIオフィス — 部屋一覧</h1><div class="grid">
"""
HTML_TAIL = """</div>
<div class="how"><b>iPhone のホーム画面に「部屋ごとのアイコン」を作る（ショートカット）</b><br>
①「ショートカット」アプリ → ＋ → アクションを追加 →「URLを開く」<br>
② URL に、この一覧の下の <code>discord://…</code> を貼る（長押しコピー）<br>
③ 右上の共有 →「ホーム画面に追加」→ 名前を社員名にして追加<br>
（この一覧ページ自体を Safari の「ホーム画面に追加」で1個置く手もあります）</div>
<div class="how"><b>コピー用リンク</b><br>
"""


def cmd_links(args):
    staff = load_json(STAFF_FILE, {"staff": []}); gid = staff.get("guild") or config().get("guild")
    if not gid: sys.exit("guild が未設定（staff.json）")
    md = ["# AIオフィス 部屋リンク一覧（%s）" % datetime.date.today().isoformat(), "",
          "| 社員 | 役割 | アプリで開く（ショートカット用） | ブラウザ |", "|---|---|---|---|"]
    html = [HTML_HEAD]; copy = []
    for s in staff["staff"]:
        web, app = room_links(s, gid)
        md.append("| %s %s | %s | %s | %s |" % (s.get("emoji", ""), s["name"], s["role"], app, web))
        html.append('<a class="room" href="%s"><span class="e">%s</span><span class="n">%s</span><span class="r">%s</span></a>\n'
                    % (app, s.get("emoji") or "🙂", s["name"], s["role"][:14]))
        copy.append('%s %s<br><code id="c%s">%s</code> <button onclick="navigator.clipboard.writeText(document.getElementById(\'c%s\').textContent)">コピー</button><br>'
                    % (s.get("emoji", ""), s["name"], s["room_id"], app, s["room_id"]))
    html.append(HTML_TAIL); html.extend(copy); html.append("</div></body></html>")
    outs = [OFFICE_DIR] + ([args.out] if args.out else [])
    for d in outs:
        os.makedirs(d, exist_ok=True)
        io.open(os.path.join(d, "links.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
        io.open(os.path.join(d, "links.html"), "w", encoding="utf-8").write("".join(html))
        print("書き出し:", os.path.join(d, "links.md"), "/ links.html")
    if args.post:
        ch = hq_room() if args.post == "hq" else args.post
        api("POST", "/channels/%s/messages" % ch, {"content": "🏢 部屋リンク一覧（%d部屋）。各部屋「名前」→「リンク」の順に1つずつ送ります。リンクを長押しコピーして、ショートカットの「URLを開く」に貼ると、その部屋を開くアイコンになります。" % len(staff["staff"])})
        for s in staff["staff"]:
            web, app = room_links(s, gid)
            api("POST", "/channels/%s/messages" % ch, {"content": "%s %s（%s）" % (s.get("emoji", ""), s["name"], s["role"])}); time.sleep(0.4)
            api("POST", "/channels/%s/messages" % ch, {"content": app}); time.sleep(0.4)
        print("投稿:", ch)


def cmd_backup(args):
    out = args.out or os.path.join(OFFICE_DIR, "backups")
    os.makedirs(out, exist_ok=True)
    zp = os.path.join(out, "ai-office_%s.zip" % datetime.datetime.now().strftime("%Y%m%d_%H%M"))
    targets = [ACCESS_FILE, STAFF_FILE, CONFIG_FILE, os.path.join(HOME, ".claude", "CLAUDE.md"), os.path.join(HOME, ".claude", "settings.json")]
    dirs = [STAFF_DIR, os.path.join(HOME, ".claude", "projects"), SKILL_DIR]
    for extra in config().get("backup_extra", []): dirs.append(os.path.expanduser(extra))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in targets:
            if os.path.exists(f): z.write(f, os.path.relpath(f, HOME)); n += 1
        for d in dirs:
            for root, _, files in os.walk(d):
                for fn in files:
                    if fn.endswith((".env", ".fal_key", "_token.txt", "bot_token.txt", ".jsonl")): continue   # 秘密と巨大ログは入れない
                    p = os.path.join(root, fn)
                    try:
                        if os.path.getsize(p) > 20 * 1024 * 1024: continue
                        z.write(p, os.path.relpath(p, HOME)); n += 1
                    except OSError: pass
    print("backup:", zp, n, "files")
    keep = int(config().get("backup_keep", 14))
    olds = sorted(f for f in os.listdir(out) if f.startswith("ai-office_") and f.endswith(".zip"))
    for f in olds[:-keep]:
        os.remove(os.path.join(out, f)); print("古いバックアップ削除:", f)


def cmd_setup(args):
    gid = guild_of(args)
    staff = load_json(STAFF_FILE, {"guild": gid, "category": args.category or "AIオフィス", "staff": []})
    staff["guild"] = gid; staff["category"] = args.category or staff.get("category") or "AIオフィス"
    cat = ensure_category(gid, staff["category"])
    for s in staff["staff"]:
        rid, created = ensure_room(gid, s.get("room_name") or "%s【%s】" % (s["name"], s["role"][:12]), cat, topic="担当: %s ／ %s" % (s["name"], s["role"]))
        s["room_id"] = rid
        if s.get("engine") == "codex": register_codex(rid, s["name"], s["role"])
        else: register_access(rid)
        s["persona"] = write_persona(s["name"], s["role"], s.get("tone"), s.get("emoji"), rid, s.get("project"))
        print(("作成" if created else "既存"), s["name"], rid)
    save_json(STAFF_FILE, staff); print("完了:", STAFF_FILE)


def cmd_list(args):
    staff = load_json(STAFF_FILE, {"staff": []})
    print("guild:", staff.get("guild"), "category:", staff.get("category"))
    for s in staff["staff"]:
        print("%s %-8s %-20s room=%s  engine=%s  %s" % (s.get("emoji", ""), s["name"], s["role"][:20], s["room_id"], s.get("engine", "claude"), s.get("project", "")))


def cmd_say(args):
    api("POST", "/channels/%s/messages" % args.channel, {"content": args.text}); print("sent")


def cmd_notice(args):
    api("POST", "/channels/%s/messages" % hq_room(), {"content": args.text}); print("sent")


def cmd_ask(args):
    labels = args.choices
    lines = [args.question] + ["%s **%s** … %s" % (FLAGS[i], chr(65 + i), c) for i, c in enumerate(labels)] + ["↓ 絵文字をタップして選んでください"]
    m = api("POST", "/channels/%s/messages" % args.channel, {"content": "\n".join(lines)})
    mid = m["id"]
    for i in range(len(labels)):
        api("PUT", "/channels/%s/messages/%s/reactions/%s/@me" % (args.channel, mid, urllib.request.quote(FLAGS[i])))
        time.sleep(0.3)
    me = api("GET", "/users/@me")["id"]
    deadline = time.time() + args.timeout
    while time.time() < deadline:
        time.sleep(args.poll)
        for i in range(len(labels)):
            users = api("GET", "/channels/%s/messages/%s/reactions/%s" % (args.channel, mid, urllib.request.quote(FLAGS[i])))
            if any(u["id"] != me for u in users):
                print("%d\t%s" % (i + 1, labels[i])); return
    print("0\tTIMEOUT")


def cmd_fire(args):
    staff = load_json(STAFF_FILE, {"staff": []})
    s_ = next((x for x in staff["staff"] if x["name"] == args.name), None)
    if not s_: sys.exit("社員「%s」は台帳にいません（office.py list で確認）" % args.name)
    if s_["name"] == "統括" or s_.get("room_id") == config().get("hq_room"):
        sys.exit("統括は外せません（振り分けと「引き継いで」の窓口のため）")
    staff["staff"] = [x for x in staff["staff"] if x["name"] != args.name]
    save_json(STAFF_FILE, staff)
    acc = load_json(ACCESS_FILE, {"groups": {}})
    if acc.get("groups", {}).pop(s_["room_id"], None) is not None:
        save_json(ACCESS_FILE, acc); print("access.json から外しました:", s_["room_id"])
    if not args.quiet:
        try: api("POST", "/channels/%s/messages" % s_["room_id"], {"content": "👋 %s はこの部屋の担当から外れました。この部屋に書いても、もう返事はしません（部屋は Discord の設定からいつでも消せます）。" % args.name})
        except SystemExit: pass
    print("外しました:", args.name, "（部屋とペルソナ %s は残しています）" % s_.get("persona", ""))


# ---------------------------------------------------------------- 引き継ぎ診断・開発部屋
PROJECTS_DIR = os.path.join(HOME, ".claude", "projects")
SKILLS_DIR = os.path.join(HOME, ".claude", "skills")
DEV_TEMPLATE = os.path.join(SKILL_DIR, "templates", "project_room.md")


def encode_project(path):
    """Claude Code がプロジェクトごとの保存場所に使う名前（英数字以外を - にする）"""
    return re.sub(r"[^A-Za-z0-9]", "-", os.path.abspath(os.path.expanduser(path)))


def memory_dir_for(folder):
    """Claude Code のメモリ置き場。git リポジトリの中ならリポジトリの一番上、外ならそのフォルダで決まる（公式ドキュメント memory の Storage location）"""
    d = os.path.abspath(os.path.expanduser(folder)); cur = d
    while True:
        if os.path.exists(os.path.join(cur, ".git")):
            d = cur; break
        up = os.path.dirname(cur)
        if up == cur: break
        cur = up
    return os.path.join(PROJECTS_DIR, encode_project(d), "memory")


def _cwd_of(pdir):
    """projects/<名前>/ の会話ログ（*.jsonl）から、そのプロジェクトの作業フォルダ（cwd）を読む"""
    logs = sorted((f for f in os.listdir(pdir) if f.endswith(".jsonl")), key=lambda f: os.path.getmtime(os.path.join(pdir, f)), reverse=True)
    for f in logs[:3]:
        try:
            with io.open(os.path.join(pdir, f), encoding="utf-8", errors="ignore") as fh:
                for i, line in enumerate(fh):
                    if i > 200: break
                    m = re.search(r'"cwd":\s*"((?:[^"\\]|\\.)*)"', line)
                    if m: return json.loads('"%s"' % m.group(1))
        except OSError:
            pass
    return None


def scan_projects():
    out = []
    if not os.path.isdir(PROJECTS_DIR): return out
    office_dir = config().get("office_dir") or ""
    for name in os.listdir(PROJECTS_DIR):
        pdir = os.path.join(PROJECTS_DIR, name)
        if not os.path.isdir(pdir): continue
        logs = [f for f in os.listdir(pdir) if f.endswith(".jsonl")]
        cwd = _cwd_of(pdir) or ""
        mem = memory_dir_for(cwd) if cwd else os.path.join(pdir, "memory")
        mem_files = [f for f in os.listdir(mem) if f.endswith(".md")] if os.path.isdir(mem) else []
        if not logs and not mem_files: continue
        last = max([os.path.getmtime(os.path.join(pdir, f)) for f in logs] + [os.path.getmtime(pdir)])
        nc = os.path.normcase(os.path.abspath(cwd or "x"))
        home_like = nc in (os.path.normcase(HOME), os.path.normcase(os.path.join(HOME, "Desktop"))) or             any(t in nc.replace("\\", "/") for t in ("/appdata/local/temp", "/tmp", "/var/folders", "/private/var"))
        is_office = bool(office_dir) and os.path.normcase(os.path.abspath(cwd or "x")) == os.path.normcase(os.path.abspath(office_dir))
        out.append({"key": name, "cwd": cwd, "exists": bool(cwd) and os.path.isdir(cwd), "sessions": len(logs),
                    "memory_files": len(mem_files), "memory_dir": mem, "last": last, "home_like": home_like, "is_office": is_office})
    out.sort(key=lambda p: p["last"], reverse=True)
    return out


def scan_skills():
    out = []
    if not os.path.isdir(SKILLS_DIR): return out
    for name in sorted(os.listdir(SKILLS_DIR)):
        sk = os.path.join(SKILLS_DIR, name, "SKILL.md")
        if not os.path.exists(sk): continue
        desc = ""
        for line in io.open(sk, encoding="utf-8", errors="ignore"):
            if line.startswith("description:"):
                desc = line.split(":", 1)[1].strip().strip('"')[:60]; break
        out.append({"name": name, "desc": desc})
    return out


def cmd_migrate(args):
    skills = scan_skills()
    projects = [p for p in scan_projects() if not p["is_office"]]
    claude_md = os.path.join(HOME, ".claude", "CLAUDE.md")
    staff = load_json(STAFF_FILE, {"staff": []})
    linked = {os.path.normcase(os.path.abspath(s["project"])) for s in staff["staff"] if s.get("kind") == "project" and s.get("project")}
    cand = [p for p in projects if p["exists"] and not p["home_like"] and os.path.normcase(os.path.abspath(p["cwd"])) not in linked]
    if args.short:
        print("引き継ぎ診断: スキル %d 個・プロジェクト %d 個（部屋にできるもの %d 個）" % (len(skills), len(projects), len(cand)))
        print("CANDIDATES=%d" % len(cand))
        print("SKILLS=%d" % len([k for k in skills if k["name"] != "discord-ai-office"]))
        return
    L = ["# 引き継ぎ診断（%s）" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "",
         "デスクトップアプリ（コード）や Claude Code で使ってきたものの一覧です。AIオフィスは同じパソコンの同じ Claude Code で動くので、ここにあるものはそのまま使えます。", "",
         "## 1. 全体の決まりごと（CLAUDE.md）",
         ("あり（%d 文字）→ Discord の部屋でも毎回読まれます" % len(io.open(claude_md, encoding="utf-8", errors="ignore").read())) if os.path.exists(claude_md) else "なし", "",
         "## 2. スキル（%d 個）→ Discord の部屋でもそのまま使えます" % len(skills)]
    sk_cand = [k for k in skills if k["name"] != "discord-ai-office"]
    hired_sk = {x.get("skill") for x in staff["staff"] if x.get("skill")}
    L += ["S%d. %s … %s%s" % (i, k["name"], k["desc"], "（社員にしてあります）" if k["name"] in hired_sk else "") for i, k in enumerate(sk_cand, 1)] or ["- （なし）"]
    L += ["→ S の番号のスキルは「社員」にできます（そのスキル専用の部屋ができて、その部屋ではそのスキルで仕事をします）"]
    L += ["", "## 3. プロジェクト（フォルダごとの会話とメモリ）", "番号の付いたものは「開発部屋」にできます。部屋にすると、その部屋の AI はこのフォルダのメモリを読み書きします（デスクトップで開いても同じメモリ）。", ""]
    for i, p in enumerate(cand, 1):
        L.append("%d. %s\n   最終 %s ・ 会話 %d 回 ・ メモリ %d 件" % (i, p["cwd"], datetime.datetime.fromtimestamp(p["last"]).strftime("%Y-%m-%d"), p["sessions"], p["memory_files"]))
    if not cand: L.append("（部屋にできるプロジェクトはありません）")
    rest = [p for p in projects if p not in cand]
    if rest:
        L += ["", "部屋にしないもの（ホーム／デスクトップ直下・フォルダが無い・部屋にしてあるもの）:"]
        L += ["- %s（メモリ %d 件）" % (p["cwd"] or p["key"], p["memory_files"]) for p in rest]
    L += ["", "## 4. 引き継げないもの",
          "- デスクトップアプリの普通のチャット（コードではない方）の会話・メモリ・プロジェクトは Anthropic のサーバー側にあり、このパソコンからは読めません。残したい内容は、そのチャットで「今までの決まりごとを箇条書きにして」と頼み、出てきた文を統括の部屋に貼ってください。CLAUDE.md に入れます。",
          "- 会話の途中の続き（セッション）は引き継ぎません。代わりに開発部屋ごとに AI が「引き継ぎメモ」を書き、次はそこから続けます。"]
    text = "\n".join(L) + "\n"
    print(text)
    outs = [OFFICE_DIR] + ([args.out] if args.out else [])
    for d in outs:
        os.makedirs(d, exist_ok=True)
        io.open(os.path.join(d, "引き継ぎ診断.txt"), "w", encoding="utf-8", newline="\n").write(text)
    save_json(os.path.join(OFFICE_DIR, "migrate.json"), {"candidates": [p["cwd"] for p in cand], "skills": [k["name"] for k in sk_cand]})
    print("CANDIDATES=%d" % len(cand))
    print("SKILLS=%d" % len(sk_cand))


def _safe_folder(name):
    """フォルダ名は英数字だけにする（日本語は Claude Code のメモリ置き場の名前で全部 - になり、別の開発とぶつかるため）"""
    n = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-.")
    return n if len(re.sub(r"[^A-Za-z0-9]", "", n)) >= 3 else "project-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


def cmd_project(args):
    name = args.name.strip()
    cand = load_json(os.path.join(OFFICE_DIR, "migrate.json"), {}).get("candidates", [])
    d = args.dir
    base = config().get("dev_root") or os.path.join(HOME, "ai-office-dev")
    if d and d.strip().isdigit():      # 診断の番号で指定（--dir 3）
        i = int(d) - 1
        if not 0 <= i < len(cand): sys.exit("番号 %s は引き継ぎ診断の一覧にありません（先に office.py migrate を実行。候補 %d 個）" % (d, len(cand)))
        d = cand[i]
    if not d:
        d = os.path.join(base, _safe_folder(name))
    d = os.path.expanduser(d)
    if not os.path.isabs(d):           # 「store-game」のような名前だけなら開発フォルダの下に置く
        d = os.path.join(base, d)
    d = os.path.abspath(d)
    fresh = not os.path.exists(d)
    os.makedirs(d, exist_ok=True)
    if fresh:   # 新しいフォルダは git の置き場にする（変更の履歴が残る＋メモリがこの開発専用になる）
        try:
            import subprocess
            subprocess.run(["git", "init", "-q", d], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
        except Exception:
            pass
    # このフォルダのメモリ置き場（デスクトップアプリで開いたときと同じ場所）
    mem = memory_dir_for(d)
    os.makedirs(mem, exist_ok=True)
    handoff = os.path.join(mem, "handoff.md")
    if not os.path.exists(handoff):
        io.open(handoff, "w", encoding="utf-8", newline="\n").write("---\nname: handoff\ndescription: この開発の引き継ぎメモ（Discord の開発部屋とデスクトップで共通）。作業の区切りで更新する\nmetadata:\n  type: project\n---\n\n## 決まったこと\n\n## 途中のもの\n\n## 次の一手\n")
    index = os.path.join(mem, "MEMORY.md")
    line = "- [引き継ぎメモ](handoff.md) — Discord の開発部屋「%s」とデスクトップで共通。作業を始める前に読む" % name
    cur = io.open(index, encoding="utf-8").read() if os.path.exists(index) else ""
    if "handoff.md" not in cur:
        io.open(index, "w", encoding="utf-8", newline="\n").write((cur.rstrip("\n") + "\n" if cur else "") + line + "\n")
    # 部屋
    class A: pass
    a = A(); a.guild = None
    gid = guild_of(a)
    staff = load_json(STAFF_FILE, {"guild": gid, "category": "AIオフィス", "staff": []})
    staff["guild"] = gid
    existing = next((s for s in staff["staff"] if s["name"] == name), None)
    cat = ensure_category(gid, config().get("dev_category") or "開発")
    if existing and existing.get("room_id"):
        rid, created = existing["room_id"], False
    else:
        rid, created = ensure_room(gid, name, cat, topic="開発部屋 ／ フォルダ: %s" % d)
    register_access(rid)
    os.makedirs(STAFF_DIR, exist_ok=True)
    ppath = os.path.join(STAFF_DIR, re.sub(r'[<>:"/|?*]', "-", name) + ".md")
    tpl = io.open(DEV_TEMPLATE, encoding="utf-8").read() if os.path.exists(DEV_TEMPLATE) else "# {name}\nフォルダ: {folder}\nメモリ: {memory}\n"
    if not os.path.exists(ppath):
        io.open(ppath, "w", encoding="utf-8", newline="\n").write(tpl.format(name=name, room_id=rid, folder=d, memory=mem, handoff=handoff,
                                                               emoji=args.emoji or "🛠", date=datetime.date.today().isoformat()))
    entry = {"name": name, "role": "開発部屋", "kind": "project", "emoji": args.emoji or "🛠", "room_id": rid, "room_name": name,
             "engine": "claude", "persona": ppath, "project": d, "memory": mem,
             "hired": (existing or {}).get("hired") or datetime.date.today().isoformat()}
    staff["staff"] = [s for s in staff["staff"] if s["name"] != name] + [entry]
    save_json(STAFF_FILE, staff)
    print("部屋:", name, rid, "(新規)" if created else "(既存)")
    print("フォルダ:", d)
    print("メモリ:", mem)
    if created and not args.quiet:
        api("POST", "/channels/%s/messages" % rid, {"content": "%s 開発部屋「%s」です。\n作業フォルダ: %s\nこの部屋の AI は、デスクトップアプリでこのフォルダを開いたときと同じメモリを読み書きします。やりたいことをそのまま書いてください。" % (args.emoji or "🛠", name, d)})


def main():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("whoami")
    p = sub.add_parser("setup"); p.add_argument("--guild"); p.add_argument("--category")
    p = sub.add_parser("hire"); p.add_argument("name"); p.add_argument("role"); p.add_argument("--tone"); p.add_argument("--emoji"); p.add_argument("--guild")
    p.add_argument("--category"); p.add_argument("--room"); p.add_argument("--project"); p.add_argument("--engine", default="claude", choices=["claude", "codex"]); p.add_argument("--quiet", action="store_true"); p.add_argument("--skill")
    p = sub.add_parser("hire-all"); p.add_argument("--file", required=True); p.add_argument("--guild"); p.add_argument("--refresh", action="store_true"); p.add_argument("--quiet", action="store_true")
    p = sub.add_parser("links"); p.add_argument("--out"); p.add_argument("--post", help="チャンネルID または hq（統括部屋）")
    p = sub.add_parser("backup"); p.add_argument("--out")
    sub.add_parser("list")
    p = sub.add_parser("say"); p.add_argument("channel"); p.add_argument("text")
    p = sub.add_parser("notice"); p.add_argument("text")
    p = sub.add_parser("fire"); p.add_argument("name"); p.add_argument("--quiet", action="store_true")
    p = sub.add_parser("migrate"); p.add_argument("--out"); p.add_argument("--short", action="store_true")
    p = sub.add_parser("project"); p.add_argument("name"); p.add_argument("--dir"); p.add_argument("--emoji"); p.add_argument("--quiet", action="store_true")
    p = sub.add_parser("ask"); p.add_argument("channel"); p.add_argument("question"); p.add_argument("choices", nargs="+")
    p.add_argument("--timeout", type=int, default=1800); p.add_argument("--poll", type=int, default=5)
    a = ap.parse_args()
    {"whoami": cmd_whoami, "setup": cmd_setup, "hire": cmd_hire, "hire-all": cmd_hire_all, "links": cmd_links, "backup": cmd_backup,
     "list": cmd_list, "say": cmd_say, "notice": cmd_notice, "ask": cmd_ask, "migrate": cmd_migrate, "project": cmd_project, "fire": cmd_fire}[a.cmd](a)


if __name__ == "__main__":
    main()
