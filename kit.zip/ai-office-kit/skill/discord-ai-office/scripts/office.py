# -*- coding: utf-8 -*-
"""discord-ai-office: Discord に「AI社員の部屋」を作り、社員（ペルソナ）を雇い、部屋⇔担当の対応表を管理する。

  python office.py whoami                         … bot と参加サーバーを確認
  python office.py setup  --guild <GUILD_ID> [--category "AIオフィス"] [--no-notice-room]
                                                  … カテゴリを作り、staff.json の社員ぶんの部屋を作る（既存はスキップ）。「お知らせ」部屋も作る（C1 2026-09-30。--no-notice-room で作らない）
  python office.py hire   "名前" "役割（1行）" [--tone "口調"] [--emoji 🧭] [--guild <GUILD_ID>] [--project <パス>] [--engine claude|codex]
                                                  … 部屋を作る＋ペルソナ定義を書く＋access.json に登録＋部屋に挨拶
  python office.py hire-all --file 社員名簿.txt [--no-notice-room]
                                                  … 名簿（1行1人）をまとめて雇う。既存はスキップ。「お知らせ」部屋も作る（--no-notice-room で作らない）。最後に NEW=<新規数> を出力
  python office.py test-room --file 社員名簿.txt … 名簿の2人目（統括の次）の部屋名を1行で出す（「ここにテストと送って」の案内用）
  python office.py links  [--out <フォルダ>] [--post <CHANNEL_ID>|hq]
                                                  … 部屋ごとのリンク一覧（links.md / links.html）を書く。--post で「名前→リンク」を1部屋ずつ投稿
  python office.py backup [--out <フォルダ>]     … 設定・台帳・ペルソナ・メモリを zip に退避（トークンは入れない）
  python office.py list                           … 社員一覧（部屋ID・役割・engine）
  python office.py say    <CHANNEL_ID> "本文"     … 部屋に1通投稿（Claude Code が落ちていても届く）
  python office.py notice "本文" [--hq]            … お知らせ部屋（config.json の notice_room）に投稿。本文が ⚠/⚠️/🛡⚠️ で始まる・--hq のときは統括部屋（hq_room）へ（C1 2026-09-30）
  python office.py hire   "名前" "役割" --skill <スキル名>
  python office.py skill  "名前" <スキル名>              … もう部屋がある社員に、あとからスキルを持たせる（例 skill 経理 invoice-inbox）
                                                  … スキルを社員にする（その部屋ではそのスキルの手順で仕事をする）
  python office.py fire   "名前"                  … 社員を外す（台帳と許可から外す。部屋とペルソナは消さない）。統括は外せない
  python office.py watch-replies [--minutes 10]   … 返事の見張り: 人が書いて N 分たっても AI の返事が無い部屋に「⚠️ もう一度送って」を1回だけ出す（5分おきに自動で動く）
  python office.py migrate [--out <フォルダ>] [--short]
                                                  … 引き継ぎ診断: デスクトップアプリ／CLI で育てたスキル・CLAUDE.md・プロジェクトごとのメモリを一覧にする（読むだけ）
  python office.py project "部屋の名前" [--slug <英語名>] [--brief "何を作るか"] [--dir <フォルダ|診断の番号>] [--emoji 🛠]
                                                  … 開発部屋: チャンネル＋作業フォルダ＋引き継ぎメモを作る。その部屋の AI はデスクトップと同じメモリを読み書きする
  python office.py pause  [--yes]                 … お休み: AI を止め、定期再起動と見張りも止める（消さない）。「起動」で resume されて元どおり
  python office.py snippet-install                … ~/.claude/CLAUDE.md の作法ブロック（ここからキット〜ここまでキット）を今の版に差し替える（無ければ足す・古い版は目印が無くても差し替える）
  python office.py model [auto|opus|sonnet|<モデル名>] [--restart] [--office <フォルダ>]
                                                  … モデルを切り替える（モデル設定.txt と写しを書き換え、--restart で再起動）。引数なしで今の設定を表示
  python office.py new-session --file <引き継ぎ書.md> [--office <フォルダ>]
                                                  … 新しいセッションに切り替える（引き継ぎ書を handoff.md に置いて再起動。次の起動だけがそれを読む）
  python office.py token protect|unprotect|status  … bot トークンを OS の暗号化保存庫（Win: DPAPI／Mac: キーチェーン）へ移す／.env に戻す／どこにあるか
  python office.py manifest write|diff [--dir <skill>] [--out <txt>] … 正の一覧（sha256）を作る／古い版で利用者が変えたファイルを出す（更新の事故防止）
  python office.py local init|status               … 持ち主の置き場 ~/.claude/ai-office/local/（更新で触らない）: 起動時の指示.txt／CLAUDE_local.md／office_ext.py／guard_rules.py／start_hook.*
  python office.py hello                          … 起動の人数（社員 N 人・開発部屋 P 件（休止 Q 件））。お知らせ部屋があれば NOTICE=<部屋ID> も出す。起動スクリプトが指示文の末尾に付ける
  python office.py archive "<開発部屋名>" [--off]     … 開発部屋を休止にする／戻す（部屋・フォルダは残す。人数に数えない）
  python office.py usage [--days 7] [--post]        … 使用量の目安: 会話記録から直近5時間／直近N日のトークン量と会話回数・モデル別の割合（公式の枠％ではない）
  python office.py usage --nick [on|off]            … 目安％を bot のこのサーバーでのニックネームに書く（値なし＝今すぐ更新／on＝常時5分おき／off＝名前を戻して止める。C4 2026-09-30）
  python office.py guard on|off|status|verify|rehash [--restart] [--work-only] [--office <フォルダ>]
                                                  … 見張り（関所）: 危ない操作を Discord の 🔐 で持ち主の ✅ 待ちにする（上級者向け・原作 momomon）。on/off は次の起動から
  python office.py allow-basics                   … Discord の道具5つと ~/ai-office-data への書き込みを許可ルールに足す（起動のたびに流す・何度でも同じ）
  python office.py resume                         … お休みから戻す（起動のたびに start.sh / start.ps1 が呼ぶ。お休み中でなければ何もしない）
  python office.py uninstall [--office <フォルダ>] [--yes]
                                                  … やめる: 控え（バックアップ＋部屋ごとの会話）を作ってから、AI・自動処理・キットの決まり・bot の鍵を外す。スキルとメモリは残す
  python office.py ask    <CHANNEL_ID> "質問" "選択肢A" "選択肢B" ["選択肢C"...]
                                                  … 🇦🇧🇨 で選ばせて、押された選択肢を標準出力に返す（run_in_background で使う）

置き場所: 社員台帳 ~/.claude/ai-office/staff.json ／ ペルソナ ~/.claude/ai-office/staff/<名前>.md ／ 設定 ~/.claude/ai-office/config.json
bot トークン: ~/.claude/channels/discord/.env の DISCORD_BOT_TOKEN=（Claude Code の Discord プラグインと共用・コピーを持たない）。setup の最後に `token protect` で暗号化保存庫へ移し、起動時に環境変数で渡す
engine=codex の社員は access.json に入れず、codex-staff/rooms.json（codex_bridge.py が見る表）に登録する。
"""
import io, shutil, json, os, re, sys, time, shutil, urllib.request, urllib.error, argparse, datetime, zipfile

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HOME = os.path.expanduser("~")
TOKEN_FILE = os.path.join(HOME, ".claude", "channels", "discord", ".env")
ACCESS_FILE = os.path.join(HOME, ".claude", "channels", "discord", "access.json")
OFFICE_DIR = os.path.join(HOME, ".claude", "ai-office")
LOCAL_DIR = os.path.join(OFFICE_DIR, "local")   # 持ち主の追加の置き場（更新で触らない）
STAFF_FILE = os.path.join(OFFICE_DIR, "staff.json")
STAFF_DIR = os.path.join(OFFICE_DIR, "staff")
CONFIG_FILE = os.path.join(OFFICE_DIR, "config.json")
SKILL_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
TEMPLATE = os.path.join(SKILL_DIR, "templates", "persona.md")
API = "https://discord.com/api/v10"
FLAGS = ["\U0001F1E6", "\U0001F1E7", "\U0001F1E8", "\U0001F1E9", "\U0001F1EA", "\U0001F1EB"]  # 🇦🇧🇨🇩🇪🇫


TOKEN_DPAPI = os.path.join(OFFICE_DIR, "token.dpapi")   # Windows: DPAPI（このユーザーだけが復号できる）
KEYCHAIN_SERVICE = "ai-office-discord"                    # Mac: キーチェーンの generic password


def _token_from_env_file():
    try:
        for line in io.open(TOKEN_FILE, encoding="utf-8"):
            if line.startswith("DISCORD_BOT_TOKEN="):
                v = line.split("=", 1)[1].strip().strip('"')
                if v: return v
    except OSError:
        pass
    return ""


def _store_get():
    """暗号化保存庫からトークンを取り出す。無ければ ""（Windows=DPAPI ファイル・Mac=キーチェーン）"""
    import subprocess
    try:
        if os.name == "nt":
            if not os.path.exists(TOKEN_DPAPI): return ""
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                                "Add-Type -AssemblyName System.Security; $b=[IO.File]::ReadAllBytes('%s'); [Console]::Out.Write([Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect($b,$null,'CurrentUser')))" % TOKEN_DPAPI.replace("'", "''")],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
            return r.stdout.strip() if r.returncode == 0 else ""
        r = subprocess.run(["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"], capture_output=True, text=True, timeout=30)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def _store_put(v):
    import subprocess
    if os.name == "nt":
        os.makedirs(OFFICE_DIR, exist_ok=True)
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                            "Add-Type -AssemblyName System.Security; $t=[Console]::In.ReadToEnd().Trim(); $b=[Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($t),$null,'CurrentUser'); [IO.File]::WriteAllBytes('%s',$b)" % TOKEN_DPAPI.replace("'", "''")],
                           input=v, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
        return r.returncode == 0 and os.path.exists(TOKEN_DPAPI)
    r = subprocess.run(["security", "add-generic-password", "-U", "-s", KEYCHAIN_SERVICE, "-a", os.environ.get("USER", "ai-office"), "-w", v], capture_output=True, text=True, timeout=30)
    return r.returncode == 0


def _store_del():
    import subprocess
    if os.name == "nt":
        try: os.remove(TOKEN_DPAPI); return True
        except OSError: return not os.path.exists(TOKEN_DPAPI)
    r = subprocess.run(["security", "delete-generic-password", "-s", KEYCHAIN_SERVICE], capture_output=True, text=True, timeout=30)
    return r.returncode == 0


def token():
    """bot トークン: .env（プラグイン共用）→ 環境変数 → 暗号化保存庫 の順。値は表示・記録しない"""
    v = _token_from_env_file() or os.environ.get("DISCORD_BOT_TOKEN", "").strip() or _store_get()
    if not v:
        sys.exit("bot トークンが見つかりません: %s（DISCORD_BOT_TOKEN=…）か、暗号化保存庫（office.py token status）に入れてください" % TOKEN_FILE)
    return v


def cmd_token(args):
    """token protect: .env のトークンを OS の暗号化保存庫へ移して .env から消す／unprotect: 戻す／status／get（起動スクリプト用・値を出す）"""
    if args.action == "get":
        v = token(); sys.stdout.write(v); return
    env_v = _token_from_env_file(); stored = _store_get()
    if args.action == "status":
        print("トークンの置き場: .env=%s／暗号化保存庫=%s（%s）" % ("あり" if env_v else "なし", "あり" if stored else "なし", "DPAPI " + TOKEN_DPAPI if os.name == "nt" else "キーチェーン " + KEYCHAIN_SERVICE))
        print("TOKEN_STORE=%s" % ("protected" if (stored and not env_v) else ("plain" if env_v else "none"))); return
    if args.action == "protect":
        v = env_v or stored
        if not v: sys.exit("トークンがどこにもありません")
        if not _store_put(v): sys.exit("暗号化保存庫に入れられませんでした（Windows: PowerShell と DPAPI／Mac: security コマンド）")
        if _store_get() != v: sys.exit("保存庫から読み戻した値が違います。.env はそのまま残します")
        if env_v:
            lines = [l for l in io.open(TOKEN_FILE, encoding="utf-8").read().splitlines() if not l.startswith("DISCORD_BOT_TOKEN=")]
            if any(l.strip() for l in lines): io.open(TOKEN_FILE, "w", encoding="utf-8", newline="\n").write("\n".join(lines) + "\n")
            else: os.remove(TOKEN_FILE)
        print("トークンを暗号化保存庫に移しました（.env からは消しました）。起動時に復号して環境変数で Claude に渡します"); print("TOKEN_STORE=protected"); return
    if args.action == "unprotect":
        v = stored or env_v
        if not v: sys.exit("トークンがどこにもありません")
        os.makedirs(os.path.dirname(TOKEN_FILE), exist_ok=True)
        rest = [l for l in (io.open(TOKEN_FILE, encoding="utf-8").read().splitlines() if os.path.exists(TOKEN_FILE) else []) if not l.startswith("DISCORD_BOT_TOKEN=")]
        io.open(TOKEN_FILE, "w", encoding="utf-8", newline="\n").write("\n".join(rest + ["DISCORD_BOT_TOKEN=" + v]) + "\n")
        try:
            if os.name != "nt": os.chmod(TOKEN_FILE, 0o600)
        except OSError: pass
        if stored: _store_del()
        print("トークンを .env に戻しました（暗号化保存庫からは消しました）"); print("TOKEN_STORE=plain"); return


def api(method, path, data=None):
    if os.environ.get("AIOFFICE_DRY") == "1":   # 試験用（C1 2026-09-30）: Discord には出さず宛先と本文だけ print する
        print("DRY %s %s %s" % (method, path, json.dumps(data, ensure_ascii=False) if data is not None else ""))
        return {"id": "0"}
    req = urllib.request.Request(API + path, data=(json.dumps(data).encode("utf-8") if data is not None else None), method=method,
                                 headers={"Authorization": "Bot " + token(), "Content-Type": "application/json", "User-Agent": "DiscordBot (discord-ai-office, 1.1)"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                body = r.read().decode("utf-8")
                return json.loads(body) if body else {}
        except urllib.error.HTTPError as e:
            b = e.read().decode("utf-8", "replace")
            if e.code == 429:
                time.sleep(float(json.loads(b).get("retry_after", 1)) + 0.5); continue
            hint = ""
            if e.code == 403 and "50013" in b:
                try: app_id = api("GET", "/users/@me")["id"]
                except SystemExit: app_id = "<APPLICATION_ID>"
                hint = ("\n→ bot に権限が足りません（チャンネルの管理など）。次の URL をサーバー管理者が開いてサーバーを選び「認証」すると権限が足されます:\n"
                        "https://discord.com/oauth2/authorize?client_id=%s&scope=bot&permissions=117840" % app_id)
            sys.exit("Discord API %s %s -> HTTP %s: %s%s" % (method, path, e.code, b[:300], hint))
    sys.exit("Discord API: 3回リトライしても失敗")


def load_json(p, default):
    if not os.path.exists(p): return default
    return json.load(io.open(p, encoding="utf-8"))


def save_json(p, obj):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    io.open(p, "w", encoding="utf-8").write(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def config():
    return load_json(CONFIG_FILE, {})


def hq_room():
    c = config()
    if c.get("hq_room"): return c["hq_room"]
    for s in load_json(STAFF_FILE, {"staff": []})["staff"]:
        if s["name"] == "統括": return s["room_id"]
    sys.exit("統括部屋が未設定です: %s に {\"hq_room\": \"<チャンネルID>\"} を書いてください" % CONFIG_FILE)


def notice_room():
    """定型のお知らせ（☀️🌙🛡 の見張りの記録など）の行き先。config.json の notice_room（C1 2026-09-30 masa決定）。無ければ None（＝統括）"""
    return config().get("notice_room") or None


def guild_of(args):
    if getattr(args, "guild", None): return args.guild
    staff = load_json(STAFF_FILE, {})
    if staff.get("guild"): return staff["guild"]
    if config().get("guild"): return config()["guild"]
    gs = api("GET", "/users/@me/guilds")
    if len(gs) == 1: return gs[0]["id"]
    sys.exit("--guild <サーバーID> を指定してください。候補: " + ", ".join("%s=%s" % (g["id"], g["name"]) for g in gs))


def cmd_whoami(args):
    me = api("GET", "/users/@me"); print("bot:", me["username"], "id:", me["id"])
    for g in api("GET", "/users/@me/guilds"):
        print("guild:", g["id"], g["name"])


def ensure_category(gid, name):
    for c in api("GET", "/guilds/%s/channels" % gid):
        if c["type"] == 4 and c["name"] == name: return c["id"]
    c = api("POST", "/guilds/%s/channels" % gid, {"name": name, "type": 4})
    print("カテゴリ作成:", name, c["id"]); return c["id"]


def ensure_room(gid, name, parent_id=None, topic=""):
    for c in api("GET", "/guilds/%s/channels" % gid):
        if c["type"] == 0 and c["name"] == name: return c["id"], False
    body = {"name": name, "type": 0, "topic": topic[:1000]}
    if parent_id: body["parent_id"] = parent_id
    c = api("POST", "/guilds/%s/channels" % gid, body)
    return c["id"], True


def register_access(channel_id):
    acc = load_json(ACCESS_FILE, {"dmPolicy": "allowlist", "allowFrom": [], "groups": {}, "pending": {}})
    acc.setdefault("groups", {})
    if channel_id not in acc["groups"]:
        # 空の allowFrom は「その部屋にいる誰でも指示できる」になるので、オーナー（トップの allowFrom）だけを写す（2026-09-29 momomon 報告 F-32）
        acc["groups"][channel_id] = {"requireMention": False, "allowFrom": list(acc.get("allowFrom") or [])}
        save_json(ACCESS_FILE, acc); print("access.json に登録:", channel_id)
    else:
        print("access.json 登録済み:", channel_id)


def register_codex(channel_id, name, role):
    """engine=codex の社員は codex_bridge.py の rooms.json に登録（Claude 側の access.json には入れない）"""
    cdir = config().get("codex_dir") or os.path.join(HOME, "Desktop", "codex-staff")
    rf = os.path.join(cdir, "rooms.json")
    if not os.path.isdir(cdir):
        print("codex-staff フォルダが無いので rooms.json は未登録:", cdir); return
    rooms = load_json(rf, {})
    if channel_id in rooms:
        print("rooms.json 登録済み:", channel_id); return
    rooms[channel_id] = {"name": name, "mode": "own", "role": role}
    save_json(rf, rooms); print("rooms.json に登録（codex）:", channel_id)


def write_persona(name, role, tone, emoji, room_id, project):
    os.makedirs(STAFF_DIR, exist_ok=True)
    tpl = io.open(TEMPLATE, encoding="utf-8").read() if os.path.exists(TEMPLATE) else "# {name}\n役割: {role}\n"
    md = tpl.format(name=name, role=role, tone=tone or "丁寧で短い。結論→根拠→次の一手。", emoji=emoji or "🙂", room_id=room_id,
                    project=project or "（未設定）", date=datetime.date.today().isoformat())
    p = os.path.join(STAFF_DIR, name + ".md")
    if not os.path.exists(p):
        io.open(p, "w", encoding="utf-8", newline="\n").write(md); print("ペルソナ作成:", p)
    else:
        print("ペルソナ既存（上書きしない）:", p)
    return p


def default_room_name(name, role, short=None):
    """部屋名＝ 名前【短い呼び名】。呼び名が空なら役割の最初の「・」「、」「／」まで（長すぎる時だけ20字で切る）"""
    label = (short or "").strip() or re.split(r"[・、，,／/]", role)[0].strip() or role
    return "%s【%s】" % (name, label if len(label) <= 20 else label[:19] + "…")


def hire_one(name, role, tone=None, emoji=None, guild=None, category=None, room=None, project=None, engine="claude", quiet=False, skill=None, short=None):
    """1人雇う。戻り値 (room_id, created)"""
    class A: pass
    a = A(); a.guild = guild
    gid = guild_of(a)
    staff = load_json(STAFF_FILE, {"guild": gid, "category": category or "AIオフィス", "staff": []})
    staff["guild"] = gid
    existing = next((s for s in staff["staff"] if s["name"] == name), None)
    cat = ensure_category(gid, staff.get("category") or category or "AIオフィス")
    if existing and existing.get("room_id"):
        rid, created = existing["room_id"], False
        room_name = existing.get("room_name") or room or default_room_name(name, role, short)
    else:
        room_name = room or default_room_name(name, role, short)
        rid, created = ensure_room(gid, room_name, cat, topic="担当: %s ／ %s" % (name, role))
    print("部屋:", room_name, rid, "(新規)" if created else "(既存)")
    if engine == "codex":
        register_codex(rid, name, role)
    else:
        register_access(rid)
    ppath = write_persona(name, role, tone, emoji, rid, project)
    if skill:
        sk = os.path.join(SKILLS_DIR, skill, "SKILL.md")
        txt = io.open(ppath, encoding="utf-8").read()
        if "この社員の道具" not in txt:
            io.open(ppath, "a", encoding="utf-8", newline="\n").write(
                "\n## この社員の道具（スキル）\n- スキル「%s」（%s）。この部屋の仕事は、まずこのスキルの SKILL.md を読んで、その手順で行う。%s\n"
                % (skill, sk, "" if os.path.exists(sk) else "※いまこのパソコンに見つからない（~/.claude/skills に入れてから）"))
    entry = {"name": name, "role": role, "emoji": emoji or "", "room_id": rid, "room_name": room_name, "engine": engine,
             "persona": (existing or {}).get("persona") or ppath, "project": project or (existing or {}).get("project", ""),
             "hired": (existing or {}).get("hired") or datetime.date.today().isoformat()}
    if skill or (existing or {}).get("skill"): entry["skill"] = skill or existing.get("skill")
    if short or (existing or {}).get("short"): entry["short"] = short or existing.get("short")
    staff["staff"] = [s for s in staff["staff"] if s["name"] != name] + [entry]
    save_json(STAFF_FILE, staff); print("staff.json 更新:", STAFF_FILE)
    if created and not quiet:
        api("POST", "/channels/%s/messages" % rid, {"content": "%s %s です。この部屋では「%s」として動きます。指示はこの部屋にそのまま書いてください。" % (emoji or "🙂", name, role)})
    return rid, created


def cmd_hire(args):
    hire_one(args.name, args.role, args.tone, args.emoji, args.guild, args.category, args.room, args.project, args.engine, args.quiet, args.skill, args.short)
    print("\n次にやること: この部屋に「%s、テスト」と書いて返事が来れば完了（再起動は不要。許可の表は発言のたびに読み直される）。" % args.name)


def parse_roster(path):
    """社員名簿.txt: 1行1人。区切りは | か ｜。列＝ 名前 | 役割 | 絵文字 | engine(claude/codex) | 正典パス | 口調 | 短い呼び名（部屋名の【】） | スキル   （後ろの列は省略可＝6列の古い名簿もそのまま読める）"""
    rows = []
    for raw in io.open(path, encoding="utf-8-sig"):
        line = raw.strip()
        if not line or line.startswith("#"): continue
        cols = [c.strip() for c in re.split(r"[|｜]", line)]
        while len(cols) < 8: cols.append("")
        name, role, emoji, engine, project, tone, short, skill = cols[:8]   # 8 列目＝この社員に持たせるスキル（例 経理 → invoice-inbox・2026-10-01）
        if not name or not role: print("名簿の行を読めません（名前と役割が必要）:", line); continue
        rows.append({"name": name, "role": role, "emoji": emoji, "engine": (engine or "claude").lower(), "project": project, "tone": tone, "short": short, "skill": skill})
    return rows


def cmd_skill(args):
    sk = os.path.join(SKILLS_DIR, args.skill_name, "SKILL.md")
    if not os.path.exists(sk):
        sys.exit("スキルが見つかりません: %s（~/.claude/skills/%s に入れてから）" % (sk, args.skill_name))
    if not attach_skill(args.name, args.skill_name):
        sys.exit("その名前の社員がいません: %s（office.py list で確認）" % args.name)


def attach_skill(name, skill):
    """もう部屋がある社員に、あとからスキルを持たせる（ペルソナに「この社員の道具」を足し、台帳に skill を書く）。部屋は触らない"""
    staff = load_json(STAFF_FILE, {"staff": []})
    s = next((x for x in staff["staff"] if x.get("name") == name), None)
    if not s:
        return False
    sk = os.path.join(SKILLS_DIR, skill, "SKILL.md")
    pp = s.get("persona")
    if pp and os.path.exists(pp):
        txt = io.open(pp, encoding="utf-8").read()
        if "スキル「%s」" % skill not in txt:
            io.open(pp, "a", encoding="utf-8", newline="\n").write(
                "\n## この社員の道具（スキル）\n- スキル「%s」（%s）。この部屋の仕事は、まずこのスキルの SKILL.md を読んで、その手順で行う。%s\n"
                % (skill, sk, "" if os.path.exists(sk) else "※いまこのパソコンに見つからない（~/.claude/skills に入れてから）"))
    s["skill"] = skill
    save_json(STAFF_FILE, staff)
    print("スキルを持たせました: %s → %s" % (name, skill))
    return True


def cmd_hire_all(args):
    rows = parse_roster(args.file)
    staff = load_json(STAFF_FILE, {"staff": []})
    known = {s["name"]: s for s in staff["staff"]}
    new = 0
    for r in rows:
        if r["name"] in known and known[r["name"]].get("room_id") and not args.refresh:
            print("既存（スキップ）:", r["name"])
            if r["skill"] and not known[r["name"]].get("skill"):   # 名簿でスキルを足した既存の社員（例 更新で経理に invoice-inbox が付いた）
                attach_skill(r["name"], r["skill"])
            continue
        rid, created = hire_one(r["name"], r["role"], r["tone"] or None, r["emoji"] or None, args.guild, None, None, r["project"] or None, r["engine"], args.quiet, skill=r["skill"] or None, short=r["short"] or None)
        new += 1 if created else 0
    if not getattr(args, "no_notice_room", False):
        staff2 = load_json(STAFF_FILE, {"staff": []})
        gid = args.guild or staff2.get("guild")
        if gid:
            cat = ensure_category(gid, staff2.get("category") or "AIオフィス")
            ensure_notice_room(gid, cat)
    print("NEW=%d" % new)


def cmd_test_room(args):
    """名簿の2人目（統括の次）の部屋名。台帳にあればその部屋名、無ければ作られるはずの名前。1人だけなら統括"""
    rows = parse_roster(args.file)
    if not rows: print("統括【統括】"); return
    r = rows[1] if len(rows) > 1 else rows[0]
    known = {s["name"]: s for s in load_json(STAFF_FILE, {"staff": []})["staff"]}
    print((known.get(r["name"]) or {}).get("room_name") or default_room_name(r["name"], r["role"], r["short"]))


def room_links(s, gid):
    dm = (s.get("room_name") or "").startswith("（DM") or s.get("dm")
    base = "%s/%s" % ("@me" if dm else gid, s["room_id"])
    return "https://discord.com/channels/" + base, "discord://discord.com/channels/" + base


HTML_HEAD = """<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes"><title>AIオフィス</title>
<style>body{font-family:-apple-system,"Hiragino Sans","Noto Sans JP",sans-serif;margin:0;padding:16px;background:#111;color:#eee}
h1{font-size:20px;margin:8px 0 16px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}
a.room{display:block;background:#1f2937;border-radius:16px;padding:18px 12px;text-decoration:none;color:#fff;text-align:center;box-shadow:0 2px 6px #0006}
a.room .e{font-size:34px;display:block}a.room .n{font-size:17px;font-weight:700;display:block;margin-top:6px}a.room .r{font-size:12px;color:#9ca3af;display:block;margin-top:2px}
.how{margin-top:28px;font-size:13px;color:#cbd5e1;line-height:1.7}.how code{background:#222;padding:1px 5px;border-radius:4px}
button{margin-top:6px;font-size:12px;background:#374151;color:#eee;border:0;border-radius:8px;padding:4px 8px}</style></head><body>
<h1>🏢 AIオフィス — 部屋一覧</h1><div class="grid">
"""
HTML_TAIL = """</div>
<div class="how"><b>iPhone のホーム画面に「部屋ごとのアイコン」を作る（ショートカット）</b><br>
①「ショートカット」アプリ → ＋ → アクションを追加 →「URLを開く」<br>
② URL に、この一覧の下の <code>discord://…</code> を貼る（長押しコピー）<br>
③ 右上の共有 →「ホーム画面に追加」→ 名前を社員名にして追加<br>
（この一覧ページ自体を Safari の「ホーム画面に追加」で1個置く手もあります）</div>
<div class="how"><b>Android のホーム画面に「部屋ごとのアイコン」を作る</b><br>
① Discord アプリでその部屋を開いて、一言書く（「テスト」でOK）<br>
② ホーム画面で Discord のアイコンを長押し → 最近の部屋が出る<br>
③ 出てきた部屋を長押ししたまま、ホーム画面の空いている所へ引っぱって離す<br>
（Chrome の「ホーム画面に追加」は Discord アプリに飛ばないので使いません）</div>
<div class="how"><b>コピー用リンク</b><br>
"""


def cmd_links(args):
    staff = load_json(STAFF_FILE, {"staff": []}); gid = staff.get("guild") or config().get("guild")
    if not gid: sys.exit("guild が未設定（staff.json）")
    md = ["# AIオフィス 部屋リンク一覧（%s）" % datetime.date.today().isoformat(), "",
          "| 社員 | 役割 | アプリで開く（ショートカット用） | ブラウザ |", "|---|---|---|---|"]
    html = [HTML_HEAD]; copy = []
    for s in staff["staff"]:
        web, app = room_links(s, gid)
        md.append("| %s %s | %s | %s | %s |" % (s.get("emoji", ""), s["name"], s["role"], app, web))
        html.append('<a class="room" href="%s"><span class="e">%s</span><span class="n">%s</span><span class="r">%s</span></a>\n'
                    % (app, s.get("emoji") or "🙂", s["name"], s["role"][:14]))
        copy.append('%s %s<br><code id="c%s">%s</code> <button onclick="navigator.clipboard.writeText(document.getElementById(\'c%s\').textContent)">コピー</button><br>'
                    % (s.get("emoji", ""), s["name"], s["room_id"], app, s["room_id"]))
    html.append(HTML_TAIL); html.extend(copy); html.append("</div></body></html>")
    outs = [OFFICE_DIR] + ([args.out] if args.out else [])
    for d in outs:
        os.makedirs(d, exist_ok=True)
        io.open(os.path.join(d, "links.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
        io.open(os.path.join(d, "links.html"), "w", encoding="utf-8").write("".join(html))
        print("書き出し:", os.path.join(d, "links.md"), "/ links.html")
    if args.post:
        ch = hq_room() if args.post == "hq" else args.post
        api("POST", "/channels/%s/messages" % ch, {"content": "🏢 部屋リンク一覧（%d部屋）。各部屋「名前」→「リンク」の順に1つずつ送ります。リンクを長押しコピーして、ショートカットの「URLを開く」に貼ると、その部屋を開くアイコンになります。" % len(staff["staff"])})
        for s in staff["staff"]:
            web, app = room_links(s, gid)
            api("POST", "/channels/%s/messages" % ch, {"content": "%s %s（%s）" % (s.get("emoji", ""), s["name"], s["role"])}); time.sleep(0.4)
            api("POST", "/channels/%s/messages" % ch, {"content": app}); time.sleep(0.4)
        print("投稿:", ch)


def cmd_backup(args):
    out = args.out or os.path.join(OFFICE_DIR, "backups")
    os.makedirs(out, exist_ok=True)
    zp = os.path.join(out, "ai-office_%s.zip" % datetime.datetime.now().strftime("%Y%m%d_%H%M"))
    targets = [ACCESS_FILE, STAFF_FILE, CONFIG_FILE, os.path.join(HOME, ".claude", "CLAUDE.md")]
    SECRET_NAME = re.compile(r"(?i)(^|\.)env(\.|$)|\.dev\.vars$|credential|\.pem$|\.key$|\.p12$|\.pfx$|_token|token\.txt$|\.fal_key$|\.dpapi$|id_(rsa|ed25519|ecdsa)|\.netrc$|\.npmrc$|\.pypirc$|\.jsonl$|secrets?\.(json|ya?ml|txt)$")   # 監査 中10
    dirs = [STAFF_DIR, os.path.join(HOME, ".claude", "projects"), SKILL_DIR, LOCAL_DIR]
    for extra in config().get("backup_extra", []): dirs.append(os.path.expanduser(extra))
    n = 0
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in targets:
            if os.path.exists(f): z.write(f, os.path.relpath(f, HOME)); n += 1
        sj = load_json(os.path.join(HOME, ".claude", "settings.json"), None)   # settings.json は env（API キーを書く人がいる）を落として入れる
        if isinstance(sj, dict):
            sj.pop("env", None); z.writestr(".claude/settings.json", json.dumps(sj, ensure_ascii=False, indent=2)); n += 1
        for d in dirs:
            for root, _, files in os.walk(d):
                for fn in files:
                    if SECRET_NAME.search(fn): continue   # 秘密と巨大ログは入れない（監査 中10: 語尾一致だけでは .env.local・*.pem・credentials.json が抜けた）
                    p = os.path.join(root, fn)
                    try:
                        if os.path.getsize(p) > 20 * 1024 * 1024: continue
                        z.write(p, os.path.relpath(p, HOME)); n += 1
                    except OSError: pass
    print("backup:", zp, n, "files")
    keep = int(config().get("backup_keep", 14))
    olds = sorted(f for f in os.listdir(out) if f.startswith("ai-office_") and f.endswith(".zip"))
    for f in olds[:-keep]:
        os.remove(os.path.join(out, f)); print("古いバックアップ削除:", f)


def ensure_notice_room(gid, cat):
    """お知らせ専用の部屋。無ければ作って staff.json に kind="notice" で登録し、config.json の notice_room に書く
    （C1 2026-09-30 masa決定「お知らせ専用の部屋を全員に標準で作る」）。hello_counts の社員数には数えない"""
    staff = load_json(STAFF_FILE, {"guild": gid, "category": "AIオフィス", "staff": []})
    existing = next((x for x in staff["staff"] if x.get("kind") == "notice"), None)
    pre = str(config().get("notice_room") or "")   # 自分で config.json に notice_room を書いていた人（自社版など）はその部屋を採用＝新しく作らない
    if existing and existing.get("room_id"):
        rid, created = existing["room_id"], False
    else:
        if pre.isdigit() and 15 <= len(pre) <= 21: rid, created = pre, False
        else:
            rid, created = ensure_room(gid, "お知らせ", cat, topic="☀️🌙🛡 など定型のお知らせ専用。担当への指示はここには書かない")
            register_access(rid)
        entry = {"name": "お知らせ", "role": "定型のお知らせ専用（自動投稿）", "emoji": "📣", "room_id": rid, "room_name": "お知らせ",
                 "engine": "claude", "kind": "notice", "persona": "", "project": "", "hired": datetime.date.today().isoformat()}
        staff["staff"] = [x for x in staff["staff"] if x.get("kind") != "notice"] + [entry]
        save_json(STAFF_FILE, staff)
    print(("作成" if created else "既存"), "お知らせ", rid)
    cfg = config()
    if cfg.get("notice_room") != rid:
        cfg["notice_room"] = rid; save_json(CONFIG_FILE, cfg); print("config.json 更新: notice_room=%s" % rid)
    return rid


def cmd_setup(args):
    gid = guild_of(args)
    staff = load_json(STAFF_FILE, {"guild": gid, "category": args.category or "AIオフィス", "staff": []})
    staff["guild"] = gid; staff["category"] = args.category or staff.get("category") or "AIオフィス"
    cat = ensure_category(gid, staff["category"])
    for s in staff["staff"]:
        rid, created = ensure_room(gid, s.get("room_name") or default_room_name(s["name"], s["role"], s.get("short")), cat, topic="担当: %s ／ %s" % (s["name"], s["role"]))
        s["room_id"] = rid
        if s.get("engine") == "codex": register_codex(rid, s["name"], s["role"])
        else: register_access(rid)
        s["persona"] = write_persona(s["name"], s["role"], s.get("tone"), s.get("emoji"), rid, s.get("project"))
        print(("作成" if created else "既存"), s["name"], rid)
    save_json(STAFF_FILE, staff); print("完了:", STAFF_FILE)
    if not getattr(args, "no_notice_room", False):
        ensure_notice_room(gid, cat)


def cmd_list(args):
    staff = load_json(STAFF_FILE, {"staff": []})
    print("guild:", staff.get("guild"), "category:", staff.get("category"))
    for s in staff["staff"]:
        print("%s %-8s %-20s room=%s  engine=%s  %s%s" % (s.get("emoji", ""), s["name"], s["role"][:20], s["room_id"], s.get("engine", "claude"), s.get("project", ""), "  [休止]" if s.get("archived") else ""))


def hello_counts():
    """社員（kind が project でも notice でもない）／動いている開発部屋／休止中の開発部屋 の数
    （momomon K-33: 「社員N人」に開発部屋を混ぜない。C1 2026-09-30: 「お知らせ」部屋（kind=notice）も混ぜない）"""
    staff = load_json(STAFF_FILE, {"staff": []}).get("staff", [])
    emp = [x for x in staff if x.get("kind") not in ("project", "notice")]
    proj = [x for x in staff if x.get("kind") == "project" and not x.get("archived")]
    arch = [x for x in staff if x.get("kind") == "project" and x.get("archived")]
    return len(emp), len(proj), len(arch)


LOCAL_FILES = [("起動時の指示.txt", "起動の指示文（デスクトップのものより優先）"), ("CLAUDE_local.md", "CLAUDE.md に足す決まり（キットの目印の内側）"),
               ("office_ext.py", "office.py の命令の追加・差し替え（COMMANDS / setup）"), ("guard_rules.py", "見張りの追加規則（rules）"),
               ("start_hook.sh", "起動フック Mac（環境変数など）"), ("start_hook.ps1", "起動フック Windows（環境変数など）")]
LOCAL_TPL = os.path.join(SKILL_DIR, "templates", "local")


def _load_local_ext():
    """~/.claude/ai-office/local/office_ext.py（持ち主の追加）。COMMANDS = {"名前": 関数(args)}／setup(office) を持てる。読めなければ無視"""
    p = os.path.join(LOCAL_DIR, "office_ext.py")
    if not os.path.exists(p): return None
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("aio_office_ext", p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
        if hasattr(m, "setup"): m.setup(sys.modules[__name__])
        return m
    except Exception as e:
        print("⚠ local/office_ext.py を読めませんでした（無視して続けます）: %s" % str(e)[:200], file=sys.stderr); return None


def cmd_local(args):
    """init: 置き場と説明書・例（*.example）を作る／status: 何が有効か"""
    if args.action == "init":
        os.makedirs(LOCAL_DIR, exist_ok=True)
        n = 0
        if os.path.isdir(LOCAL_TPL):
            for fn in sorted(os.listdir(LOCAL_TPL)):
                dst = os.path.join(LOCAL_DIR, fn)
                if fn == "README.txt" or not os.path.exists(dst): shutil.copyfile(os.path.join(LOCAL_TPL, fn), dst); n += 1
        print("置き場: %s（%d ファイルを置きました。*.example の .example を外すと有効）" % (LOCAL_DIR, n))
    if not os.path.isdir(LOCAL_DIR):
        print("持ち主の置き場はまだありません: %s（python office.py local init で作る）" % LOCAL_DIR); print("LOCAL=0"); return
    on = 0
    for fn, desc in LOCAL_FILES:
        ok = os.path.exists(os.path.join(LOCAL_DIR, fn)); on += ok
        print("  %s %s … %s" % ("✅" if ok else "・", fn, desc))
    print("有効 %d 件（更新で触らない置き場: %s。guard_rules.py・start_hook.* を変えたら python office.py guard rehash）" % (on, LOCAL_DIR)); print("LOCAL=%d" % on)


MANIFEST_NAME = "manifest.json"
MANIFEST_SKIP = ("__pycache__", ".DS_Store", MANIFEST_NAME)


def _manifest_of(d):
    import hashlib
    out = {}
    for root, dirs, files in os.walk(d):
        dirs[:] = [x for x in dirs if x not in MANIFEST_SKIP]
        for fn in files:
            if fn in MANIFEST_SKIP or fn.endswith(".pyc"): continue
            fp = os.path.join(root, fn)
            try: out[os.path.relpath(fp, d).replace("\\", "/")] = hashlib.sha256(open(fp, "rb").read()).hexdigest()
            except OSError: pass
    return out


def cmd_manifest(args):
    """write: いまの skill フォルダの正の一覧を manifest.json に（ビルド時）／diff <古い skill フォルダ>: 古い版の manifest と実ファイルを照合し、利用者が変えたファイルを出す"""
    if args.action == "write":
        d = os.path.abspath(args.dir or SKILL_DIR)
        m = _manifest_of(d)
        save_json(os.path.join(d, MANIFEST_NAME), {"files": m, "at": time.strftime("%Y-%m-%d %H:%M")})
        print("manifest: %d files -> %s" % (len(m), os.path.join(d, MANIFEST_NAME))); return
    old = os.path.abspath(args.dir or SKILL_DIR)
    ref = load_json(os.path.join(old, MANIFEST_NAME), None)
    if not ref:
        print("古い版に manifest.json がありません（この版より前）＝比較できません。控えは丸ごと残します"); print("CHANGED=-1"); return
    cur = _manifest_of(old); refm = ref.get("files", {})
    changed = sorted([k for k in cur if k in refm and refm[k] != cur[k]])
    added = sorted([k for k in cur if k not in refm])
    for k in changed: print("変更: " + k)
    for k in added: print("追加: " + k)
    print("CHANGED=%d" % (len(changed) + len(added)))
    if args.out:
        io.open(args.out, "w", encoding="utf-8", newline="\n").write("".join("変更: %s\n" % k for k in changed) + "".join("追加: %s\n" % k for k in added))


def cmd_hello(args):
    e, pj, ar = hello_counts()
    line = "社員 %d 人" % e + ("・開発部屋 %d 件" % pj if pj else "") + ("（休止 %d 件）" % ar if ar else "")
    print(line); print("HELLO=" + line)
    nid = notice_room()
    if nid: print("NOTICE=" + str(nid))


def cmd_archive(args):
    """開発部屋を休止（archived）にする／戻す。部屋もフォルダも消さない。起動の人数に数えない・03:50 の引き継ぎ更新の対象外（momomon K-34）"""
    st = load_json(STAFF_FILE, {"staff": []})
    hit = [x for x in st.get("staff", []) if x.get("name") == args.name]
    if not hit: sys.exit("その名前の部屋がありません: %s（office.py list で確認）" % args.name)
    if hit[0].get("kind") != "project": sys.exit("休止にできるのは開発部屋だけです（社員は office.py fire）: %s" % args.name)
    hit[0]["archived"] = not args.off
    save_json(STAFF_FILE, st)
    print("%s を%s（部屋とフォルダはそのまま。起動の人数に%s）" % (args.name, "休止にしました" if not args.off else "戻しました", "数えません" if not args.off else "数えます")); print("ARCHIVED=%s" % ("1" if not args.off else "0"))


def cmd_say(args):
    api("POST", "/channels/%s/messages" % args.channel, {"content": args.text}); print("sent")


def cmd_notice(args):
    text = args.text
    problem = text.lstrip().startswith(("⚠", "🛡⚠"))   # ⚠ / ⚠️ / 🛡⚠️ で始まる＝確認が要る→統括のまま（C1 2026-09-30）
    room = hq_room() if (problem or getattr(args, "hq", False)) else (notice_room() or hq_room())
    api("POST", "/channels/%s/messages" % room, {"content": text}); print("sent")


def cmd_ask(args):
    labels = args.choices
    lines = [args.question] + ["%s **%s** … %s" % (FLAGS[i], chr(65 + i), c) for i, c in enumerate(labels)] + ["↓ 絵文字をタップして選んでください"]
    m = api("POST", "/channels/%s/messages" % args.channel, {"content": "\n".join(lines)})
    mid = m["id"]
    for i in range(len(labels)):
        api("PUT", "/channels/%s/messages/%s/reactions/%s/@me" % (args.channel, mid, urllib.request.quote(FLAGS[i])))
        time.sleep(0.3)
    me = api("GET", "/users/@me")["id"]
    deadline = time.time() + args.timeout
    while time.time() < deadline:
        time.sleep(args.poll)
        for i in range(len(labels)):
            users = api("GET", "/channels/%s/messages/%s/reactions/%s" % (args.channel, mid, urllib.request.quote(FLAGS[i])))
            if any(u["id"] != me for u in users):
                print("%d\t%s" % (i + 1, labels[i])); return
    print("0\tTIMEOUT")


def cmd_fire(args):
    staff = load_json(STAFF_FILE, {"staff": []})
    s_ = next((x for x in staff["staff"] if x["name"] == args.name), None)
    if not s_: sys.exit("社員「%s」は台帳にいません（office.py list で確認）" % args.name)
    if s_["name"] == "統括" or s_.get("room_id") == config().get("hq_room"):
        sys.exit("統括は外せません（振り分けと「引き継いで」の窓口のため）")
    staff["staff"] = [x for x in staff["staff"] if x["name"] != args.name]
    save_json(STAFF_FILE, staff)
    acc = load_json(ACCESS_FILE, {"groups": {}})
    if acc.get("groups", {}).pop(s_["room_id"], None) is not None:
        save_json(ACCESS_FILE, acc); print("access.json から外しました:", s_["room_id"])
    if not args.quiet:
        try: api("POST", "/channels/%s/messages" % s_["room_id"], {"content": "👋 %s はこの部屋の担当から外れました。この部屋に書いても、もう返事はしません（部屋は Discord の設定からいつでも消せます）。" % args.name})
        except SystemExit: pass
    print("外しました:", args.name, "（部屋とペルソナ %s は残しています）" % s_.get("persona", ""))


def cmd_watch_replies(args):
    """人の発言のあと N 分たっても bot の返事が無ければ、その部屋に1回だけ知らせる（通信切れ・固まりの見張り）。
    再起動の前後（毎時 xx:00 前後の予告〜☀️）でも誤報しないよう、🌙 の予告から15分は黙る。"""
    if os.path.exists(PAUSE_FLAG): print("WATCH paused"); return
    staff = load_json(STAFF_FILE, {"staff": []})
    state_f = os.path.join(OFFICE_DIR, "watch_replies.json")
    state = load_json(state_f, {"flagged": []})
    flagged = set(state.get("flagged", []))
    now = time.time(); wait = args.minutes * 60
    posted = 0
    for s_ in staff["staff"]:
        if s_.get("engine", "claude") != "claude" or not s_.get("room_id"): continue
        try: msgs = api("GET", "/channels/%s/messages?limit=15" % s_["room_id"])
        except SystemExit: continue
        if not msgs: continue
        def ts(m): return datetime.datetime.fromisoformat(m["timestamp"].replace("Z", "+00:00")).timestamp()
        # 直近の再起動予告（🌙）から15分は見張らない
        if any(m["author"].get("bot") and m.get("content", "").startswith("🌙") and now - ts(m) < 900 for m in msgs): continue
        last_bot = max([ts(m) for m in msgs if m["author"].get("bot")] or [0])
        for m in msgs:   # 新しい順
            if m["author"].get("bot"): continue
            text = (m.get("content") or "").strip()
            if len(text) <= 2 and not m.get("attachments"): continue   # 「ok」「🤣」など返事が要らないもの
            age = now - ts(m)
            if ts(m) > last_bot and wait <= age <= 3 * 3600 and m["id"] not in flagged:
                try:
                    api("POST", "/channels/%s/messages" % s_["room_id"], {
                        "content": "⚠️ まだ返事が出せていません（通信が切れたか、作業が止まっているかもしれません）。少し待っても来なければ、もう一度送ってください。続くときはデスクトップの AIオフィス の「再起動」をダブルクリック。",
                        "message_reference": {"message_id": m["id"]}})
                    flagged.add(m["id"]); posted += 1
                except SystemExit:
                    pass
            break   # いちばん新しい人の発言だけ見る
    state["flagged"] = sorted(flagged)[-500:]
    save_json(state_f, state)
    try:   # C4 2026-09-30: 使用量の目安を名前に（5分おき・4分未満は飛ばす）。失敗しても watch-replies 本体の結果は変えない
        c = config()
        if c.get("usage_nick", "on") != "off":
            last_u = c.get("usage_nick_at") or 0
            if now - last_u >= 240:
                c["usage_nick_at"] = now; save_json(CONFIG_FILE, c)
                _, udata = usage_report(7)
                upct = _usage_pct(udata)
                if upct is not None: _usage_nick_apply(upct, _usage_pct_week(udata))
    except Exception as e:
        print("USAGE_NICK_WATCH_ERR=%s" % e)
    print("WATCH posted=%d" % posted)


# ---------------------------------------------------------------- 引き継ぎ診断・開発部屋
PROJECTS_DIR = os.path.join(HOME, ".claude", "projects")
SKILLS_DIR = os.path.join(HOME, ".claude", "skills")
DEV_TEMPLATE = os.path.join(SKILL_DIR, "templates", "project_room.md")


def encode_project(path):
    """Claude Code がプロジェクトごとの保存場所に使う名前（英数字以外を - にする）"""
    return re.sub(r"[^A-Za-z0-9]", "-", os.path.abspath(os.path.expanduser(path)))


def memory_dir_for(folder):
    """Claude Code のメモリ置き場。git リポジトリの中ならリポジトリの一番上、外ならそのフォルダで決まる（公式ドキュメント memory の Storage location）"""
    d = os.path.abspath(os.path.expanduser(folder)); cur = d
    while True:
        if os.path.exists(os.path.join(cur, ".git")):
            d = cur; break
        up = os.path.dirname(cur)
        if up == cur: break
        cur = up
    return os.path.join(PROJECTS_DIR, encode_project(d), "memory")


def _cwd_of(pdir):
    """projects/<名前>/ の会話ログ（*.jsonl）から、そのプロジェクトの作業フォルダ（cwd）を読む"""
    logs = sorted((f for f in os.listdir(pdir) if f.endswith(".jsonl")), key=lambda f: os.path.getmtime(os.path.join(pdir, f)), reverse=True)
    for f in logs[:3]:
        try:
            with io.open(os.path.join(pdir, f), encoding="utf-8", errors="ignore") as fh:
                for i, line in enumerate(fh):
                    if i > 200: break
                    m = re.search(r'"cwd":\s*"((?:[^"\\]|\\.)*)"', line)
                    if m: return json.loads('"%s"' % m.group(1))
        except OSError:
            pass
    return None


def scan_projects():
    out = []
    if not os.path.isdir(PROJECTS_DIR): return out
    office_dir = config().get("office_dir") or ""
    for name in os.listdir(PROJECTS_DIR):
        pdir = os.path.join(PROJECTS_DIR, name)
        if not os.path.isdir(pdir): continue
        logs = [f for f in os.listdir(pdir) if f.endswith(".jsonl")]
        cwd = _cwd_of(pdir) or ""
        mem = memory_dir_for(cwd) if cwd else os.path.join(pdir, "memory")
        mem_files = [f for f in os.listdir(mem) if f.endswith(".md")] if os.path.isdir(mem) else []
        if not logs and not mem_files: continue
        last = max([os.path.getmtime(os.path.join(pdir, f)) for f in logs] + [os.path.getmtime(pdir)])
        nc = os.path.normcase(os.path.abspath(cwd or "x"))
        home_like = nc in (os.path.normcase(HOME), os.path.normcase(os.path.join(HOME, "Desktop"))) or             any(t in nc.replace("\\", "/") for t in ("/appdata/local/temp", "/tmp", "/var/folders", "/private/var"))
        is_office = bool(office_dir) and os.path.normcase(os.path.abspath(cwd or "x")) == os.path.normcase(os.path.abspath(office_dir))
        out.append({"key": name, "cwd": cwd, "exists": bool(cwd) and os.path.isdir(cwd), "sessions": len(logs),
                    "memory_files": len(mem_files), "memory_dir": mem, "last": last, "home_like": home_like, "is_office": is_office})
    out.sort(key=lambda p: p["last"], reverse=True)
    return out


def scan_skills():
    out = []
    if not os.path.isdir(SKILLS_DIR): return out
    for name in sorted(os.listdir(SKILLS_DIR)):
        sk = os.path.join(SKILLS_DIR, name, "SKILL.md")
        if not os.path.exists(sk): continue
        desc = ""
        for line in io.open(sk, encoding="utf-8", errors="ignore"):
            if line.startswith("description:"):
                desc = line.split(":", 1)[1].strip().strip('"')[:60]; break
        out.append({"name": name, "desc": desc})
    return out


def cmd_migrate(args):
    skills = scan_skills()
    projects = [p for p in scan_projects() if not p["is_office"]]
    claude_md = os.path.join(HOME, ".claude", "CLAUDE.md")
    staff = load_json(STAFF_FILE, {"staff": []})
    linked = {os.path.normcase(os.path.abspath(s["project"])) for s in staff["staff"] if s.get("kind") == "project" and s.get("project")}
    cand = [p for p in projects if p["exists"] and not p["home_like"] and os.path.normcase(os.path.abspath(p["cwd"])) not in linked]
    if args.short:
        print("引き継ぎ診断: スキル %d 個・プロジェクト %d 個（部屋にできるもの %d 個）" % (len(skills), len(projects), len(cand)))
        print("CANDIDATES=%d" % len(cand))
        print("SKILLS=%d" % len([k for k in skills if k["name"] != "discord-ai-office"]))
        return
    L = ["# 引き継ぎ診断（%s）" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "",
         "デスクトップアプリ（コード）や Claude Code で使ってきたものの一覧です。AIオフィスは同じパソコンの同じ Claude Code で動くので、ここにあるものはそのまま使えます。", "",
         "## 1. 全体の決まりごと（CLAUDE.md）",
         ("あり（%d 文字）→ Discord の部屋でも毎回読まれます" % len(io.open(claude_md, encoding="utf-8", errors="ignore").read())) if os.path.exists(claude_md) else "なし", "",
         "## 2. スキル（%d 個）→ Discord の部屋でもそのまま使えます" % len(skills)]
    sk_cand = [k for k in skills if k["name"] != "discord-ai-office"]
    hired_sk = {x.get("skill") for x in staff["staff"] if x.get("skill")}
    L += ["S%d. %s … %s%s" % (i, k["name"], k["desc"], "（社員にしてあります）" if k["name"] in hired_sk else "") for i, k in enumerate(sk_cand, 1)] or ["- （なし）"]
    L += ["→ S の番号のスキルは「社員」にできます（そのスキル専用の部屋ができて、その部屋ではそのスキルで仕事をします）"]
    L += ["", "## 3. プロジェクト（フォルダごとの会話とメモリ）", "番号の付いたものは「開発部屋」にできます。部屋にすると、その部屋の AI はこのフォルダのメモリを読み書きします（デスクトップで開いても同じメモリ）。", ""]
    for i, p in enumerate(cand, 1):
        L.append("%d. %s\n   最終 %s ・ 会話 %d 回 ・ メモリ %d 件" % (i, p["cwd"], datetime.datetime.fromtimestamp(p["last"]).strftime("%Y-%m-%d"), p["sessions"], p["memory_files"]))
    if not cand: L.append("（部屋にできるプロジェクトはありません）")
    rest = [p for p in projects if p not in cand]
    if rest:
        L += ["", "部屋にしないもの（ホーム／デスクトップ直下・フォルダが無い・部屋にしてあるもの）:"]
        L += ["- %s（メモリ %d 件）" % (p["cwd"] or p["key"], p["memory_files"]) for p in rest]
    L += ["", "## 4. 引き継げないもの",
          "- デスクトップアプリの普通のチャット（コードではない方）の会話・メモリ・プロジェクトは Anthropic のサーバー側にあり、このパソコンからは読めません。残したい内容は、そのチャットで「今までの決まりごとを箇条書きにして」と頼み、出てきた文を統括の部屋に貼ってください。CLAUDE.md に入れます。",
          "- 会話の途中の続き（セッション）は引き継ぎません。代わりに開発部屋ごとに AI が「引き継ぎメモ」を書き、次はそこから続けます。"]
    text = "\n".join(L) + "\n"
    print(text)
    outs = [OFFICE_DIR] + ([args.out] if args.out else [])
    for d in outs:
        os.makedirs(d, exist_ok=True)
        io.open(os.path.join(d, "引き継ぎ診断.txt"), "w", encoding="utf-8", newline="\n").write(text)
    save_json(os.path.join(OFFICE_DIR, "migrate.json"), {"candidates": [p["cwd"] for p in cand], "skills": [k["name"] for k in sk_cand]})
    print("CANDIDATES=%d" % len(cand))
    print("SKILLS=%d" % len(sk_cand))


def _safe_folder(name):
    """フォルダ名は英数字だけにする（日本語は Claude Code のメモリ置き場の名前で全部 - になり、別の開発とぶつかるため）"""
    n = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-.")
    return n if len(re.sub(r"[^A-Za-z0-9]", "", n)) >= 3 else "project-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


def _git_root(d):
    cur = os.path.abspath(d)
    while True:
        if os.path.exists(os.path.join(cur, ".git")):
            return cur
        up = os.path.dirname(cur)
        if up == cur:
            return None
        cur = up


def _norm_name(x):
    return re.sub(r"[\s_.-]+", "", (x or "").lower())


def _find_project_folder(names):
    """[T-0354 自社改変・手軽化] 開発フォルダの置き場（config の dev_root と project_roots）から、名前が同じフォルダを探す"""
    keys = {_norm_name(n) for n in names if n and _norm_name(n)}
    roots = [config().get("dev_root")] + list(config().get("project_roots") or []) + [os.path.join(HOME, "ai-office-dev")]
    for r in roots:
        if not r:
            continue
        r = os.path.expanduser(r)
        try:
            for e in sorted(os.listdir(r)):
                if os.path.isdir(os.path.join(r, e)) and _norm_name(e) in keys:
                    return os.path.join(r, e)
        except OSError:
            continue
    return None


def _seed_project(d, name, slug, brief):
    """[T-0354 自社改変・手軽化] 新しいフォルダに CLAUDE.md と .gitignore を置く（あれば触らない）"""
    cm = os.path.join(d, "CLAUDE.md")
    if not os.path.exists(cm):
        io.open(cm, "w", encoding="utf-8", newline="\n").write(
            "# %s\n\n- 目的: %s\n- 作成: %s（Discord の開発部屋「%s」から）\n- PC のデスクトップアプリでこのフォルダを開けば、同じメモリ・引き継ぎメモで続けられる。\n\n"
            "## 決まり\n- 秘密（トークン・パスワード・API キー）はコードに書かず `.env`／`.dev.vars` に置き、git に入れない。\n"
            "- 公開・削除・外への送信は、Discord ではオーナーの ✅（見張りの関所）を通す。\n"
            % (name, (brief or "（未記入・最初の相談で決める）").strip(), datetime.date.today().isoformat(), name))
    gi = os.path.join(d, ".gitignore")
    if not os.path.exists(gi):
        io.open(gi, "w", encoding="utf-8", newline="\n").write("node_modules/\n.env\n.env.*\n!.env.example\n.dev.vars\n.wrangler/\ndist/\n__pycache__/\n")


def _register_hq(d, name, slug, brief):
    """[T-0354 自社改変・手軽化] 管制塔（hq-dashboard）の登録簿に載せる。登録簿の土台（オフィス）の外のフォルダは載せない"""
    reg = os.path.expanduser(config().get("hq_registry") or "")
    base = os.path.expanduser(config().get("hq_base") or "")
    if not reg or not base or not os.path.exists(reg):
        return "（登録簿の設定なし）"
    rel = os.path.relpath(d, base).replace("\\", "/")
    if rel.startswith("..") or os.path.isabs(rel):
        return "（オフィスの外のフォルダなので載せない）"
    data = json.load(io.open(reg, encoding="utf-8"))
    if any(p.get("path") == rel or p.get("slug") == slug for p in data.get("projects", [])):
        return "登録済み"
    data.setdefault("projects", []).append({"slug": slug, "name": name, "kind": "product", "status": "developing",
                                            "description": (brief or "").strip()[:160], "path": rel,
                                            "own_git": os.path.exists(os.path.join(d, ".git")), "ledger_match": [name, slug]})
    io.open(reg, "w", encoding="utf-8", newline="\n").write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    return "載せた（%s）" % rel


def cmd_project(args):
    name = args.name.strip()
    cand = load_json(os.path.join(OFFICE_DIR, "migrate.json"), {}).get("candidates", [])
    d = args.dir
    base = config().get("dev_root") or os.path.join(HOME, "ai-office-dev")
    if d and d.strip().isdigit():      # 診断の番号で指定（--dir 3）
        i = int(d) - 1
        if not 0 <= i < len(cand): sys.exit("番号 %s は引き継ぎ診断の一覧にありません（先に office.py migrate を実行。候補 %d 個）" % (d, len(cand)))
        d = cand[i]
    slug = (args.slug or "").strip()
    if not d:   # [T-0354 自社改変・手軽化] 名前・英語名が既存のフォルダと同じなら、それを部屋にする
        d = _find_project_folder([slug, name])
    if not d:
        if not slug and not re.search(r"[A-Za-z0-9]{3}", name):
            sys.exit("名前が日本語なので、フォルダ用の英語の短い名前を --slug で付けてください（例: --slug store-game）")
        d = os.path.join(base, slug or _safe_folder(name))
    d = os.path.expanduser(d)
    if not os.path.isabs(d):           # 「store-game」のような名前だけなら開発フォルダの下に置く
        d = os.path.join(base, d)
    d = os.path.abspath(d)
    slug = slug or os.path.basename(d)
    fresh = not os.path.exists(d)
    os.makedirs(d, exist_ok=True)
    in_repo = _git_root(d) is not None
    if fresh and not in_repo:   # リポジトリの外に作るときだけ git の置き場にする（中なら親のリポジトリで管理＝PC と同じメモリ）
        try:
            import subprocess
            subprocess.run(["git", "init", "-q", d], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
        except Exception:
            pass
    if fresh:
        _seed_project(d, name, slug, args.brief)
    # このフォルダのメモリ置き場（デスクトップアプリで開いたときと同じ場所）
    mem = memory_dir_for(d)
    os.makedirs(mem, exist_ok=True)
    shared = os.path.abspath(_git_root(d) or d) != d   # 親のリポジトリと共用のメモリなら、引き継ぎメモはプロジェクトごとのファイルに
    hname = ("handoff-%s.md" % slug) if shared else "handoff.md"
    handoff = os.path.join(mem, hname)
    if not os.path.exists(handoff):
        body = "## 決まったこと\n\n## 途中のもの\n\n## 次の一手\n" + (("- 目的: " + args.brief.strip() + "\n") if args.brief else "")
        io.open(handoff, "w", encoding="utf-8", newline="\n").write("---\nname: %s\ndescription: 開発「%s」の引き継ぎメモ（Discord の開発部屋とデスクトップで共通）。作業の区切りで更新する\nmetadata:\n  type: project\n---\n\n%s" % (hname[:-3], name, body))
    index = os.path.join(mem, "MEMORY.md")
    line = "- [引き継ぎ・%s](%s) — Discord の開発部屋「%s」とデスクトップで共通。この開発を始める前に読む" % (name, hname, name)
    cur = io.open(index, encoding="utf-8").read() if os.path.exists(index) else ""
    if hname not in cur:
        io.open(index, "w", encoding="utf-8", newline="\n").write((cur.rstrip("\n") + "\n" if cur else "") + line + "\n")
    hq = _register_hq(d, name, slug, args.brief)
    # 部屋
    class A: pass
    a = A(); a.guild = None
    gid = guild_of(a)
    staff = load_json(STAFF_FILE, {"guild": gid, "category": "AIオフィス", "staff": []})
    staff["guild"] = gid
    existing = next((s for s in staff["staff"] if s["name"] == name), None)
    cat = ensure_category(gid, config().get("dev_category") or "開発")
    if existing and existing.get("room_id"):
        rid, created = existing["room_id"], False
    else:
        rid, created = ensure_room(gid, name, cat, topic="開発部屋 ／ フォルダ: %s" % d)
    register_access(rid)
    os.makedirs(STAFF_DIR, exist_ok=True)
    ppath = os.path.join(STAFF_DIR, re.sub(r'[<>:"/|?*]', "-", name) + ".md")
    tpl = io.open(DEV_TEMPLATE, encoding="utf-8").read() if os.path.exists(DEV_TEMPLATE) else "# {name}\nフォルダ: {folder}\nメモリ: {memory}\n"
    if not os.path.exists(ppath):
        io.open(ppath, "w", encoding="utf-8", newline="\n").write(tpl.format(name=name, room_id=rid, folder=d, memory=mem, handoff=handoff,
                                                               emoji=args.emoji or "🛠", date=datetime.date.today().isoformat()))
    entry = {"name": name, "role": "開発部屋", "kind": "project", "emoji": args.emoji or "🛠", "room_id": rid, "room_name": name,
             "engine": "claude", "persona": ppath, "project": d, "memory": mem,
             "hired": (existing or {}).get("hired") or datetime.date.today().isoformat()}
    staff["staff"] = [s for s in staff["staff"] if s["name"] != name] + [entry]
    save_json(STAFF_FILE, staff)
    print("部屋:", name, rid, "(新規)" if created else "(既存)")
    print("フォルダ:", d, "(新規)" if fresh else "(既存)")
    print("メモリ:", mem)
    print("引き継ぎメモ:", handoff)
    print("管制塔:", hq)
    print("ROOM_ID=%s" % rid)
    if created and not args.quiet:
        goal = ("\n目的: " + args.brief.strip()) if args.brief else ""
        api("POST", "/channels/%s/messages" % rid, {"content": "%s 開発部屋「%s」です。%s\n作業フォルダ: `%s`\nPC のデスクトップアプリでこのフォルダを開いても、同じメモリ・引き継ぎメモで続けられます。やりたいことをそのまま書いてください。" % (args.emoji or "🛠", name, goal, d)})


# ---------------------------------------------------------------- お休み・やめる
PAUSE_FLAG = os.path.join(OFFICE_DIR, "paused.json")
KIT_BEGIN = "<!-- ここからキット（discord-ai-office）: AIオフィスの「やめる」で、この目印の間だけ消えます -->"
KIT_END = "<!-- ここまでキット（discord-ai-office） -->"
KIT_HEAD = "# Discord AI オフィス（discord-ai-office スキル）"
LOCAL_BEGIN = "<!-- ここから持ち主の追加（~/.claude/ai-office/local/CLAUDE_local.md）-->"
LOCAL_END = "<!-- ここまで持ち主の追加 -->"
IS_WIN = os.name == "nt"
LAUNCH_AGENTS = os.path.join(HOME, "Library", "LaunchAgents")
MAC_JOBS = ["com.aioffice.restart", "com.aioffice.watch", "com.aioffice.start", "com.aioffice.restart-now"]
WIN_TASKS = ["AIOffice_DailyRestart", "AIOffice_ReplyWatch", "AIOffice_Watchdog", "AIOffice_AtLogon", "AIOffice_RestartNow"]   # Watchdog＝利用者が足した見回り（止めないとお休み中に起こされる）
CLAUDE_MD = os.path.join(HOME, ".claude", "CLAUDE.md")


def _run(cmd):
    import subprocess
    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120).stdout.decode("utf-8", "replace").strip()
    except Exception as e:
        return "error: %s" % e


def _ps(script):
    return _run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script])


def _confirm(lines, yes):
    print("\n".join(lines))
    if yes: return True
    try: a = input("\n進めるなら「はい」（または y）と打って Enter。やめておくなら、そのまま Enter: ").strip().lower()
    except EOFError: a = ""
    if a in ("はい", "hai", "y", "yes", "ｙ", "ｙｅｓ"): return True
    print("何もしませんでした。"); return False


def _try_notice(text):
    try: api("POST", "/channels/%s/messages" % hq_room(), {"content": text}); return True
    except SystemExit: return False


def stop_claude():
    """Discord 付きで動いている Claude Code を止める（デスクトップアプリや普通の claude は止めない）"""
    if IS_WIN:
        _ps("Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match 'claude' -and $_.CommandLine -match '--channels' } | "
            "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
    else:
        _run(["pkill", "-f", "claude.*--channels"])


def set_tasks(on):
    """定期再起動と返事の見張りを 止める(False)／戻す(True)。消さない"""
    if IS_WIN:
        for t in WIN_TASKS:
            _ps("%s -TaskName '%s' -ErrorAction SilentlyContinue | Out-Null" % ("Enable-ScheduledTask" if on else "Disable-ScheduledTask", t))
        return
    park = os.path.join(OFFICE_DIR, "paused_jobs")   # launchd は unload しても再ログインで読み直すので、plist ごと脇に寄せておく
    for j in MAC_JOBS:
        live, parked = os.path.join(LAUNCH_AGENTS, j + ".plist"), os.path.join(park, j + ".plist")
        if on and os.path.exists(parked):
            os.makedirs(LAUNCH_AGENTS, exist_ok=True); shutil.move(parked, live); _run(["launchctl", "load", live])
        elif not on and os.path.exists(live):
            _run(["launchctl", "unload", live]); os.makedirs(park, exist_ok=True); shutil.move(live, parked)


def remove_tasks():
    if IS_WIN:
        for t in WIN_TASKS + ["AIオフィス 定期再起動"]:
            _ps("Unregister-ScheduledTask -TaskName '%s' -Confirm:$false -ErrorAction SilentlyContinue" % t)
        return
    for j in MAC_JOBS:
        for p in (os.path.join(LAUNCH_AGENTS, j + ".plist"), os.path.join(OFFICE_DIR, "paused_jobs", j + ".plist")):
            if os.path.exists(p): _run(["launchctl", "unload", p]); os.remove(p)


def cmd_pause(args):
    if os.path.exists(PAUSE_FLAG):
        print("もうお休み中です。戻すときは AIオフィス の「起動」をダブルクリックしてください。"); return
    if not _confirm(["", "😴 AIオフィスを お休み にします。", "",
                     "・Discord の部屋に書いても、AI は返事をしなくなります",
                     "・毎日の自動再起動と、返事の見張りも止めます",
                     "・部屋・会話・社員・メモリ・設定は 何も消しません",
                     "・戻すときは AIオフィス の「起動」をダブルクリックするだけです"], args.yes): return
    _try_notice("😴 %s AIオフィスはお休みに入ります。部屋に書いても返事はしません（パソコンの AIオフィス の「起動」で戻ります）" % time.strftime("%m/%d %H:%M"))
    stop_claude(); set_tasks(False)
    save_json(PAUSE_FLAG, {"since": datetime.datetime.now().isoformat(timespec="seconds")})
    print("\n✓ お休みにしました。戻すときは「起動」をダブルクリック。")


def cmd_resume(args):
    if not os.path.exists(PAUSE_FLAG): print("RESUME=0"); return
    set_tasks(True); os.remove(PAUSE_FLAG)
    print("お休みから戻しました（自動再起動と見張りを再開）"); print("RESUME=1")


def export_room(rid, name, path, limit=5000):
    """部屋の会話を古い順に Markdown へ書き出す（最大 limit 件）"""
    msgs, before = [], None
    while len(msgs) < limit:
        try: batch = api("GET", "/channels/%s/messages?limit=100%s" % (rid, ("&before=%s" % before) if before else ""))
        except SystemExit: break
        if not batch: break
        msgs += batch; before = batch[-1]["id"]
        if len(batch) < 100: break
        time.sleep(0.3)
    msgs.reverse()
    out = ["# 「%s」の部屋の会話（%s に Discord から書き出し・%d 件）" % (name, time.strftime("%Y-%m-%d %H:%M"), len(msgs)), "",
           "AIオフィスをやめたときに書き出した、この部屋のやり取りです。",
           "デスクトップの Claude に「このファイルを読んで、続きから手伝って」と渡せば、話の続きから始められます。", ""]
    for m in msgs:
        t = datetime.datetime.fromisoformat(m["timestamp"].replace("Z", "+00:00")).astimezone().strftime("%Y-%m-%d %H:%M")
        a = m.get("author", {})
        who = (a.get("global_name") or a.get("username") or "?") + ("（AI）" if a.get("bot") else "")
        body = (m.get("content") or "").strip()
        att = [x.get("filename", "") for x in m.get("attachments", [])]
        if att: body += ("\n" if body else "") + "（添付: %s）" % "、".join(att)
        out += ["### %s — %s" % (t, who), body, ""]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    io.open(path, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
    return len(msgs)


def strip_kit_block(text):
    """CLAUDE.md からキットが足した決まりだけを外す。(新しい本文, どう外したか)"""
    b, e = text.find(KIT_BEGIN), text.find(KIT_END)
    if b >= 0 and e > b:
        before, after = text[:b].rstrip("\n"), text[e + len(KIT_END):].lstrip("\n")
        return (before + "\n\n" + after if before and after else before + after).strip("\n") + "\n", "目印の間を外しました"
    i = text.find(KIT_HEAD)
    if i < 0: return text, "キットの決まりは見つかりませんでした（そのまま）"
    # 目印の無い古い版: 見出しから、次の「# 」見出し／「## デスクトップから引き継いだ決まり」（本人の決まり）の手前まで
    rest = text[i + len(KIT_HEAD):]
    m = re.search(r"^(# |## デスクトップから引き継いだ決まり)", rest, re.M)
    j = i + len(KIT_HEAD) + (m.start() if m else len(rest))
    before, after = text[:i].rstrip("\n"), text[j:].strip("\n")
    return (before + "\n\n" + after if before and after else before + after).strip("\n") + "\n", "キットの見出しから外しました（目印の無い古い版）"


SNIPPET_FILE = os.path.join(SKILL_DIR, "templates", "CLAUDE_snippet.md")
REASON_FILE = os.path.join(OFFICE_DIR, "restart_reason.txt")


def cmd_snippet_install(args):
    """CLAUDE.md のキットの作法ブロックを今の版に差し替える（更新で新しい決まりが届くように）。目印の無い古い版は見出しから外して入れ直す"""
    new = io.open(SNIPPET_FILE, encoding="utf-8").read().strip("\n")
    lp = os.path.join(LOCAL_DIR, "CLAUDE_local.md")
    if os.path.exists(lp) and KIT_END in new:   # 持ち主の追加の決まりをキットの目印の内側に足す（更新でも残る・「やめる」で一緒に消える）
        loc = io.open(lp, encoding="utf-8").read().strip("\n")
        if loc: new = new.replace(KIT_END, LOCAL_BEGIN + "\n" + loc + "\n" + LOCAL_END + "\n" + KIT_END)
    cur = io.open(CLAUDE_MD, encoding="utf-8").read() if os.path.exists(CLAUDE_MD) else ""
    if new in cur:
        print("SNIPPET=same"); return
    base, how = strip_kit_block(cur) if (KIT_BEGIN in cur or KIT_HEAD in cur) else (cur, "無かったので足しました")
    base = base.rstrip("\n")
    out = (base + "\n\n" if base else "") + new + "\n"
    os.makedirs(os.path.dirname(CLAUDE_MD), exist_ok=True)
    io.open(CLAUDE_MD, "w", encoding="utf-8", newline="\n").write(out)
    print("CLAUDE.md の作法ブロックを今の版にしました（%s）" % how); print("SNIPPET=updated")


def running_model():
    """いま動いている Discord 用 claude の --model（プロセスのコマンドラインから）。無ければ ""。設定値ではなく実物を答えるため"""
    try:
        if IS_WIN:
            out = _ps("Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'claude' -and $_.CommandLine -match '--channels' } | ForEach-Object { $_.CommandLine }")
        else:
            out = _run(["bash", "-c", "ps -eo args | grep -- '--channels' | grep -v grep"])
        m = re.search(r"--model\s+(?:'|\")?([A-Za-z0-9.-]+)", out or "")
        return m.group(1) if m else ""
    except Exception:
        return ""


def _restart_log_started(since, office):
    """since 以降に restart_*.log が書かれ始めたか（デスクトップの logs と、書けないときの置き場の両方を見る）"""
    for d in (os.path.join(office, "logs"), os.path.join(OFFICE_DIR, "logs")):
        f = os.path.join(d, "restart_%s.log" % time.strftime("%Y%m%d"))
        try:
            if os.path.getmtime(f) >= since - 1: return True
        except OSError: pass
    return False


def request_restart(office, reason):
    """再起動を Claude の外（予約タスク／launchd）に頼む。Claude の中から直接呼ぶと自分ごと止まるため。無ければ切り離したプロセスで"""
    import subprocess
    os.makedirs(OFFICE_DIR, exist_ok=True)
    io.open(REASON_FILE, "w", encoding="utf-8", newline="\n").write(reason + "\n")   # restart.* が読んで消す（理由あり＝更新は飛ばす）
    if IS_WIN:
        r = _ps("if (Get-ScheduledTask -TaskName 'AIOffice_RestartNow' -ErrorAction SilentlyContinue) { Start-ScheduledTask -TaskName 'AIOffice_RestartNow'; 'TASK' } else { 'NOTASK' }")
        if "TASK" in r and "NOTASK" not in r: return "task"
        subprocess.Popen(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", os.path.join(SKILL_DIR, "scripts", "restart.ps1"),
                          "-Office", office, "-NoUpdate", "-Reason", reason], creationflags=0x00000008 | 0x00000200); return "detached"
    r = _run(["launchctl", "start", "com.aioffice.restart-now"])
    if "error" not in r.lower() and "could not find" not in r.lower() and "no such" not in r.lower(): return "launchd"
    logd = os.path.join(OFFICE_DIR, "logs"); os.makedirs(logd, exist_ok=True)
    subprocess.Popen(["nohup", "bash", os.path.join(SKILL_DIR, "scripts", "restart.sh"), office, reason],
                     stdout=open(os.path.join(logd, "model_restart.log"), "a"), stderr=subprocess.STDOUT, start_new_session=True); return "detached"


def cmd_uninstall(args):
    office = os.path.abspath(args.office or os.path.join(HOME, "Desktop", "AIオフィス"))
    staff = load_json(STAFF_FILE, {"staff": []})
    keep = os.path.join(office, "やめた時の控え_" + time.strftime("%Y%m%d_%H%M"))
    if not _confirm(["", "👋 AIオフィスを やめます（キットが足したものを外し、デスクトップの Claude だけの状態に戻します）。", "",
                     "先に「控え」を作ります（%s）:" % keep,
                     "  ・全部のバックアップ（zip）",
                     "  ・部屋ごとの会話（開発部屋はその作業フォルダの「Discordでの会話.md」、ほかは控えの中）",
                     "  ・社員の設定と、いまの CLAUDE.md の写し", "",
                     "そのあと外すもの:",
                     "  ・Discord 付きで動いている AI と、毎日の自動再起動・返事の見張り",
                     "  ・キットが CLAUDE.md に足した決まり（あなたが書いた分は残す）",
                     "  ・bot の鍵（トークン）と、部屋の許可",
                     "  ・キットが Claude の許可設定（settings.json）に足した項目",
                     "  ・キット本体（控えに移す）", "",
                     "残すもの: スキル・メモリ・プロジェクト・作業フォルダ・デスクトップの Claude（今までどおり使えます）",
                     "Discord のサーバーと bot は、最後に出す手順であなたが消します（残しても構いません）"], args.yes): return
    os.makedirs(keep, exist_ok=True)
    log = []
    def step(msg): print("✓ " + msg); log.append("・" + msg)
    class A: pass
    a = A(); a.out = keep
    try: cmd_backup(a); step("バックアップを作りました")
    except Exception as e: print("（バックアップ失敗: %s）" % e)
    if os.path.exists(CLAUDE_MD): shutil.copy2(CLAUDE_MD, os.path.join(keep, "CLAUDE.md（やめる前の写し）.md"))
    if os.path.isdir(STAFF_DIR): shutil.copytree(STAFF_DIR, os.path.join(keep, "社員の設定"), dirs_exist_ok=True)
    # 会話の書き出し
    have_token = os.path.exists(TOKEN_FILE)
    for s_ in staff.get("staff", []):
        rid = s_.get("room_id")
        if not rid or not have_token: continue
        safe = re.sub(r'[<>:"/\\|?*]', "-", s_["name"])
        proj = s_.get("project")
        if s_.get("kind") == "project" and proj and os.path.isdir(proj):
            path = os.path.join(proj, "Discordでの会話.md")
            if os.path.exists(path): path = os.path.join(proj, "Discordでの会話_%s.md" % time.strftime("%Y%m%d_%H%M"))
        else:
            path = os.path.join(keep, "会話", safe + ".md")
        n = export_room(rid, s_["name"], path)
        step("会話を書き出し: %s（%d 件）→ %s" % (s_["name"], n, path))
        mem = s_.get("memory")
        if mem and os.path.isdir(mem):   # 開発部屋: 引き継ぎメモに「会話はここ」を足す＝デスクトップで開くと続きがわかる
            try:
                io.open(os.path.join(mem, "handoff.md"), "a", encoding="utf-8", newline="\n").write(
                    "\n## Discord の開発部屋から戻ってきた（%s）\n- AIオフィスをやめた。部屋での会話は %s に書き出してある。続きを始める前に読む\n" % (time.strftime("%Y-%m-%d"), path))
            except OSError: pass
    if not have_token: print("（bot の鍵が無いので、会話の書き出しは飛ばしました）")
    _try_notice("👋 %s AIオフィスを終了します。会話はパソコンに書き出しました。この部屋に書いても、もう返事はしません。" % time.strftime("%m/%d %H:%M"))
    # 止める・外す
    stop_claude(); step("AI（Discord 付き）を止めました")
    remove_tasks(); step("毎日の自動再起動と返事の見張りを外しました")
    if os.path.exists(CLAUDE_MD):
        t = io.open(CLAUDE_MD, encoding="utf-8").read()
        nt, how = strip_kit_block(t)
        if nt != t: io.open(CLAUDE_MD, "w", encoding="utf-8", newline="\n").write(nt)
        step("CLAUDE.md: " + how)
    acc = load_json(ACCESS_FILE, None)
    if acc is not None:
        rooms = set(str(s_.get("room_id")) for s_ in staff.get("staff", []))
        acc["groups"] = {k: v for k, v in acc.get("groups", {}).items() if k not in rooms}
        save_json(ACCESS_FILE, acc); step("部屋の許可を外しました")
    if os.path.exists(TOKEN_FILE):
        os.remove(TOKEN_FILE); step("bot の鍵（トークン）を消しました")
    if _store_get():
        _store_del(); step("暗号化保存庫のトークンを消しました")
    sp = os.path.join(HOME, ".claude", "settings.json")
    st = load_json(sp, None)
    if st is not None and isinstance(st.get("permissions", {}).get("allow"), list):
        before = st["permissions"]["allow"]; st["permissions"]["allow"] = [x for x in before if x not in BASIC_ALLOW]
        if len(before) != len(st["permissions"]["allow"]):
            save_json(sp, st); step("キットが settings.json に足した許可（Discord の道具・ai-office-data・Cron）を外しました")
    st = load_json(sp, None)
    if st is not None and _guard_hook_registered(st):
        st["hooks"]["PreToolUse"] = [e for e in st["hooks"]["PreToolUse"] if not any("discord-ai-office/guard/guard.py" in str(h.get("command", "")) for h in (e.get("hooks") or []))]
        if not st["hooks"]["PreToolUse"]: del st["hooks"]["PreToolUse"]
        save_json(sp, st); step("見張り（関所）のフックを外しました")
    if os.path.isdir(GUARD_DIR):
        try:
            shutil.copytree(GUARD_DIR, os.path.join(keep, "見張りの記録"), dirs_exist_ok=True); shutil.rmtree(GUARD_DIR, ignore_errors=True); step("見張りの記録を控えに移しました")
        except Exception as e:
            step("見張りの記録の移動に失敗（そのまま残します）: %s" % e)
    r = _run(["claude", "plugin", "disable", "discord@claude-plugins-official"])
    step("Discord 連携（プラグイン）を無効にしました" if "rror" not in r else "Discord 連携の無効化はできませんでした（気になるときは Claude で /plugin → discord → Disable）")
    for src, name in ((OFFICE_DIR, "キットの台帳と設定"), (SKILL_DIR, "キット本体（discord-ai-office）")):
        try:
            if os.path.isdir(src): shutil.move(src, os.path.join(keep, name)); step("%s を控えに移しました" % name)
        except OSError as e:
            print("（%s は移せませんでした: %s。あとで手で消して構いません）" % (name, e))
    tail = ["■ あと2つ、あなたがすること（どちらも残しておいても大丈夫）",
            "1) Discord のサーバーを消す: Discord でサーバー名を押す → サーバー設定 → いちばん下の「サーバーを削除」",
            "2) bot を消す: https://discord.com/developers/applications を開く → bot を選ぶ → General Information のいちばん下「Delete App」",
            "",
            "■ 続きをデスクトップの Claude でやるとき",
            "・開発の部屋: デスクトップアプリで、その作業フォルダを開く → メモリと「Discordでの会話.md」がそのまま読めます",
            "・ほかの部屋: この控えの「会話」フォルダの .md を Claude に渡して「続きから手伝って」",
            "・スキル・メモリは消していないので、デスクトップの Claude はこれまでどおりです",
            "・~/ai-office-data（社員のメモや成果物）は残しています。要らなければ手で消してください",
            "・見張りの関所を自分で足していた場合（キットの guard on 以外）は、そのフックも外してください",
            "",
            "■ また使いたくなったら: 買ったときのセットアップの1行をもう一度貼るだけです"]
    io.open(os.path.join(keep, "やめた後にすること.txt"), "w", encoding="utf-8").write(
        "\n".join(["AIオフィスをやめました（%s）" % time.strftime("%Y-%m-%d %H:%M"), ""] + log + [""] + tail) + "\n")
    print("\n" + "\n".join(tail))
    print("\n（この案内は %s にも置きました）" % os.path.join(keep, "やめた後にすること.txt"))
    print("UNINSTALLED=1")


# ---------------------------------------------------------------- 最低限の許可（Q1 🇦・2026-09-29）
BASIC_ALLOW = ["mcp__plugin_discord_discord__reply", "mcp__plugin_discord_discord__react", "mcp__plugin_discord_discord__edit_message",
               "mcp__plugin_discord_discord__fetch_messages", "mcp__plugin_discord_discord__download_attachment",
               "Edit(~/ai-office-data/**)", "Write(~/ai-office-data/**)", "CronCreate", "CronList", "CronDelete"]   # 起動時の指示が cron を張るので Cron も


def cmd_allow_basics(args):
    """auto mode でも Discord への返事と社員の作業場所への書き込みが止まらないよう、許可ルールに足す（何度流しても同じ・ほかの設定は触らない）"""
    p = os.path.join(HOME, ".claude", "settings.json")
    cur = load_json(p, {})
    allow = cur.setdefault("permissions", {}).setdefault("allow", [])
    add = [x for x in BASIC_ALLOW if x not in allow]
    if add:
        allow.extend(add); save_json(p, cur)
    os.makedirs(os.path.join(HOME, "ai-office-data"), exist_ok=True)
    # 部屋の許可が空（＝その部屋にいる誰でも指示できる）のままの部屋があれば、オーナーだけに直す（古い版で作った部屋の直し）
    acc = load_json(ACCESS_FILE, None)
    if acc is not None and acc.get("allowFrom"):
        fixed = 0
        for rid, g in acc.get("groups", {}).items():
            if not g.get("allowFrom"):
                g["allowFrom"] = list(acc["allowFrom"]); fixed += 1
        if fixed:
            save_json(ACCESS_FILE, acc); print("部屋の許可をオーナーだけにしました: %d 部屋" % fixed)
    print("ALLOW_ADDED=%d" % len(add))


# ---------------------------------------------------------------- モデル切替（スマホから「モデルを変えて」）
MODEL_RE = re.compile(r"^(auto|[A-Za-z][A-Za-z0-9.-]{1,40})$")
DESK_MIRROR = os.path.join(OFFICE_DIR, "desk")
RECOMMEND_FILE = os.path.join(OFFICE_DIR, "recommended_model.txt")


def _office_dir(args):
    d = getattr(args, "office", None)
    if d: return os.path.abspath(d)
    if IS_WIN:
        try:
            import ctypes.wintypes
            buf = ctypes.create_unicode_buffer(260); ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf)   # CSIDL_DESKTOPDIRECTORY（OneDrive のデスクトップも正しく出る）
            if buf.value: return os.path.join(buf.value, "AIオフィス")
        except Exception: pass
    return os.path.join(HOME, "Desktop", "AIオフィス")


def _set_cfg_line(path, key, value):
    """モデル設定.txt の key= 行だけ書き換える（無ければ足す・他の行は触らない・value が空なら行を消す）。書けなければ False"""
    try:
        lines = io.open(path, encoding="utf-8").read().splitlines() if os.path.exists(path) else []
    except OSError:
        return False
    out, done = [], False
    for l in lines:
        if l.startswith(key + "="):
            if value and not done: out.append(key + "=" + value)
            done = True
        else: out.append(l)
    if value and not done: out.append(key + "=" + value)
    try:
        io.open(path, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n"); return True
    except OSError:
        return False


def _set_model_line(path, model): return _set_cfg_line(path, "model", model)


# ---------------------------------------------------------------- 使用量の目安（B1・momomon 案 2026-09-30）
def _usage_records(days):
    """~/.claude/projects 以下の会話記録から (時刻UTC, モデル, 入力, キャッシュ読み, キャッシュ書き, 出力) を集める。
    同じ message.id（無ければ requestId）は最後に見えた行だけ採用（途中経過が同じ id で複数行残るため・momomon model_usage.py と同じ）"""
    root = os.path.join(HOME, ".claude", "projects")
    since = time.time() - days * 86400 - 6 * 3600
    seen = {}
    for dp, _, files in os.walk(root):
        for fn in files:
            if not fn.endswith(".jsonl"): continue
            fp = os.path.join(dp, fn)
            try:
                if os.path.getmtime(fp) < since: continue
                with io.open(fp, encoding="utf-8", errors="replace") as f:
                    for line in f:
                        if '"usage"' not in line: continue
                        try: d = json.loads(line)
                        except Exception: continue
                        m = d.get("message") or {}
                        u = m.get("usage") if isinstance(m, dict) else None
                        if not isinstance(u, dict) or m.get("role") != "assistant": continue
                        ts = d.get("timestamp") or ""
                        try:
                            t = datetime.datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=datetime.timezone.utc).timestamp()
                        except Exception: continue
                        if t < since: continue
                        key = (fp, m.get("id") or d.get("requestId") or ts)
                        seen[key] = (t, str(m.get("model") or "?"), int(u.get("input_tokens") or 0), int(u.get("cache_read_input_tokens") or 0),
                                     int(u.get("cache_creation_input_tokens") or 0), int(u.get("output_tokens") or 0))
            except OSError: continue
    return sorted(seen.values())


def _fmt_tok(n):
    return ("%.1f万" % (n / 1e4)) if n >= 1e4 else str(n)


def usage_report(days=7, now=None):
    now = now or time.time()
    rec = _usage_records(days)
    def agg(rs):
        return {"calls": len(rs), "in": sum(r[2] for r in rs), "cache": sum(r[3] for r in rs), "create": sum(r[4] for r in rs), "out": sum(r[5] for r in rs)}
    last5 = [r for r in rec if r[0] >= now - 5 * 3600]
    lastN = [r for r in rec if r[0] >= now - days * 86400]
    # 直近 N 日で「最も多かった5時間」（出力トークン＋新規入力で見る。キャッシュ読みは枠の消費が軽いので外す）
    weight = lambda r: r[5] + r[2] + r[4]
    peak, best = 0, None
    j = 0
    for i, r in enumerate(lastN):
        while lastN[j][0] < r[0] - 5 * 3600: j += 1
        w = sum(weight(x) for x in lastN[j:i + 1])
        if w > peak: peak, best = w, (lastN[j][0], r[0])
    cur = sum(weight(x) for x in last5)
    by_model = {}
    for r in lastN:
        if r[1].startswith("<"): continue   # <synthetic> などの内部行は割合に入れない
        by_model[r[1]] = by_model.get(r[1], 0) + weight(r)
    tot = sum(by_model.values()) or 1
    days_list = []
    jst = datetime.timezone(datetime.timedelta(hours=9))
    for k in range(days - 1, -1, -1):
        d0 = datetime.datetime.fromtimestamp(now, jst).replace(hour=0, minute=0, second=0, microsecond=0) - datetime.timedelta(days=k)
        t0, t1 = d0.timestamp(), d0.timestamp() + 86400
        w = sum(weight(x) for x in lastN if t0 <= x[0] < t1)
        days_list.append((d0.strftime("%-m/%-d") if os.name != "nt" else "%d/%d" % (d0.month, d0.day), w))
    mx = max([w for _, w in days_list] + [1])
    a5, aN = agg(last5), agg(lastN)
    L = ["📊 使用量の目安（この PC の会話記録から推定・公式の枠の％ではありません）",
         "直近5時間: 会話 %d 回・新規入力 %s・キャッシュ読み %s・出力 %s tok" % (a5["calls"], _fmt_tok(a5["in"] + a5["create"]), _fmt_tok(a5["cache"]), _fmt_tok(a5["out"])),
         "直近%d日: 会話 %d 回・新規入力 %s・キャッシュ読み %s・出力 %s tok" % (days, aN["calls"], _fmt_tok(aN["in"] + aN["create"]), _fmt_tok(aN["cache"]), _fmt_tok(aN["out"]))]
    if peak:
        L.append("今の5時間の重さ: 直近%d日で最も多かった5時間（%s〜）の **%d%%**" % (days, datetime.datetime.fromtimestamp(best[0], jst).strftime("%m/%d %H:%M"), round(100 * cur / peak)))
    if by_model:
        L.append("モデル別（重さの割合）: " + "・".join("%s %d%%" % (k.replace("claude-", ""), round(100 * v / tot)) for k, v in sorted(by_model.items(), key=lambda x: -x[1])))
    L.append("日ごと: " + " ".join("%s%s" % (d, "▇" * max(1, round(6 * w / mx)) if w else "·") for d, w in days_list))
    L.append("※ 重さ＝出力＋新規入力（キャッシュ読みは軽いので外す）。公式の残り％は PC の Claude Code で /usage")
    return "\n".join(L), {"last5": a5, "lastN": aN, "peak5_ratio": (round(cur / peak, 3) if peak else None), "by_model": by_model,
                       "span_days": (round((now - rec[0][0]) / 86400, 2) if rec else 0)}   # 10/1: 履歴の長さ（週の目安は 7 日ためてから）


# ---------------------------------------------------------------- 使用量を名前に（C4・momomon要望「メンバー一覧で残り％」・masa🇦 2026-09-30）
def _usage_guild():
    """このサーバーの guild id。無ければ None（token() のように止めない＝watch-replies を落とさない）"""
    staff = load_json(STAFF_FILE, {"staff": []})
    return staff.get("guild") or config().get("guild")


def _usage_nick_base():
    """付け替える前の元のニックネーム。config.json の nick_base に控えて2回目以降はそれを使う（「｜目安」が重ならない）"""
    c = config()
    if c.get("nick_base"): return c["nick_base"]
    gid = _usage_guild(); base = ""
    if gid:
        try:
            me = api("GET", "/guilds/%s/members/@me" % gid)
            base = (me.get("nick") or (me.get("user") or {}).get("username") or "").strip()
        except SystemExit:
            base = ""
    if not base:
        try: base = (api("GET", "/users/@me").get("username") or "").strip()
        except SystemExit: base = ""
    base = base or "AI社員"
    c["nick_base"] = base; save_json(CONFIG_FILE, c)
    return base


def _usage_pct(data):
    """0〜100の使用量の目安。出せないときは None（呼び出し側は名前を触らない）"""
    peak = data.get("peak5_ratio")
    if peak is not None:
        return max(0, min(100, round(100 * peak)))
    last5 = data.get("last5") or {}
    w = (last5.get("out") or 0) + (last5.get("in") or 0) + (last5.get("create") or 0)
    if w <= 0: return None
    c = config()
    limit = c.get("usage_limit_5h") or c.get("usage_peak_5h") or 0
    if w > limit:   # 上限の目安が無い／今までの最大を超えた → これまでで一番重い5時間として学習
        c["usage_peak_5h"] = w; save_json(CONFIG_FILE, c); limit = c.get("usage_limit_5h") or w
    if not limit: return None
    return max(0, min(100, round(100 * w / limit)))


def _usage_pct_week(data):
    """週の目安 0〜100（直近7日の重み ÷ config usage_limit_7d か学習した usage_peak_7d）。出せないときは None"""
    n = data.get("lastN") or {}
    w = (n.get("out") or 0) + (n.get("in") or 0) + (n.get("create") or 0)
    if w <= 0: return None
    c = config()
    if not c.get("usage_limit_7d") and (data.get("span_days") or 0) < 6.5: return None   # 10/1: 7 日分たまるまで出さない（初週は常に 100% になってしまうため）
    limit = c.get("usage_limit_7d") or c.get("usage_peak_7d") or 0
    if w > limit:   # 今までで一番重い7日として学習（上限に当たった週が 100% になる）
        c["usage_peak_7d"] = w; save_json(CONFIG_FILE, c); limit = c.get("usage_limit_7d") or w
    if not limit: return None
    return max(0, min(100, round(100 * w / limit)))


def _usage_nick_apply(pct, wpct=None):
    gid = _usage_guild()
    if not gid: print("USAGE_NICK_SKIP=no_guild"); return
    base = _usage_nick_base()
    suffix = " %d%%/%s" % (pct, ("%d%%" % wpct) if wpct is not None else "--")   # 10/1: 「AI社員 0%/40%」（5h/週・メンバー一覧で切れない長さ）
    nick = (base[:max(0, 32 - len(suffix))] + suffix) if len(base) + len(suffix) > 32 else base + suffix
    nick = nick[:32]
    api("PATCH", "/guilds/%s/members/@me" % gid, {"nick": nick})
    print("USAGE_NICK=" + nick)


def _usage_nick_reset():
    gid = _usage_guild(); base = config().get("nick_base")
    if gid and base:
        try: api("PATCH", "/guilds/%s/members/@me" % gid, {"nick": base})
        except SystemExit: pass
    print("USAGE_NICK=" + (base or ""))


def cmd_usage(args):
    text, data = usage_report(args.days)
    print(text); print("USAGE_JSON=" + json.dumps(data, ensure_ascii=False))
    if getattr(args, "week", None) is not None or getattr(args, "five_h", None) is not None:   # 10/1: Claude Code の /usage の数字で目安を合わせる
        c = config()
        for key, val, part, label in (("usage_limit_7d", getattr(args, "week", None), data.get("lastN") or {}, "週"),
                                      ("usage_limit_5h", getattr(args, "five_h", None), data.get("last5") or {}, "5h")):
            if val is None: continue
            w = (part.get("out") or 0) + (part.get("in") or 0) + (part.get("create") or 0)
            if not (1 <= val <= 100): sys.exit("--week／--5h は 1〜100 の数字（Claude Code の /usage に出る％）")
            if w <= 0: sys.exit("%s: この PC の会話記録がまだ無いので合わせられません" % label)
            c[key] = int(round(w * 100.0 / val)); c.pop(key.replace("limit", "peak"), None)
            print("CALIBRATED_%s=%d（%s %d%% に合わせました。以後の目安はこの上限で出します）" % (label, c[key], label, val))
        save_json(CONFIG_FILE, c)
    if args.post:
        api("POST", "/channels/%s/messages" % config()["hq_room"], {"content": text, "allowed_mentions": {"parse": []}}); print("POSTED=1")
    if args.nick is None: return
    if args.nick == "off":
        c = config(); c["usage_nick"] = "off"; save_json(CONFIG_FILE, c)
        _usage_nick_reset(); return
    if args.nick == "on":
        c = config(); c["usage_nick"] = "on"; save_json(CONFIG_FILE, c)
    elif args.nick != "update":
        sys.exit("--nick は on／off のどちらか（値を付けなければ今すぐ更新）")
    pct = _usage_pct(data)
    if pct is None: print("USAGE_NICK_SKIP=no_data"); return
    _usage_nick_apply(pct, _usage_pct_week(data))


# ---------------------------------------------------------------- 見張り（関所・上級者向け・原作 momomon 2026-09-28〜）
GUARD_PY = os.path.join(SKILL_DIR, "guard", "guard.py").replace("\\", "/")
GUARD_DIR = os.path.join(OFFICE_DIR, "guard")
GUARD_SETTINGS = os.path.join(GUARD_DIR, "settings.json")
GUARD_TEMPLATE = os.path.join(SKILL_DIR, "templates", "discord-settings-guard.json")
USER_SETTINGS = os.path.join(HOME, ".claude", "settings.json")
_PY = "python" if IS_WIN else "python3"


def _guard_hook_cmd():
    """フックの命令。利用者の PATH や site を読まない絶対パスの python（-I）で動かす（監査 重大3a: ~/.local/bin の偽 python・usercustomize の乗っ取り）"""
    return '"%s" -I "%s" pre' % (sys.executable.replace("\\", "/"), GUARD_PY)


GUARD_WATCH = ["guard/guard.py", "scripts/office.py", "scripts/start.sh", "scripts/start.ps1", "scripts/restart.sh", "scripts/restart.ps1",
               "templates/discord-settings.json", "templates/discord-settings-guard.json", "templates/CLAUDE_snippet.md"]
INTEGRITY_FILE = os.path.join(GUARD_DIR, "integrity.json")


def _hashes():
    import hashlib
    out = {}
    for rel in GUARD_WATCH:
        f = os.path.join(SKILL_DIR, rel)
        try: out[rel] = hashlib.sha256(open(f, "rb").read()).hexdigest()
        except OSError: out[rel] = None
    for rel in ("local/guard_rules.py", "local/start_hook.sh", "local/start_hook.ps1"):   # 持ち主の見張り規則・起動フックも合図に入れる（変えたら guard rehash）
        f = os.path.join(OFFICE_DIR, rel)
        if os.path.exists(f): out[rel] = hashlib.sha256(open(f, "rb").read()).hexdigest()
    out["hook"] = _guard_hook_registered(load_json(USER_SETTINGS, {}))
    return out


def _guard_rehash():
    os.makedirs(GUARD_DIR, exist_ok=True); save_json(INTEGRITY_FILE, {"at": time.strftime("%Y-%m-%d %H:%M"), "hashes": _hashes()})


def guard_verify():
    """見張りの本体・起動の仕掛けが guard on／更新のときから変わっていないか（Claude の外＝restart.* から呼ぶ）。戻り値: 変わったものの一覧"""
    ref = load_json(INTEGRITY_FILE, None)
    if not ref: return None
    cur = _hashes(); bad = [k for k, v in ref["hashes"].items() if cur.get(k) != v]
    return bad


def _guard_hook_registered(st):
    for ent in (st.get("hooks") or {}).get("PreToolUse") or []:
        for h in (ent.get("hooks") or []):
            if "discord-ai-office/guard/guard.py" in str(h.get("command", "")) and h.get("command", "").rstrip().endswith(" pre"): return True
    return False


def _guard_settings_line(office):
    for f in (os.path.join(office, "モデル設定.txt"), os.path.join(DESK_MIRROR, "モデル設定.txt")):
        try:
            for l in io.open(f, encoding="utf-8"):
                if l.startswith("settings="): return l.split("=", 1)[1].strip()
        except OSError: continue
    return ""


def cmd_guard(args):
    office = _office_dir(args)
    desk_f = os.path.join(office, "モデル設定.txt"); mir_f = os.path.join(DESK_MIRROR, "モデル設定.txt")
    st = load_json(USER_SETTINGS, {})
    if args.action == "status":
        hooked = _guard_hook_registered(st); line = _guard_settings_line(office)
        on = hooked and line == GUARD_SETTINGS
        wo = any(l.strip() == "workonly=1" for f in (desk_f, mir_f) if os.path.exists(f) for l in io.open(f, encoding="utf-8"))
        print("見張り: %s（関所のフック %s／起動に渡す設定 %s／作業フォルダ限定 %s）" % ("ON" if on else "OFF", "登録済み" if hooked else "未登録", "見張り用" if line == GUARD_SETTINGS else (line or "既定"), "ON" if wo else "OFF"))
        n, last = 0, []
        try:
            for l in io.open(os.path.join(GUARD_DIR, "log.jsonl"), encoding="utf-8", errors="replace"):
                n += 1
                try:
                    r = json.loads(l)
                    if r.get("verdict") in ("approved", "rejected", "timeout", "error", "blocked"): last.append("%s %s" % (r.get("verdict"), r.get("kind", "")))
                except Exception: pass
        except OSError: pass
        print("記録: %d 件（危ない操作の直近: %s）" % (n, "・".join(last[-3:]) or "なし"))
        print("GUARD=%s" % ("on" if on else "off")); return
    if args.action in ("verify", "rehash"):
        if not os.path.exists(INTEGRITY_FILE) and args.action == "verify": print("GUARD_VERIFY=none"); return
        if args.action == "rehash":
            _guard_rehash(); print("見張りの合図（ハッシュ）を取り直しました"); print("GUARD_VERIFY=refreshed"); return
        bad = guard_verify()
        if bad:
            print("⚠ 見張り／起動の仕掛けが前回から変わっています: " + ", ".join(bad)); print("GUARD_VERIFY=changed:" + ",".join(bad))
        else:
            print("見張りの本体は前回と同じです"); print("GUARD_VERIFY=ok")
        return
    if args.action == "on":
        if not os.path.exists(GUARD_PY): sys.exit("見張りの本体が見つかりません: %s" % GUARD_PY)
        os.makedirs(GUARD_DIR, exist_ok=True)
        tpl = io.open(GUARD_TEMPLATE, encoding="utf-8").read().replace("__PY__", _PY).replace("__GUARD__", GUARD_PY)
        json.loads(tpl)   # 壊れていたらここで止まる
        io.open(GUARD_SETTINGS, "w", encoding="utf-8", newline="\n").write(tpl)
        others = [h.get("command", "") for ent in (st.get("hooks") or {}).get("PreToolUse") or [] for h in (ent.get("hooks") or [])
                  if "guard" in str(h.get("command", "")).lower() and "discord-ai-office/guard/guard.py" not in str(h.get("command", ""))]
        if others:   # 自作の見張り（ops/discord-guard など）が残っていると 🔐 が二重に出る（momomon 9/30 実機）
            print("⚠ 別の見張りのフックがユーザー設定に残っています（🔐 が二重に出ます）。要らなければ ~/.claude/settings.json の hooks.PreToolUse から外してください:"); [print("   " + c[:120]) for c in others]
        if not _guard_hook_registered(st):
            st.setdefault("hooks", {}).setdefault("PreToolUse", []).append({"hooks": [{"type": "command", "command": _guard_hook_cmd(), "timeout": 600}]})
            save_json(USER_SETTINGS, st); print("関所のフック（PreToolUse）をユーザー設定に登録しました（AIOFFICE_DISCORD=1 の Claude にだけ効く）")
        os.makedirs(DESK_MIRROR, exist_ok=True)
        ok = _set_cfg_line(desk_f, "settings", GUARD_SETTINGS) | _set_cfg_line(mir_f, "settings", GUARD_SETTINGS)
        if not ok: sys.exit("モデル設定.txt に settings= を書けませんでした: %s" % desk_f)
        if args.work_only:
            _set_cfg_line(desk_f, "workonly", "1"); _set_cfg_line(mir_f, "workonly", "1")
            print("作業フォルダ限定も ON（~/ai-office-data・デスクトップの AIオフィス・起動フォルダ・開発部屋の外への書き込みは 🔐）")
        _guard_rehash()   # いまの本体の合図（ハッシュ）を控える → restart.* が guard verify で改変を見る
        print("見張りを ON にしました（次の起動から。危ない操作は統括の部屋に 🔐 が出て、持ち主の ✅ を待ちます）"); print("GUARD=on")
    elif args.action == "off":
        if _guard_hook_registered(st):
            pre = []
            for ent in st["hooks"]["PreToolUse"]:
                hs = [h for h in (ent.get("hooks") or []) if not ("discord-ai-office/guard/guard.py" in str(h.get("command", "")) and h.get("command", "").rstrip().endswith(" pre"))]
                if hs: ent["hooks"] = hs; pre.append(ent)
            st["hooks"]["PreToolUse"] = pre
            if not pre: del st["hooks"]["PreToolUse"]
            save_json(USER_SETTINGS, st); print("関所のフックをユーザー設定から外しました")
        _set_cfg_line(desk_f, "settings", ""); _set_cfg_line(mir_f, "settings", ""); _set_cfg_line(desk_f, "workonly", ""); _set_cfg_line(mir_f, "workonly", "")
        print("見張りを OFF にしました（次の起動から。記録 %s は残ります）" % os.path.join(GUARD_DIR, "log.jsonl")); print("GUARD=off")
    if args.restart:
        restart_and_report(office, "見張りを %s にします" % args.action.upper(), "設定は書き換え済みなので", "統括に「☀️ 再起動しました」が出たら完了")


def cmd_model(args):
    office = _office_dir(args)
    desk_f = os.path.join(office, "モデル設定.txt"); mir_f = os.path.join(DESK_MIRROR, "モデル設定.txt")
    if not args.name:
        cur = ""
        for f in (desk_f, mir_f):
            try:
                for l in io.open(f, encoding="utf-8"):
                    if l.startswith("model="): cur = l.split("=", 1)[1].strip()
                if cur: break
            except OSError: continue
        rec = io.open(RECOMMEND_FILE, encoding="utf-8").read().strip() if os.path.exists(RECOMMEND_FILE) else "（未取得）"
        live = running_model()
        print("今の設定: model=%s（auto のときの実体＝推奨 %s・取れなければ opus）" % (cur or "auto", rec))
        print("いま動いている Claude: %s" % (live or "（Discord 付きの Claude が見つからない／--model 未指定）"))
        if live and cur and cur != "auto" and live != cur: print("⚠ 設定と実物が違います（設定 %s／実物 %s）。次の再起動で設定の方になります" % (cur, live))
        print("MODEL=%s" % (cur or "auto")); print("RUNNING=%s" % (live or "")); return
    m = args.name.strip()
    if not MODEL_RE.match(m):
        sys.exit("モデル名は auto か、英数字・ピリオド・ハイフンだけ（例: opus / sonnet / claude-opus-5-5）。受け付けませんでした: %r" % m)
    os.makedirs(DESK_MIRROR, exist_ok=True)
    ok_desk = _set_model_line(desk_f, m); ok_mir = _set_model_line(mir_f, m)
    if not (ok_desk or ok_mir): sys.exit("モデル設定.txt に書けませんでした: %s" % desk_f)
    print("モデル設定を model=%s にしました（%s）" % (m, "デスクトップ＋写し" if ok_desk and ok_mir else ("デスクトップ" if ok_desk else "写しのみ（デスクトップは読めない場所）")))
    print("MODEL_SET=%s" % m)
    if args.restart:
        restart_and_report(office, "モデルを %s に切り替えます" % m, "設定は書き換え済みなので", "統括に「☀️ 再起動しました（モデル: …）」が出たら完了")


def restart_and_report(office, reason, already, done_hint):
    """再起動を頼み、ログが動き出したかを最大12秒確かめて RESTART=started / not_started を出す（model と new-session で共用）"""
    t0 = time.time()
    how = request_restart(office, reason)
    started = False
    for _ in range(12):   # 「始めました」と言ってから実は動いていなかった F-42/F-43 を防ぐ
        time.sleep(1)
        if _restart_log_started(t0, office): started = True; break
    via = {"task": "予約タスク", "launchd": "launchd", "detached": "切り離したプロセス"}[how]
    if started:
        print("再起動が始まりました（%s・1〜2分で切り替わります。%s）" % (via, done_hint)); print("RESTART=started")
    else:
        print("⚠ 再起動を頼みましたが（%s）、12秒たっても再起動のログが動き出しません。%s、パソコンの AIオフィス の「再起動」をダブルクリックすると切り替わります" % (via, already)); print("RESTART=not_started")
    return started


HANDOFF_FILE = os.path.join(OFFICE_DIR, "handoff.md")          # 次の起動が最初に読む引き継ぎメモ（起動時の指示に書いてある）
HANDOFF_PENDING = os.path.join(OFFICE_DIR, "handoff.pending")  # この印がある起動だけ handoff.md を読む。start.sh/.ps1 が消す


def cmd_new_session(args):
    """「新しいセッションにして」: AI が書いた引き継ぎ書を handoff.md に置き、再起動を頼む。会話が長くなったときにスマホだけで切り替えるため（masa 9/30 B4）"""
    office = _office_dir(args)
    src = os.path.abspath(args.file)
    try:
        body = io.open(src, encoding="utf-8").read().strip()
    except OSError as e:
        sys.exit("引き継ぎ書が読めません: %s（%s）" % (src, e))
    if len(body) < 20: sys.exit("引き継ぎ書が短すぎます（済んだこと・次の一手・触らないこと を書いてから）: %s" % src)
    if len(body) > 20000: sys.exit("引き継ぎ書が長すぎます（20,000文字まで。要点だけに）: %s" % src)
    stamp = time.strftime("%Y-%m-%d %H:%M")
    os.makedirs(OFFICE_DIR, exist_ok=True)
    io.open(HANDOFF_FILE, "w", encoding="utf-8", newline="\n").write(
        "# 引き継ぎ（%s・新しいセッションへ）\n\n起動したら最初にこれを読み、統括の部屋に「🧭 引き継ぎを読みました」で報告して続きから動くこと。\n\n%s\n" % (stamp, body))
    io.open(HANDOFF_PENDING, "w", encoding="utf-8", newline="\n").write(stamp + "\n")
    keep = os.path.join(HOME, "ai-office-data", "handoff"); os.makedirs(keep, exist_ok=True)
    kp = os.path.join(keep, "RESUME-%s.md" % time.strftime("%Y%m%d-%H%M"))
    if os.path.abspath(kp) != src: io.open(kp, "w", encoding="utf-8", newline="\n").write(body + "\n")
    print("引き継ぎ書を置きました: %s（控え %s）" % (HANDOFF_FILE, kp)); print("HANDOFF=%s" % HANDOFF_FILE)
    if args.no_restart: print("RESTART=skipped"); return
    restart_and_report(office, "新しいセッションに切り替えます", "引き継ぎ書は置いてあるので", "統括に「☀️ 再起動しました」→「🧭 引き継ぎを読みました」が出たら完了")


def main():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("whoami")
    p = sub.add_parser("setup"); p.add_argument("--guild"); p.add_argument("--category"); p.add_argument("--no-notice-room", action="store_true", dest="no_notice_room", help='お知らせ部屋を作らない')
    p = sub.add_parser("hire"); p.add_argument("name"); p.add_argument("role"); p.add_argument("--tone"); p.add_argument("--emoji"); p.add_argument("--guild")
    p.add_argument("--category"); p.add_argument("--room"); p.add_argument("--project"); p.add_argument("--engine", default="claude", choices=["claude", "codex"]); p.add_argument("--quiet", action="store_true"); p.add_argument("--skill")
    p.add_argument("--short", help="部屋名の【】に入れる短い呼び名（空なら役割の最初の「・」まで）")
    p = sub.add_parser("hire-all"); p.add_argument("--file", required=True); p.add_argument("--guild"); p.add_argument("--refresh", action="store_true"); p.add_argument("--quiet", action="store_true")
    p.add_argument("--no-notice-room", action="store_true", dest="no_notice_room", help='お知らせ部屋を作らない（設定シートの「お知らせ部屋 = なし」のとき setup_*.* から渡す）')
    p = sub.add_parser("test-room"); p.add_argument("--file", required=True)
    p = sub.add_parser("links"); p.add_argument("--out"); p.add_argument("--post", help="チャンネルID または hq（統括部屋）")
    p = sub.add_parser("backup"); p.add_argument("--out")
    sub.add_parser("list")
    p = sub.add_parser("say"); p.add_argument("channel"); p.add_argument("text")
    p = sub.add_parser("notice"); p.add_argument("text"); p.add_argument("--hq", action="store_true", help="お知らせ部屋があっても統括へ強制的に送る")
    p = sub.add_parser("watch-replies"); p.add_argument("--minutes", type=int, default=10)
    p = sub.add_parser("fire"); p.add_argument("name"); p.add_argument("--quiet", action="store_true")
    p = sub.add_parser("skill"); p.add_argument("name"); p.add_argument("skill_name")
    p = sub.add_parser("migrate"); p.add_argument("--out"); p.add_argument("--short", action="store_true")
    p = sub.add_parser("project"); p.add_argument("name"); p.add_argument("--dir"); p.add_argument("--emoji"); p.add_argument("--quiet", action="store_true")
    p.add_argument("--slug", help="フォルダの英語の短い名前（例: store-game）。名前が日本語なら必須"); p.add_argument("--brief", help="何を作るか（1〜3行）。CLAUDE.md・引き継ぎメモ・管制塔に入る")
    p = sub.add_parser("pause"); p.add_argument("--yes", action="store_true")
    sub.add_parser("resume")
    sub.add_parser("allow-basics")
    sub.add_parser("snippet-install")
    p = sub.add_parser("model"); p.add_argument("name", nargs="?"); p.add_argument("--restart", action="store_true"); p.add_argument("--office")
    p = sub.add_parser("usage"); p.add_argument("--days", type=int, default=7); p.add_argument("--post", action="store_true")
    p.add_argument("--week", type=int, help="Claude Code の /usage に出る週の％で目安を合わせる（例 40）"); p.add_argument("--5h", dest="five_h", type=int, help="同じく 5 時間の％")
    p.add_argument("--nick", nargs="?", const="update", default=None, help="このサーバーでの自分のニックネームに目安％を書く（値なし＝今すぐ更新／on＝常時5分おき／off＝名前を戻して止める。C4 2026-09-30）")
    p = sub.add_parser("token"); p.add_argument("action", choices=["protect", "unprotect", "status", "get"])
    sub.add_parser("hello")
    p = sub.add_parser("manifest"); p.add_argument("action", choices=["write", "diff"]); p.add_argument("--dir"); p.add_argument("--out")
    p = sub.add_parser("local"); p.add_argument("action", choices=["init", "status"])
    p = sub.add_parser("archive"); p.add_argument("name"); p.add_argument("--off", action="store_true", help="休止を解除")
    p = sub.add_parser("guard"); p.add_argument("action", choices=["on", "off", "status", "verify", "rehash"]); p.add_argument("--restart", action="store_true"); p.add_argument("--office"); p.add_argument("--work-only", action="store_true", help="作業フォルダの外への書き込みも 🔐 にする")
    p = sub.add_parser("new-session"); p.add_argument("--file", required=True, help="AI が書いた引き継ぎ書（md）"); p.add_argument("--office"); p.add_argument("--no-restart", action="store_true", help="置くだけ（試験用）")
    p = sub.add_parser("uninstall"); p.add_argument("--office"); p.add_argument("--yes", action="store_true")
    p = sub.add_parser("ask"); p.add_argument("channel"); p.add_argument("question"); p.add_argument("choices", nargs="+")
    p.add_argument("--timeout", type=int, default=21600); p.add_argument("--poll", type=int, default=5)   # 既定6時間（momomon K-39: 30分では外出中に切れる）
    ext = _load_local_ext(); ext_cmds = dict(getattr(ext, "COMMANDS", None) or {}) if ext else {}   # 持ち主の追加命令（local/office_ext.py）
    for name in ext_cmds:
        if name not in sub.choices: p = sub.add_parser(name); p.add_argument("rest", nargs="*")
    a = ap.parse_args()
    cmds = {"whoami": cmd_whoami, "setup": cmd_setup, "hire": cmd_hire, "hire-all": cmd_hire_all, "test-room": cmd_test_room, "links": cmd_links, "backup": cmd_backup,
     "list": cmd_list, "say": cmd_say, "notice": cmd_notice, "ask": cmd_ask, "migrate": cmd_migrate, "project": cmd_project, "fire": cmd_fire, "skill": cmd_skill, "watch-replies": cmd_watch_replies,
     "pause": cmd_pause, "resume": cmd_resume, "uninstall": cmd_uninstall, "allow-basics": cmd_allow_basics, "model": cmd_model, "snippet-install": cmd_snippet_install,
     "new-session": cmd_new_session, "guard": cmd_guard, "usage": cmd_usage, "token": cmd_token, "hello": cmd_hello, "archive": cmd_archive, "manifest": cmd_manifest, "local": cmd_local}
    cmds.update(ext_cmds); cmds[a.cmd](a)


if __name__ == "__main__":
    main()
