#!/bin/bash
# restart.sh — AIオフィス 定期再起動（Mac 用）: 予告 → Claude を落とす → バックアップ → 更新 → 起動 → 報告
OFFICE="${1:-$HOME/Desktop/AIオフィス}"
SKILL="$HOME/.claude/skills/discord-ai-office"; PY="$SKILL/scripts/office.py"
mkdir -p "$OFFICE/logs"; LOG="$OFFICE/logs/restart_$(date +%Y%m%d).log"
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"; export PYTHONUTF8=1
say() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOG"; }
say "=== AIオフィス 再起動 ==="
python3 "$PY" notice "🌙 $(date +%H:%M) 定期再起動に入ります（バックアップ→更新→起動。5分ほど返事が止まります）" 2>&1 | tee -a "$LOG"
pkill -f "claude.*--channels" && say "Claude Code を停止しました"; sleep 5
python3 "$PY" backup --out "$OFFICE/backups" 2>&1 | tee -a "$LOG"
say "claude update ..."; claude update 2>&1 | tail -3 | tee -a "$LOG"
if [ -f "$OFFICE/更新コマンド.txt" ]; then
  grep -v '^[[:space:]]*#' "$OFFICE/更新コマンド.txt" | grep -v '^[[:space:]]*$' | while read -r line; do say "更新: $line"; bash -c "$line" 2>&1 | tee -a "$LOG"; done
fi
bash "$SKILL/scripts/start.sh" "$OFFICE"
OK=1; for i in $(seq 1 15); do sleep 2; pgrep -f "claude.*--channels" >/dev/null || OK=""; done   # 30秒動き続けているか
if [ -n "$OK" ]; then python3 "$PY" notice "☀️ $(date +%H:%M) 再起動しました。引き継ぎを読んで続きから動きます" 2>&1 | tee -a "$LOG"
else python3 "$PY" notice "⚠️ $(date +%H:%M) 再起動で Claude が立ち上がりませんでした。パソコンの「AIオフィス」フォルダの 起動.command をダブルクリックしてください" 2>&1 | tee -a "$LOG"; fi
say "=== 再起動 完了 ==="
