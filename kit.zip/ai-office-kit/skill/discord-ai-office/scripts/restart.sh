#!/bin/bash
# restart.sh — AIオフィス 定期再起動（Mac 用）: 予告 → Claude を落とす → バックアップ → 更新 → 起動 → 報告
OFFICE="${1:-$HOME/Desktop/AIオフィス}"; REASON="${2:-}"   # 2つ目＝再起動の理由（モデル切替など。あれば更新は飛ばす）
RF="$HOME/.claude/ai-office/restart_reason.txt"; if [ -z "$REASON" ] && [ -f "$RF" ]; then REASON="$(head -1 "$RF")"; rm -f "$RF"; fi   # office.py が頼んだ再起動（launchd 経由）
SKILL="$HOME/.claude/skills/discord-ai-office"; PY="$SKILL/scripts/office.py"
OUTD="$OFFICE"; { mkdir -p "$OFFICE/logs" && touch "$OFFICE/.w" && rm -f "$OFFICE/.w"; } >/dev/null 2>&1 || OUTD="$HOME/.claude/ai-office"   # launchd からはデスクトップに書けない（macOS の保護）
mkdir -p "$OUTD/logs" "$OUTD/backups"; LOG="$OUTD/logs/restart_$(date +%Y%m%d).log"
UPD="$OFFICE/更新コマンド.txt"; head -c1 "$UPD" >/dev/null 2>&1 || UPD="$HOME/.claude/ai-office/desk/更新コマンド.txt"   # 読めないときは写し
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"; export PYTHONUTF8=1
say() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOG"; }
say "=== AIオフィス 再起動 ==="
if [ -n "$REASON" ]; then python3 "$PY" notice "🔌 $(date +%H:%M) $REASON（1〜2分で戻ります）" 2>&1 | tee -a "$LOG"
else python3 "$PY" notice "🌙 $(date +%H:%M) 定期再起動に入ります（バックアップ→更新→起動。5分ほど返事が止まります）" 2>&1 | tee -a "$LOG"; fi
pkill -f "claude.*--channels"
for i in $(seq 1 20); do pgrep -f "claude.*--channels" >/dev/null || break; sleep 1; done   # 消えるまで待つ（残っていると新しい方が「もう動いています」で立ち上がらない）
pgrep -f "claude.*--channels" >/dev/null && pkill -9 -f "claude.*--channels"; sleep 2
say "Claude Code を停止しました"
python3 "$PY" backup --out "$OUTD/backups" 2>&1 | tee -a "$LOG"
if [ -z "$REASON" ]; then say "claude update ..."; claude update 2>&1 | tail -3 | tee -a "$LOG"; fi
if [ -z "$REASON" ] && [ -f "$UPD" ]; then
  grep -v '^[[:space:]]*#' "$UPD" | grep -v '^[[:space:]]*$' | while read -r line; do say "更新: $line"; bash -c "$line" 2>&1 | tee -a "$LOG"; done
fi
bash "$SKILL/scripts/start.sh" "$OFFICE"
OK=1; for i in $(seq 1 15); do sleep 2; pgrep -f "claude.*--channels" >/dev/null || OK=""; done   # 30秒動き続けているか
NOWM="$(sed -n 's/^モデル auto → //p' "$OUTD/logs/start_$(date +%Y%m%d).log" 2>/dev/null | tail -1)"; [ -z "$NOWM" ] && NOWM="$(sed -n 's/^model=//p' "$HOME/.claude/ai-office/desk/モデル設定.txt" 2>/dev/null | head -1)"
if [ -n "$OK" ]; then python3 "$PY" notice "☀️ $(date +%H:%M) 再起動しました${NOWM:+（モデル: $NOWM）}。引き継ぎを読んで続きから動きます" 2>&1 | tee -a "$LOG"
else python3 "$PY" notice "⚠️ $(date +%H:%M) 再起動で Claude が立ち上がりませんでした。パソコンの「AIオフィス」フォルダの 起動.command をダブルクリックしてください" 2>&1 | tee -a "$LOG"; fi
say "=== 再起動 完了 ==="
