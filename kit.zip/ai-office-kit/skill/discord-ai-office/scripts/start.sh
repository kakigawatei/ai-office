#!/bin/bash
# start.sh — AIオフィス 起動（Mac 用・初回セットアップ込み）。起動.command から呼ばれる
#   bash start.sh <AIオフィス フォルダ> [--no-launch]
OFFICE="${1:-$HOME/Desktop/AIオフィス}"; NOLAUNCH="$2"
SKILL="$HOME/.claude/skills/discord-ai-office"; PY="$SKILL/scripts/office.py"
TOKENF="$HOME/.claude/channels/discord/.env"
mkdir -p "$OFFICE/logs"; LOG="$OFFICE/logs/start_$(date +%Y%m%d).log"
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"; export PYTHONUTF8=1
say() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOG"; }

say "=== AIオフィス 起動 ==="
need=()
for t in python3 claude; do command -v $t >/dev/null 2>&1 || need+=($t); done
if [ ${#need[@]} -gt 0 ]; then
  say "足りない道具: ${need[*]}"
  command -v brew >/dev/null 2>&1 || say "  まず Homebrew: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
  [[ " ${need[*]} " == *" node "* ]] && say "  brew install node"
  [[ " ${need[*]} " == *" python3 "* ]] && say "  brew install python"
  [[ " ${need[*]} " == *" claude "* ]] && say "  curl -fsSL https://claude.ai/install.sh | bash"
  read -r -p "いま自動で入れますか？ (y/n) " ans
  if [ "$ans" = "y" ]; then
    command -v brew >/dev/null 2>&1 || /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null || /usr/local/bin/brew shellenv)"
    [[ " ${need[*]} " == *" node "* ]] && brew install node
    [[ " ${need[*]} " == *" python3 "* ]] && brew install python
    [[ " ${need[*]} " == *" claude "* ]] && (curl -fsSL https://claude.ai/install.sh | bash)
    say "入れました。このウィンドウを閉じて、もう一度 起動.command を開いてください"
  fi
  read -r -p "Enter で閉じる"; exit 0
fi
say "道具OK: python3 / claude"

if ! grep -q "DISCORD_BOT_TOKEN=." "$TOKENF" 2>/dev/null; then
  say "Discord bot のトークンがまだ入っていません。"
  say "  1) bot を作る: 開いたテキストの指示文を Claude in Chrome に貼る（ログインと最後の「認証」だけ自分で押す）"
  say "  2) これから開く Claude Code の画面で  /plugin install discord@claude-plugins-official  →  /discord:configure  でトークンを貼る"
  say "  3) 続けて  /discord:access  で自分の Discord ユーザーIDを許可する"
  say "  4) 終わったら Claude Code を閉じて、もう一度 起動.command"
  open -e "$SKILL/browser/create_bot_instruction.txt"
  osascript -e 'tell application "Terminal" to do script "claude"' >/dev/null
  read -r -p "Enter で閉じる"; exit 0
fi
say "bot トークンOK"

NEW=0
if [ -f "$OFFICE/社員名簿.txt" ]; then
  OUT=$(python3 "$PY" hire-all --file "$OFFICE/社員名簿.txt" 2>&1); echo "$OUT" | tee -a "$LOG"
  NEW=$(echo "$OUT" | sed -n 's/^NEW=\([0-9]*\).*/\1/p' | tail -1); NEW=${NEW:-0}
  if echo "$OUT" | grep -q "HTTP 403"; then say "★ bot の権限不足です。上の URL を開いて認証してから、もう一度 起動.command"; read -r -p "Enter で閉じる"; exit 1; fi
fi
python3 "$PY" links --out "$OFFICE" 2>&1 | tee -a "$LOG"
[ "$NEW" -gt 0 ] 2>/dev/null && python3 "$PY" links --post hq 2>&1 | tee -a "$LOG"

if pgrep -f "claude.*--channels" >/dev/null; then say "Claude Code（Discord付き）はすでに動いています。二重起動しません。"; exit 0; fi
[ "$NOLAUNCH" = "--no-launch" ] && { say "（--no-launch のため起動はしない）"; exit 0; }
LAUNCH="$HOME/.claude/ai-office/launch_claude.command"; mkdir -p "$(dirname "$LAUNCH")"
PROMPT=""; [ -f "$OFFICE/起動時の指示.txt" ] && PROMPT="$(cat "$OFFICE/起動時の指示.txt")"
MODEL="$(sed -n 's/^model=//p' "$OFFICE/モデル設定.txt" 2>/dev/null | head -1)"; MODEL="${MODEL:-opus}"
EFFORT="$(sed -n 's/^effort=//p' "$OFFICE/モデル設定.txt" 2>/dev/null | head -1)"; EFFORT="${EFFORT:-high}"
PERM="$(sed -n 's/^permission=//p' "$OFFICE/モデル設定.txt" 2>/dev/null | head -1 | tr -d '\r[:space:]')"; PERM="${PERM:-auto}"   # 既定は auto mode（確認を減らす）。モデル設定.txt で manual などに変えられる
{ echo '#!/bin/bash'; echo 'export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"'; echo 'export MCP_TIMEOUT=180000'; echo 'cd "$HOME/Desktop"';
  if [ -n "$PROMPT" ]; then printf 'claude %q --model %q --effort %q --permission-mode %q --channels plugin:discord@claude-plugins-official\n' "$PROMPT" "$MODEL" "$EFFORT" "$PERM"; else printf 'claude --model %q --effort %q --permission-mode %q --channels plugin:discord@claude-plugins-official\n' "$MODEL" "$EFFORT" "$PERM"; fi; } > "$LAUNCH"; chmod +x "$LAUNCH"   # 指示文は --channels より前（後ろだとチャンネル名として読まれてエラー）
# 初回の画面（テーマ選び・フォルダを信頼するか）を先に済ませておく＝起動で止まらない
/usr/bin/python3 - "$HOME/.claude.json" "$HOME/Desktop" <<'PYEOF'
import json, os, sys
p, cwd = sys.argv[1], sys.argv[2]
try: c = json.load(open(p))
except Exception: c = {}
c["hasCompletedOnboarding"] = True; c.setdefault("theme", "dark"); c["fullscreenUpsellSeenCount"] = max(99, c.get("fullscreenUpsellSeenCount", 0)); c.setdefault("claudeInChromeDefaultEnabled", False)  # 起動時の「全画面表示を試す？」「Claude in Chrome を使う？」で止まらない（再起動が無人で通るように）
pr = c.setdefault("projects", {}).setdefault(cwd, {}); pr["hasTrustDialogAccepted"] = True
json.dump(c, open(p, "w"), ensure_ascii=False, indent=2)
PYEOF
open -a Terminal "$LAUNCH"   # .command を開く＝新しいターミナル窓で起動（「Terminal を操作する許可」を聞かれない）
say "Claude Code を起動しました（Discord プラグイン付き）"
say "=== 起動 完了 ==="
