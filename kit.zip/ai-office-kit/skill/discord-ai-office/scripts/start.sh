#!/bin/bash
# start.sh — AIオフィス 起動（Mac 用・初回セットアップ込み）。起動.command から呼ばれる
#   bash start.sh <AIオフィス フォルダ> [--no-launch]
OFFICE="${1:-$HOME/Desktop/AIオフィス}"; NOLAUNCH="$2"
SKILL="$HOME/.claude/skills/discord-ai-office"; PY="$SKILL/scripts/office.py"
TOKENF="$HOME/.claude/channels/discord/.env"
MIR="$HOME/.claude/ai-office/desk"; mkdir -p "$MIR" "$HOME/.claude/ai-office/logs"   # 机の上の設定の写し。launchd（定期再起動・ログイン時）から動くと macOS の保護でデスクトップが読めないため、人が起動したときに写しを更新し、読めないときは写しを使う
if head -c1 "$OFFICE/社員名簿.txt" >/dev/null 2>&1 || head -c1 "$OFFICE/モデル設定.txt" >/dev/null 2>&1; then
  CFG="$OFFICE"; for f in 社員名簿.txt モデル設定.txt 起動時の指示.txt 更新コマンド.txt; do [ -f "$OFFICE/$f" ] && cp -f "$OFFICE/$f" "$MIR/$f" 2>/dev/null; done
else CFG="$MIR"; fi
OUTD="$OFFICE"; { mkdir -p "$OFFICE/logs" && touch "$OFFICE/.w" && rm -f "$OFFICE/.w"; } >/dev/null 2>&1 || OUTD="$HOME/.claude/ai-office"   # デスクトップに書けないときの置き場
LOG="$OUTD/logs/start_$(date +%Y%m%d).log"; mkdir -p "$OUTD/logs"
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"; export PYTHONUTF8=1
say() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOG"; }

say "=== AIオフィス 起動 ==="
need=()
for t in python3 claude; do command -v $t >/dev/null 2>&1 || need+=($t); done
if [ ${#need[@]} -gt 0 ]; then
  say "足りない道具: ${need[*]}"
  command -v brew >/dev/null 2>&1 || say "  まず Homebrew: /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
  [[ " ${need[*]} " == *" node "* ]] && say "  brew install node"
  [[ " ${need[*]} " == *" python3 "* ]] && say "  brew install python"
  [[ " ${need[*]} " == *" claude "* ]] && say "  curl -fsSL https://claude.ai/install.sh | bash"
  read -r -p "いま自動で入れますか？ (y/n) " ans
  if [ "$ans" = "y" ]; then
    command -v brew >/dev/null 2>&1 || /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null || /usr/local/bin/brew shellenv)"
    [[ " ${need[*]} " == *" node "* ]] && brew install node
    [[ " ${need[*]} " == *" python3 "* ]] && brew install python
    [[ " ${need[*]} " == *" claude "* ]] && (curl -fsSL https://claude.ai/install.sh | bash)
    say "入れました。このウィンドウを閉じて、もう一度 起動.command を開いてください"
  fi
  read -r -p "Enter で閉じる"; exit 0
fi
say "道具OK: python3 / claude"

if ! grep -q "DISCORD_BOT_TOKEN=." "$TOKENF" 2>/dev/null; then
  say "Discord bot のトークンがまだ入っていません。セットアップをもう一度やってください:"
  say "  キットのフォルダ（~/ai-office-kit）の「セットアップ.command」をダブルクリック（または販売ページの Mac 用の1行を貼り直す）"
  [ -t 0 ] && read -r -p "Enter で閉じる"; exit 0
fi
say "bot トークンOK"
python3 "$PY" allow-basics 2>&1 | grep -v "^ALLOW_ADDED=0" | tee -a "$LOG"   # Discord の道具と作業場所の許可（auto でも返事が止まらない）
python3 "$PY" resume 2>&1 | grep -v "^RESUME=" | tee -a "$LOG"   # お休み中なら、自動再起動と見張りを戻す

NEW=0
if [ -f "$CFG/社員名簿.txt" ]; then
  OUT=$(python3 "$PY" hire-all --file "$CFG/社員名簿.txt" 2>&1); echo "$OUT" | tee -a "$LOG"
  NEW=$(echo "$OUT" | sed -n 's/^NEW=\([0-9]*\).*/\1/p' | tail -1); NEW=${NEW:-0}
  if echo "$OUT" | grep -q "HTTP 403"; then say "★ bot の権限不足です。上の URL を開いて認証してから、もう一度 起動.command"; [ -t 0 ] && read -r -p "Enter で閉じる"; exit 1; fi
fi
python3 "$PY" links --out "$OUTD" 2>&1 | tee -a "$LOG"
[ "$NEW" -gt 0 ] 2>/dev/null && python3 "$PY" links --post hq 2>&1 | tee -a "$LOG"

if pgrep -f "claude.*--channels" >/dev/null; then say "Claude Code（Discord付き）はすでに動いています。二重起動しません。"; exit 0; fi
[ "$NOLAUNCH" = "--no-launch" ] && { say "（--no-launch のため起動はしない）"; exit 0; }
LAUNCH="$HOME/.claude/ai-office/launch_claude.command"; mkdir -p "$(dirname "$LAUNCH")"
PROMPT=""; [ -f "$CFG/起動時の指示.txt" ] && PROMPT="$(cat "$CFG/起動時の指示.txt")"
MODEL="$(sed -n 's/^model=//p' "$CFG/モデル設定.txt" 2>/dev/null | head -1 | tr -d '\r[:space:]')"; MODEL="${MODEL:-auto}"
if [ "$MODEL" = "auto" ]; then   # auto＝公開ページの推奨1行に追随（英数字・ピリオド・ハイフンだけ受け付ける）。取れなければ前回の値、それも無ければ opus
  REC="$(curl -fsSL -m 6 https://kakigawatei.github.io/ai-office/model.txt 2>/dev/null | head -1 | tr -d '\r[:space:]')"
  if printf '%s' "$REC" | grep -Eq '^[A-Za-z][A-Za-z0-9.-]{1,40}$'; then printf '%s\n' "$REC" > "$HOME/.claude/ai-office/recommended_model.txt"; fi
  MODEL="$(head -1 "$HOME/.claude/ai-office/recommended_model.txt" 2>/dev/null | tr -d '\r[:space:]')"
  printf '%s' "$MODEL" | grep -Eq '^[A-Za-z][A-Za-z0-9.-]{1,40}$' || MODEL="opus"   # 写しが壊れていても英数字以外は使わない
  say "モデル auto → $MODEL"
fi
EFFORT="$(sed -n 's/^effort=//p' "$CFG/モデル設定.txt" 2>/dev/null | head -1)"; EFFORT="${EFFORT:-high}"
PERM="$(sed -n 's/^permission=//p' "$CFG/モデル設定.txt" 2>/dev/null | head -1 | tr -d '\r[:space:]')"; PERM="${PERM:-auto}"   # 既定は auto mode（確認を減らす）。モデル設定.txt で manual などに変えられる
GSET="$(sed -n 's/^settings=//p' "$CFG/モデル設定.txt" 2>/dev/null | head -1 | tr -d '\r')"; [ -n "$GSET" ] && [ -f "$GSET" ] || GSET="$SKILL/templates/discord-settings.json"   # 秘密を読ませない一覧（Discord 用の起動にだけ効く）
WORK="$(sed -n 's/^workdir=//p' "$CFG/モデル設定.txt" 2>/dev/null | head -1 | tr -d '\r')"; [ -n "$WORK" ] && [ -d "$WORK" ] || WORK="$HOME/Desktop"   # 起動フォルダ（作業フォルダの社員・スキルを使うとき）
# [F-33] ほかのセッションで Discord 部品の接続に失敗すると「認証が要る」印が残り、次の起動で Discord につながらない → 起動の直前に discord の印だけ消す
/usr/bin/python3 -c "import json,os,sys; p=sys.argv[1]; c=json.load(open(p)) if os.path.exists(p) else None; k=[x for x in (c or {}) if x.startswith('plugin:discord:')]; [c.pop(x) for x in k]; (json.dump(c,open(p,'w')) if k else None); print('needs-auth の印を消した' if k else 'needs-auth の印なし')" "$HOME/.claude/mcp-needs-auth-cache.json" 2>&1 | tee -a "$LOG"
{ echo '#!/bin/bash'; echo 'for v in $(env | awk -F= "/^(CLAUDE|ANTHROPIC_|MCP_)/{print \$1}"); do unset "$v"; done   # [K-10] 親の Claude から引き継いだ変数を消す（子セッション扱い・Discord 未接続を防ぐ）'; echo 'export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"'; echo 'export MCP_TIMEOUT=180000'; echo 'export AIOFFICE_DISCORD=1'; printf 'cd %q\n' "$WORK";
  if [ -n "$PROMPT" ]; then printf 'claude %q --model %q --effort %q --permission-mode %q --settings %q --channels plugin:discord@claude-plugins-official\n' "$PROMPT" "$MODEL" "$EFFORT" "$PERM" "$GSET"; else printf 'claude --model %q --effort %q --permission-mode %q --settings %q --channels plugin:discord@claude-plugins-official\n' "$MODEL" "$EFFORT" "$PERM" "$GSET"; fi; } > "$LAUNCH"; chmod +x "$LAUNCH"   # 指示文は --channels より前（後ろだとチャンネル名として読まれてエラー）
# 初回の画面（テーマ選び・フォルダを信頼するか）を先に済ませておく＝起動で止まらない
/usr/bin/python3 - "$HOME/.claude.json" "$WORK" <<'PYEOF'
import json, os, sys
p, cwd = sys.argv[1], sys.argv[2]
try: c = json.load(open(p))
except Exception: c = {}
c["hasCompletedOnboarding"] = True; c.setdefault("theme", "dark"); c["fullscreenUpsellSeenCount"] = max(99, c.get("fullscreenUpsellSeenCount", 0)); c.setdefault("claudeInChromeDefaultEnabled", False)  # 起動時の「全画面表示を試す？」「Claude in Chrome を使う？」で止まらない（再起動が無人で通るように）
pr = c.setdefault("projects", {}).setdefault(cwd, {}); pr["hasTrustDialogAccepted"] = True
json.dump(c, open(p, "w"), ensure_ascii=False, indent=2)
PYEOF
open -a Terminal "$LAUNCH"   # .command を開く＝新しいターミナル窓で起動（「Terminal を操作する許可」を聞かれない）
say "Claude Code を起動しました（Discord プラグイン付き）"
say "=== 起動 完了 ==="
