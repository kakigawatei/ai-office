﻿# setup_windows.ps1 — AIオフィス まとめてセットアップ（Windows）。install.ps1（PowerShell に1行）から呼ばれる
#   powershell -NoProfile -ExecutionPolicy Bypass -File setup_windows.ps1 -Kit <キットのフォルダ>
#   途中で止まっても、もう一度同じ1行で頭から通せる（入っているものは飛ばす）
param([Parameter(Mandatory=$true)][string]$Kit)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Continue"
$Host.UI.RawUI.WindowTitle = "AIオフィス セットアップ"
$Test  = [bool]$env:AIO_TEST                                   # 作り手の動作確認用（ログイン・画面操作・本物のトークン確認を飛ばす）
$Home_ = $env:USERPROFILE
$Sheet = Join-Path $Kit "設定シート.txt"
$SK    = Join-Path $Home_ ".claude\skills\discord-ai-office"
$Desk0 = [Environment]::GetFolderPath("Desktop"); if ($Test -or -not $Desk0) { $Desk0 = Join-Path $Home_ "Desktop" }   # OneDrive のデスクトップにも対応
$Desk  = Join-Path $Desk0 "AIオフィス"
$CH    = Join-Path $Home_ ".claude\channels\discord"
$Logs  = Join-Path $Desk "logs"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$env:PYTHONUTF8 = "1"

function Step($t) { Write-Host ""; Write-Host ("━━ " + $t + " ━━") -ForegroundColor Cyan }
function Ok($t)   { Write-Host ("✓ " + $t) -ForegroundColor Green }
function Warn($t) { Write-Host ("⚠ " + $t) -ForegroundColor Yellow }
function Fail($t) { Write-Host ""; Write-Host ("✗ " + $t) -ForegroundColor Red; Write-Host "（この画面のスクショを送ってください）"
  if ($script:Bz) { Write-Host ("  更新の直前に戻すには: デスクトップの AIオフィス の「戻す」をダブルクリック →「更新の直前」（控え: " + $script:Bz + "）") }
  elseif ((Test-Path (Join-Path $Home_ ".claude\ai-office\preinstall\info.txt")) -and (Test-Path (Join-Path $SK "scripts\office.py"))) { Write-Host "  入れる前に戻すには: デスクトップの AIオフィス の「やめる」をダブルクリック（入れる前の控えを見て、キットが足した分だけを外します）" }
  Read-Host "Enter で閉じる" | Out-Null; exit 1 }
function Drain()  { try { while ([Console]::KeyAvailable) { [void][Console]::ReadKey($true) } } catch {} }   # 間違って貼られた文字を捨てる（あとでコマンドとして動かないように）
function RefreshPath() {
  $m = [Environment]::GetEnvironmentVariable("Path", "Machine"); $u = [Environment]::GetEnvironmentVariable("Path", "User")
  $extra = @((Join-Path $Home_ ".local\bin"), (Join-Path $Home_ ".bun\bin"))
  $env:Path = (@($extra) + @($m, $u) | Where-Object { $_ }) -join ";"
}
function Val($key) {
  foreach ($l in (Get-Content $Sheet -Encoding UTF8)) { if ($l -match ("^\s*" + [regex]::Escape($key) + "\s*=\s*(.*?)\s*$")) { return $Matches[1] } }
  return ""
}
function HasPython() { try { $o = & python -c "print(12345)" 2>$null; return ($o -eq "12345") } catch { return $false } }   # Microsoft Store の偽 python を除く
function Winget($id) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Fail "winget（アプリのインストーラ）がありません。Microsoft Store で「アプリ インストーラー」を入れてから、もう一度同じ1行" }
  winget install --id $id -e --silent --accept-source-agreements --accept-package-agreements | Out-Host
  RefreshPath
}

$Server = Val "サーバー名"; if (-not $Server) { $Server = "AIオフィス" }
$Bot    = Val "bot名";      if (-not $Bot)    { $Bot = "AI社員" }
$RT     = Val "再起動の時刻"; if (-not $RT)    { $RT = "04:00" }
$Model  = Val "モデル"; if (-not $Model) { $Model = "auto" }
$Effort = Val "考える深さ"; if (-not $Effort) { $Effort = "high" }
$Notice = Val "お知らせ部屋"   # C1 2026-09-30: 「なし」なら hire-all に --no-notice-room を渡す（既定＝作る）
$UsageNick = Val "使用量を名前に"   # C4 2026-09-30: 「なし」なら usage --nick off を呼ぶ（既定＝あり）
RefreshPath

Step "1/8 ファイルを置く"
$Pre = Join-Path $Home_ ".claude\ai-office\preinstall"
if (-not (Test-Path $SK) -and -not (Test-Path (Join-Path $Pre "info.txt"))) {   # 最初に入れる前の控え（1回だけ・上書きしない）。「やめる」はこれを見て、入れる前からあった物を残しキットが足した分だけを外す。Python が無い PC でも取れるよう PowerShell だけで（2026-10-02 テスター向け・office.py preinstall と同じ形）
  New-Item -ItemType Directory -Force $Pre | Out-Null
  $info = @("at=" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), "by=setup_windows.ps1")
  foreach ($pair in @(@("CLAUDE.md", (Join-Path $Home_ ".claude\CLAUDE.md")), @("settings.json", (Join-Path $Home_ ".claude\settings.json")), @("access.json", (Join-Path $CH "access.json")),
                      @("installed_plugins.json", (Join-Path $Home_ ".claude\plugins\installed_plugins.json")), @("known_marketplaces.json", (Join-Path $Home_ ".claude\plugins\known_marketplaces.json")))) {
    if (Test-Path $pair[1]) { Copy-Item -Force $pair[1] (Join-Path $Pre $pair[0]); $info += ("had_" + $pair[0] + "=1") } else { $info += ("had_" + $pair[0] + "=0") }
  }
  $info += ("had_env=" + [int](Test-Path (Join-Path $CH ".env")))
  $info += ("had_claude_cli=" + [int][bool](Get-Command claude -ErrorAction SilentlyContinue)); $info += ("had_bun=" + [int][bool](Get-Command bun -ErrorAction SilentlyContinue)); $info += "had_kit=0"
  $info += ("skills=" + ((Get-ChildItem (Join-Path $Home_ ".claude\skills") -Directory -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ","))
  $proj = Join-Path $Home_ ".claude\projects"; $hist = @()
  if (Test-Path $proj) { $epoch = [datetime]"1970-01-01Z"; $hist = @(Get-ChildItem $proj -Recurse -File -Filter "*.jsonl" -ErrorAction SilentlyContinue | ForEach-Object { "{0} {1} {2}" -f [int64]($_.LastWriteTimeUtc - $epoch.ToUniversalTime()).TotalSeconds, $_.Length, ($_.FullName.Substring($Home_.Length + 1) -replace "\\", "/") }) }   # 会話の履歴は一覧だけ（中身は写さない）
  [IO.File]::WriteAllLines((Join-Path $Pre "history.txt"), [string[]]$hist, $Utf8NoBom)
  [IO.File]::WriteAllLines((Join-Path $Pre "info.txt"), [string[]]$info, $Utf8NoBom)
  try { icacls $Pre /inheritance:r /grant:r ("{0}:(OI)(CI)F" -f $env:USERNAME) *> $null } catch {}   # settings.json に env（鍵）を書いている人もいる＝本人だけ
  Ok ("入れる前の控え: " + $Pre + "（会話の履歴 " + $hist.Count + " 件を記録。やめるときは、これを見て入れる前に戻します）")
}
New-Item -ItemType Directory -Force (Join-Path $Home_ ".claude\skills") | Out-Null
$Bk = ""; $Bz = ""
$NewPy = Join-Path $Kit "skill\discord-ai-office\scripts\office.py"
if (Test-Path $SK) {   # 更新: ①全体の控え（戻す用）②前のスキルを丸ごと控える（5世代）③持ち主が変えていたファイルを見つけたら、上書きの前に止まって聞く（v1.6 momomon R-1）
  try { $Bz = ((& python $NewPy backup --tag before-update --skill $SK --desk $Desk 2>$null) | Where-Object { $_ -match "^BACKUP=" } | Select-Object -First 1) -replace "^BACKUP=", "" } catch {}
  if ($Bz) { Ok ("更新の前の控え: " + $Bz + "（困ったらデスクトップの AIオフィス の「戻す」で戻せます）") } else { Warn "更新の前の全体の控えを取れませんでした（スキルの控えは取ります）" }
  $BkDir = Join-Path $Home_ ".claude\ai-office\backups"; New-Item -ItemType Directory -Force $BkDir | Out-Null
  $Bk = Join-Path $BkDir ("skill_" + (Get-Date -Format "yyyyMMdd_HHmm")); Copy-Item -Recurse -Force $SK $Bk
  Get-ChildItem $BkDir -Directory -Filter "skill_*" | Sort-Object Name -Descending | Select-Object -Skip 5 | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  $cm = Join-Path $Home_ ".claude\CLAUDE.md"; if (Test-Path $cm) { Copy-Item -Force $cm (Join-Path $Bk "CLAUDE.md.before") }   # 決まりの違い（R-4）を更新の報告に出すため
  try { & python $NewPy manifest diff --dir $SK --out (Join-Path $Bk "CHANGED.txt") 2>$null | Where-Object { $_ -notmatch "^CHANGED=" } | ForEach-Object { Write-Host ("  " + $_) } } catch {}
  $cf = Join-Path $Bk "CHANGED.txt"
  if ((Test-Path $cf) -and (Get-Item $cf).Length -gt 0) {
    $lst = @(Get-Content $cf -Encoding UTF8 | Where-Object { $_ })
    Write-Host ""; Warn ("前の版で、あなたが変えていたキットのファイルがあります。更新すると新しい版で置き換わります（控え: " + $Bk + "）:")
    $lst | ForEach-Object { Write-Host ("   " + $_) }
    Write-Host "   残したい直しは ~/.claude/ai-office/local/ に移すと、更新で消えません（統括に「local に移して」と頼めます）"
    if ($env:AIOFFICE_FORCE -ne "1") {
      $ans = ""; try { $ans = (Read-Host "このまま置き換えて更新するなら「はい」と打って Enter（やめるならそのまま Enter）").Trim() } catch {}
      if (@("はい", "hai", "y", "Y", "yes") -contains $ans) { Write-Host "  → 置き換えて続けます（控えはあります）" }
      else {
        try { & python (Join-Path $SK "scripts\office.py") notice ("⚠️ 更新を止めました: あなたが変えていたキットのファイルが " + $lst.Count + " 件あります（控え: " + $Bk + "）。直しを local/ に移すか、置き換えてよければもう一度更新して「はい」") *> $null } catch {}
        Write-Host ""; Write-Host "更新をやめました。何も変えていません。直しを local/ に移してから、もう一度同じ1行で更新してください"
        Write-Host "（置き換えてよいときは、先に `$env:AIOFFICE_FORCE=1 と打ってから同じ1行でも進めます）"; try { Read-Host "Enter で閉じる" | Out-Null } catch {}; exit 0
      }
    }
  }
}
$SKnew = $SK + ".new"; $SKold = $SK + ".old"   # 新しい版を横に置いてから差し替える（v1.6 までは先に消していた＝写す途中で失敗すると空になった）
if (Test-Path $SKnew) { Remove-Item -Recurse -Force $SKnew }
try { Copy-Item -Recurse -ErrorAction Stop (Join-Path $Kit "skill\discord-ai-office") $SKnew } catch {}
if (-not ((Test-Path (Join-Path $SKnew "scripts\office.py")) -and (Test-Path (Join-Path $SKnew "VERSION")))) { Remove-Item -Recurse -Force $SKnew -ErrorAction SilentlyContinue; Fail "新しい版を置けませんでした（空き容量・権限）。前の版はそのまま残っています" }
if (Test-Path $SKold) { Remove-Item -Recurse -Force $SKold -ErrorAction SilentlyContinue }
if (Test-Path $SK) { try { Rename-Item -ErrorAction Stop $SK (Split-Path $SKold -Leaf) } catch { Remove-Item -Recurse -Force $SKnew -ErrorAction SilentlyContinue; Fail "前の版を差し替えられませんでした（ファイルを開いているアプリを閉じて、もう一度同じ1行）。前の版はそのまま残っています" } }
try { Rename-Item -ErrorAction Stop $SKnew (Split-Path $SK -Leaf) } catch { if (Test-Path $SKold) { Rename-Item $SKold (Split-Path $SK -Leaf) }; Fail "新しい版に差し替えられませんでした。前の版に戻しました" }
Remove-Item -Recurse -Force $SKold -ErrorAction SilentlyContinue
foreach ($d in (Get-ChildItem (Join-Path $Kit "skill") -Directory | Where-Object { $_.Name -ne "discord-ai-office" })) {   # 同梱スキル（例 invoice-inbox）: 無いときだけ入れる。育てた自分の版は上書きしない（2026-10-01）
  $dst = Join-Path $Home_ (".claude\skills\" + $d.Name)
  if (Test-Path $dst) { Write-Host ("  同梱スキル " + $d.Name + " はもう入っています（あなたの版を残しました。新しい版は " + $d.FullName + "）") }
  else { Copy-Item -Recurse $d.FullName $dst; Write-Host ("  ✓ 同梱スキル " + $d.Name + " を入れました") }
}
if (-not (Test-Path $Desk)) { Copy-Item -Recurse (Join-Path $Kit "AIオフィス") $Desk }
foreach ($b in @("起動.bat", "再起動.bat", "お休み.bat", "やめる.bat", "戻す.bat")) { Copy-Item -Force (Join-Path $Kit ("AIオフィス\" + $b)) (Join-Path $Desk $b) }
foreach ($f in @("起動時の指示.txt", "Discordで開発する使い方.txt")) {   # キット側の説明は毎回新しくする（前のは .bak）
  $dst = Join-Path $Desk $f; $src = Join-Path $Kit ("AIオフィス\" + $f)
  if ((Test-Path $dst) -and ((Get-FileHash $dst).Hash -ne (Get-FileHash $src).Hash)) { Copy-Item -Force $dst ($dst + ".bak"); Copy-Item -Force $dst ($dst + ".bak_" + (Get-Date -Format "yyyyMMdd_HHmm")) }   # 前のものは .bak（最新）と日付つきの両方で残す
  Copy-Item -Force $src $dst
}
Get-ChildItem $Desk -Filter *.command -ErrorAction SilentlyContinue | Remove-Item -Force   # Windows では Mac 用は置かない
New-Item -ItemType Directory -Force $Logs | Out-Null
$lines = Get-Content $Sheet -Encoding UTF8; $i = [array]::IndexOf($lines, ($lines | Where-Object { $_ -match "^\[社員名簿\]" } | Select-Object -First 1))
$roster = if ($i -ge 0) { $lines[($i + 1)..($lines.Count - 1)] } else { @() }
$RosterF = Join-Path $Desk "社員名簿.txt"; $KitRoster = Join-Path $Kit "AIオフィス\社員名簿.txt"   # 自分で直した名簿は残す。初回や初期値のままなら設定シートから作る
if (-not (Test-Path $RosterF) -or ((Get-FileHash $RosterF).Hash -eq (Get-FileHash $KitRoster).Hash)) { [IO.File]::WriteAllText($RosterF, (($roster -join "`r`n") + "`r`n"), $Utf8NoBom) }
$MF = Join-Path $Desk "モデル設定.txt"   # 初回だけ設定シートから作る。2回目以降はこのファイルが正（スマホからの切替や自分で足した行を消さない）
if (-not (Test-Path $MF)) { [IO.File]::WriteAllText($MF, ("# model=auto は公開ページの推奨モデルに自動で追随（opus / sonnet などと書けば固定）。permission=auto は確認を減らす auto mode（毎回確認は manual）`r`nmodel=" + $Model + "`r`neffort=" + $Effort + "`r`npermission=auto`r`n"), $Utf8NoBom) }
Ok ("スキル・デスクトップの AIオフィス・社員名簿（" + @($roster | Where-Object { $_ -match "\|" }).Count + " 人）")

Step "2/8 Python と Git"
if (-not (HasPython)) { Write-Host "Python を入れます（1〜3分）"; Winget "Python.Python.3.12" }
if (-not (HasPython)) { Fail "Python が入りませんでした。パソコンを再起動してから、もう一度同じ1行" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Write-Host "Git を入れます（1〜3分・「このアプリがデバイスに変更を加えることを許可しますか」と出たら「はい」）"; Winget "Git.Git" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Fail "Git が入りませんでした。パソコンを再起動してから、もう一度同じ1行" }
Ok ((& python --version) + "・" + ((& git --version) -replace "git version ", "git "))

Step "3/8 Claude Code（CLI 版）"
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) {
  Write-Host "Claude Code を入れます（公式のインストーラ・1〜2分）"
  try { Invoke-RestMethod https://claude.ai/install.ps1 | Invoke-Expression | Out-Null } catch { Warn ("インストーラの表示: " + $_) }
  RefreshPath
}
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) { Fail "Claude Code が入りませんでした" }
Ok ((& claude --version 2>$null) -join " ")

Step "4/8 Claude にログイン"
if (-not $Test) {
  if (-not ((& claude auth status 2>$null) -join "" -match '"loggedIn":\s*true')) {
    Write-Host "ブラウザが開きます。いつもの Claude のアカウントでログイン →「承認」してください"
    & claude auth login
    if (-not ((& claude auth status 2>$null) -join "" -match '"loggedIn":\s*true')) { Fail "ログインが確認できませんでした" }
  }
}
Ok "ログイン済み"

Step "5/8 Bun と Discord 連携（プラグイン）"
if (-not (Get-Command bun -ErrorAction SilentlyContinue)) {
  try { Invoke-RestMethod https://bun.sh/install.ps1 | Invoke-Expression | Out-Null } catch { Warn ("Bun の表示: " + $_) }
  RefreshPath
}
if (-not (Get-Command bun -ErrorAction SilentlyContinue)) { Fail "Bun が入りませんでした" }
if (-not ((& claude plugin marketplace list 2>$null) -join "`n" -match "claude-plugins-official")) { & claude plugin marketplace add anthropics/claude-plugins-official 2>&1 | Out-Null }
& claude plugin install discord@claude-plugins-official 2>&1 | Out-Null
if (-not ((& claude plugin list 2>$null) -join "`n" -match "discord@claude-plugins-official")) { Fail "Discord プラグインが入りませんでした" }
# Discord 連携（プラグイン）の部品がそろっているか確かめ、足りなければ入れ直す（途中で止まった install で空フォルダが残ると bot がオフラインのままになる）
function Heal-Plugin {
  $base = Join-Path $env:USERPROFILE ".claude\plugins\cache\claude-plugins-official\discord"
  $pd = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1
  if (-not $pd) { return "none" }
  $nm = Join-Path $pd.FullName "node_modules"
  $bad = { if (-not (Test-Path $nm)) { return 1 }
    $dirs = @(Get-ChildItem $nm -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne ".bin" -and $_.Name -ne ".cache" })
    $pk = @(); foreach ($d in $dirs) { if ($d.Name.StartsWith("@")) { $pk += @(Get-ChildItem $d.FullName -Directory -ErrorAction SilentlyContinue) } else { $pk += $d } }
    if ($pk.Count -lt 5) { return 1 }
    @($pk | Where-Object { -not (Test-Path (Join-Path $_.FullName "package.json")) }).Count }   # 中身の無い部品フォルダの数
  if ((& $bad) -eq 0) { return "ok" }
  for ($t = 1; $t -le 2; $t++) {
    Remove-Item -Recurse -Force $nm -ErrorAction SilentlyContinue
    cmd /c ("cd /d `"" + $pd.FullName + "`" && bun install --no-summary >nul 2>&1")
    if ((& $bad) -eq 0) { return "fixed" }
  }
  return "broken"
}
$h = Heal-Plugin
if ($h -eq "broken") { Fail "Discord 連携の部品を入れられませんでした（ネットにつながっているか確認して、もう一度同じ1行）" }
Ok ("Bun " + (& bun --version) + "・Discord プラグイン")

Step "6/8 bot を作って招待（ここだけ Claude アプリの画面操作）"
New-Item -ItemType Directory -Force $CH | Out-Null
$EnvF = Join-Path $CH ".env"
$Py = Join-Path $SK "scripts\office.py"   # 10/1: 生存確認より前に定義（未定義のまま token get を呼び、空トークンで 401 → 生きているトークンを失効扱いにしていた）
$TokD = Join-Path $Home_ ".claude\ai-office\token.dpapi"
$haveToken = ((Test-Path $EnvF) -and (Select-String -Path $EnvF -Pattern "DISCORD_BOT_TOKEN=\S" -Quiet)) -or (Test-Path $TokD)   # .env か暗号化保存庫（B5①）
if ($haveToken -and -not $Test) {   # 保存済みのトークンが死んでいたら（bot を消して作り直した等）作り直す。ネットの不調では消さない
  $old = ((& python $Py token get 2>$null) -join "").Trim()
  if (-not $old) { Write-Host "  （保存済みトークンを読めなかったので生存確認は飛ばします）"; $old = $null }
  if ($old) { try { Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me" -Headers @{ Authorization = "Bot $old"; "User-Agent" = "DiscordBot (ai-office, 1.0)" } -TimeoutSec 15 | Out-Null }
  catch { if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) { Warn "保存されていたトークンが使えなくなっていたので、bot の準備からやり直します"; if (Test-Path $EnvF) { Move-Item -Force $EnvF ($EnvF + ".old") }; if (Test-Path $TokD) { Remove-Item -Force $TokD }; $haveToken = $false } } }
  $old = $null
}
if (-not $haveToken) {
  # Claude に貼る指示文（Mac 用の言い方を Windows 用に直す）→ コピー。上書きされた時用に「指示文をもう一度コピー」も置く
  $ins = [IO.File]::ReadAllText((Join-Path $SK "browser\computer_use_setup.txt"), [Text.Encoding]::UTF8)
  $ins = $ins.Replace("{SERVER}", $Server).Replace("{BOT}", $Bot).Replace("⌘C", "Ctrl+C").Replace("⌘V", "Ctrl+V").Replace("⌘T", "Ctrl+T").Replace("「ターミナル」アプリの「AIオフィス セットアップ」", "「AIオフィス セットアップ」という題の PowerShell").Replace("ターミナル", "PowerShell の窓")
  $InsF = Join-Path $Home_ ".claude\ai-office\computer_use_setup_win.txt"; New-Item -ItemType Directory -Force (Split-Path $InsF) | Out-Null
  [IO.File]::WriteAllText($InsF, $ins, $Utf8NoBom)
  Set-Clipboard -Value $ins
  $re = Join-Path $Desk "指示文をもう一度コピー.bat"
  [IO.File]::WriteAllText($re, ("@echo off`r`nchcp 65001 >nul`r`npowershell -NoProfile -Command `"Set-Clipboard -Value ([IO.File]::ReadAllText('" + $InsF + "', [Text.Encoding]::UTF8))`"`r`necho 指示文をコピーしました。Claude アプリの新しいチャットに Ctrl+V → 送信`r`npause`r`n"), (New-Object System.Text.UTF8Encoding($false)))
  Write-Host ""
  Write-Host "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓" -ForegroundColor Yellow
  Write-Host "┃  ⚠ この窓には、何も貼らなくて大丈夫です                            ┃" -ForegroundColor Yellow
  Write-Host "┃                                                                ┃" -ForegroundColor Yellow
  Write-Host "┃  ① パソコン版の「Claude」アプリを開いて「新しいチャット」         ┃" -ForegroundColor Yellow
  Write-Host "┃  ② そこに Ctrl+V（指示文はもうコピーしてあります）→ 送信          ┃" -ForegroundColor Yellow
  Write-Host "┃  ③ Claude が Discord の準備をします（認証ボタンだけ自分で押す）    ┃" -ForegroundColor Yellow
  Write-Host "┃  ④ 最後に、画面に出たトークン（長い英数字）を自分でコピーする      ┃" -ForegroundColor Yellow
  Write-Host "┃     マウスでドラッグ、または3回クリックで選んで Ctrl+C             ┃" -ForegroundColor Yellow
  Write-Host "┃     （「コピー」ボタンは効かないことが多い）この窓が自動で読み取る   ┃" -ForegroundColor Yellow
  Write-Host "┃  ※ この窓・Claude アプリ・Chrome のタブは、完成まで閉じない         ┃" -ForegroundColor Yellow
  Write-Host "┃  ※ 作業中はスマホでコピーしない（パソコンのコピーが上書きされる）   ┃" -ForegroundColor Yellow
  Write-Host "┃     上書きされたら デスクトップ AIオフィス の「指示文をもう一度コピー」    ┃" -ForegroundColor Yellow
  Write-Host "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛" -ForegroundColor Yellow
  Write-Host ("（サーバー名「" + $Server + "」・bot「" + $Bot + "」）")
  if (-not $Test) { Start-Sleep 2; try { Start-Process "claude://" -ErrorAction Stop } catch {} }
  $tokRe = '^[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{20,}$'
  $H = @{ "User-Agent" = "DiscordBot (ai-office, 1.0)" }
  function TokOk($t) { if ($Test) { return $true }; try { Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me" -Headers ($H + @{ Authorization = "Bot $t" }) -TimeoutSec 15 | Out-Null; return $true } catch { return $false } }
  Write-Host "トークンを待っています…（コピーすれば自動で読み取ります）"
  $Token = ""; $last = ""
  try { $last = ((Get-Clipboard -Raw) -replace '\s', '') } catch {}
  if (($last -match $tokRe) -and (TokOk $last)) { $last = "" }   # 前回の有効なトークンが残っていれば使う
  while (-not $Token) {
    Drain
    $cb = ""; try { $cb = ((Get-Clipboard -Raw) -replace '\s', '') } catch {}
    if ($cb -ne $last) {
      $last = $cb
      if ($cb -match $tokRe) {
        if (TokOk $cb) { $Token = $cb; Set-Clipboard -Value " "; Write-Host "（コピーされたトークンを読み取りました）"; break }
        Warn "コピーされたトークンでは Discord につながりませんでした。Bot の「Reset Token」でもう一度出してコピーしてください"
      }
    }
    Start-Sleep 1
  }
  Ok "トークンを確認しました"
  # ユーザーID は聞かない: bot が入ったサーバーの「持ち主」を Discord から読む
  $Owner = ""
  for ($n = 1; $n -le 45 -and -not $Owner; $n++) {
    if ($Test) { $Owner = "123456789012345678"; break }
    try {
      $A = $H + @{ Authorization = "Bot $Token" }
      $gs = @(Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me/guilds" -Headers $A -TimeoutSec 15)
      $g0 = $gs | Where-Object { $_.name -eq $Server } | Select-Object -First 1   # 設定シートのサーバー名で照合（bot が別のサーバーにも入っていると違う人が持ち主になる・監査 小）
      if (-not $g0 -and $gs.Count -eq 1) { $g0 = $gs[0] }
      if ($g0) { $Owner = (Invoke-RestMethod -Uri ("https://discord.com/api/v10/guilds/" + $g0.id) -Headers $A -TimeoutSec 15).owner_id }
      elseif ($gs.Count -gt 1) { Write-Host ("  bot は " + $gs.Count + " 個のサーバーに入っていますが、設定シートの「" + $Server + "」が見つかりません。サーバー名を設定シートと同じにしてください") }
    } catch {}
    if (-not $Owner) { if ($n % 3 -eq 1) { Write-Host "  bot のサーバー参加を待っています…（招待の「認証」まで進めてください）" }; Start-Sleep 20 }
  }
  if (-not $Owner) { Fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）" }
  Ok ("サーバーの持ち主を確認しました（あなたのID: " + $Owner + "）")
  [IO.File]::WriteAllText($EnvF, ("DISCORD_BOT_TOKEN=" + $Token + "`n"), $Utf8NoBom); $Token = $null
  try { & icacls $EnvF /inheritance:r /grant:r ("$env:USERNAME" + ":F") | Out-Null } catch {}   # 自分だけが読める（Mac の chmod 600 相当・監査 小）
  $AccF = Join-Path $CH "access.json"
  $acc = [ordered]@{ dmPolicy = "allowlist"; allowFrom = @(); groups = @{}; pending = @{} }
  if (Test-Path $AccF) { try { $old = Get-Content $AccF -Raw -Encoding UTF8 | ConvertFrom-Json; foreach ($p in $old.PSObject.Properties) { $acc[$p.Name] = $p.Value } } catch {} }
  $acc["dmPolicy"] = "allowlist"; $af = @($acc["allowFrom"]); if ($af -notcontains $Owner) { $af += $Owner }; $acc["allowFrom"] = $af
  [IO.File]::WriteAllText($AccF, ($acc | ConvertTo-Json -Depth 8), $Utf8NoBom)
  Ok "トークンと許可を保存しました"
} else { Ok "bot トークンは設定済み" }
$Py = Join-Path $SK "scripts\office.py"
$who = (& python $Py whoami 2>&1 | Select-Object -First 1)
if (-not ("$who" -match "^bot:")) { Fail ("トークンで Discord につながりませんでした（" + $who + "）") }
Ok $who

Step "7/8 部屋と社員を作る"
& python $Py snippet-install 2>&1 | Where-Object { $_ -notmatch "^SNIPPET=" } | ForEach-Object { Write-Host ("  " + $_) }
if (Test-Path (Join-Path $Home_ ".claude\ai-office\local")) { Write-Host "  ✓ 持ち主の置き場（更新で触らない）:"; & python $Py local status 2>&1 | Where-Object { $_ -notmatch "^LOCAL=" } | ForEach-Object { Write-Host ("  " + $_) } }
& python $Py guard rehash 2>&1 | Where-Object { $_ -notmatch "^GUARD_VERIFY=" } | ForEach-Object { Write-Host ("  " + $_) }
& python $Py version --announce 2>&1 | Where-Object { $_ -match "^AIオフィス " } | ForEach-Object { Write-Host ("  ✓ 版: " + $_) }   # 更新が入っていればお知らせの部屋に ⬆️（Q34）
if ($env:AIOFFICE_TOKEN_PROTECT -eq "1") { & python $Py token protect 2>&1 | Where-Object { $_ -notmatch "^TOKEN_STORE=" } | ForEach-Object { Write-Host ("  " + $_) } }   # [B5①] トークンを DPAPI の保存庫へ（.env から消す）。実機で env 渡しの接続を確かめるまでは手動（office.py token protect）・自動化は次の版   # 更新で本体が変わったので、見張りの合図を取り直す（ON のときだけ意味がある）   # CLAUDE.md の作法ブロックを今の版に（更新でも新しい決まりが届く）
for ($n = 1; $n -le 30; $n++) {
  if (((& python $Py whoami 2>$null) -join "`n") -match "(?m)^guild:") { break }
  if ($n % 3 -eq 1) { Write-Host "  bot のサーバー参加を待っています…（Claude アプリで招待の「認証」まで進めてください）" }; Start-Sleep 20
}
if (-not (((& python $Py whoami 2>$null) -join "`n") -match "(?m)^guild:")) { Fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）" }
$HireArgs = @("--file", (Join-Path $Desk "社員名簿.txt")); if ($Notice -eq "なし") { $HireArgs += "--no-notice-room" }
$out = (& python $Py hire-all @HireArgs 2>&1) -join "`n"
if ($out -match "HTTP 403") { Write-Host $out; Fail "bot の権限が足りません。招待の URL を開いて「認証」してから、もう一度同じ1行" }
if (-not ($out -match "(?m)^NEW=")) { Write-Host $out; Fail "部屋を作れませんでした" }
$newN = 0; if ($out -match "(?m)^NEW=(\d+)") { $newN = [int]$Matches[1] }
if (-not $Bk -or $newN -gt 0) {   # リンク一覧を統括に送るのは、最初に入れたときと部屋が増えたときだけ（更新のたびに10通流れていた・開発くんの試し B）
  & python $Py links --out $Desk --post hq *> $null
  if ($LASTEXITCODE -ne 0) { Fail "リンク一覧を送れませんでした" }
  Ok ("部屋 " + @($roster | Where-Object { $_ -match "\|" }).Count + " つ・統括の部屋に部屋ごとのリンクを送りました")
} else { & python $Py links --out $Desk *> $null; Ok ("部屋 " + @($roster | Where-Object { $_ -match "\|" }).Count + " つ（増えた部屋なし・リンク一覧はデスクトップの links.html）") }
if ($Bk) {   # 何が変わったか。Discord につながるのを確かめてから送る（v1.6 は手順7の頭で送って届かなかった）
  $rp = @(& python $Py update-report --bk $Bk --zip $Bz --out $Desk --post 2>&1)
  $rp | Where-Object { $_ -match "^REPORT=" } | ForEach-Object { Write-Host ("  ✓ 更新の報告: " + ($_ -replace "^REPORT=", "")) }
  if ($rp -match "^REPORT_POST=failed") { Warn "統括に ⚠️ を送れませんでした。デスクトップの AIオフィス\更新の報告.txt を読んでください" }
}
if ($UsageNick -eq "なし") { & python $Py usage --nick off 2>&1 | Select-Object -Last 1 | ForEach-Object { Write-Host ("  " + $_) } }   # C4 2026-09-30

Step "8/8 毎朝の再起動を入れて、起動"
$reg = (& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $SK "scripts\register_task.ps1") -Time $RT -Office $Desk 2>&1) -join "`n"
if (-not ($reg -match "登録しました")) { Write-Host $reg; Fail "毎朝の再起動を登録できませんでした" }
Ok ("登録しました: 毎日 " + $RT + " に 再起動")
$old = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" }
if ($old) {   # 更新: 古い Claude を止めてから起動（止めないと新しい版が効かない・v1.6.1）。Claude の中から実行したときは止めない
  if ($env:CLAUDECODE) { Warn "Claude の中から実行しているので止めません。あとでデスクトップの AIオフィス の「再起動」で新しい版になります" }
  else { Write-Host "  動いている Claude を止めて、新しい版で起動し直します"; $old | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep 5 }
}
$sl = Join-Path $Logs "setup_start.log"; $se = Join-Path $Logs "setup_start_err.log"
$sp = Start-Process powershell.exe -ArgumentList "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ("`"" + (Join-Path $SK "scripts\start.ps1") + "`""), "-Office", ("`"" + $Desk + "`"") -RedirectStandardOutput $sl -RedirectStandardError $se -WindowStyle Hidden -PassThru
$sp.WaitForExit()
if (-not (Select-String -Path $sl -Pattern "Claude Code を起動しました|すでに動いています" -Quiet)) { Get-Content $sl -Tail 5; Get-Content $se -Tail 5 -ErrorAction SilentlyContinue; Fail "Claude を起動できませんでした" }
$alive = $true
for ($n = 1; $n -le 15; $n++) { Start-Sleep 2; if (-not (Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" })) { $alive = $false } }
if (-not $alive -and -not $Test) { Fail "Claude が起動してすぐ止まりました（新しく開いた青い窓の赤い文字をスクショしてください）" }
Ok "Claude を起動しました（新しい窓・30秒動作を確認）"
# 本当に Discord とつながったか: 起動後に bot 自身が統括へ投稿したかを見る（来なければ1回だけ起動し直す）
function BotPosted($since) {
  try {
    $tok = (& python $Py token get 2>$null)
    $cfgj = Get-Content (Join-Path $Home_ ".claude\ai-office\config.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $hq = $cfgj.hq_room
    if (-not $hq) { $st = Get-Content (Join-Path $Home_ ".claude\ai-office\staff.json") -Raw -Encoding UTF8 | ConvertFrom-Json; $hq = ($st.staff | Where-Object { $_.name -eq "統括" } | Select-Object -First 1).room_id }
    $A = @{ Authorization = "Bot $tok"; "User-Agent" = "DiscordBot (ai-office, 1.0)" }
    $me = (Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me" -Headers $A -TimeoutSec 15).id
    $msgs = Invoke-RestMethod -Uri ("https://discord.com/api/v10/channels/" + $hq + "/messages?limit=10") -Headers $A -TimeoutSec 15
    foreach ($m in $msgs) { if ($m.author.id -eq $me -and ([datetime]$m.timestamp).ToUniversalTime() -gt $since -and ($m.content -match "Congratulations|起動しました")) { return $true } }
  } catch {}
  return $false
}
if (-not $Test) {
  Write-Host "  Claude が Discord とつながるのを待っています（最長2分半）…"
  $since = (Get-Date).ToUniversalTime().AddMinutes(-2); $ok = $false
  for ($n = 1; $n -le 30 -and -not $ok; $n++) { Start-Sleep 5; $ok = BotPosted $since }
  if (-not $ok) {
    Warn "Discord とのつながりが遅いので、Claude を1回だけ起動し直します"
    Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep 5
    $since = (Get-Date).ToUniversalTime()
    $sp2 = Start-Process powershell.exe -ArgumentList "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ("`"" + (Join-Path $SK "scripts\start.ps1") + "`""), "-Office", ("`"" + $Desk + "`"") -RedirectStandardOutput (Join-Path $Logs "setup_start2.log") -RedirectStandardError (Join-Path $Logs "setup_start2_err.log") -WindowStyle Hidden -PassThru
    $sp2.WaitForExit()
    for ($n = 1; $n -le 30 -and -not $ok; $n++) { Start-Sleep 5; $ok = BotPosted $since }
  }
  if ($ok) { Ok "Claude が Discord につながりました（統括の部屋に投稿を確認）" }
  else { Warn "Claude が統括の部屋に投稿していません。Claude の窓を閉じて、デスクトップの AIオフィス の「起動」をダブルクリックしてください" }
}

Step "健康診断"
$dr = @(& python $Py doctor --net 2>&1); $dr | Where-Object { $_ -notmatch "^DOCTOR=" } | ForEach-Object { Write-Host $_ }
if (-not ($dr -match "^DOCTOR=ok")) {
  if ($Bz -and -not $Test) {   # 更新の後に問題があれば、更新の直前に戻すかを聞く（勝手には戻さない）
    $ans = ""; try { $ans = (Read-Host "更新の直前に戻しますか？ 戻すなら「はい」と打って Enter（このまま使うならそのまま Enter）").Trim() } catch {}
    if (@("はい", "hai", "y", "Y", "yes") -contains $ans) { & python $Py restore $Bz --yes; Read-Host "Enter で閉じる" | Out-Null; exit 0 }
    Write-Host "  このまま進めます。あとで戻すときはデスクトップの AIオフィス の「戻す」→「更新の直前」"
  } else { Write-Host "  ✗ の行をスクショして送ってください。入れる前に戻すときはデスクトップの AIオフィス の「やめる」" }
}

$tRoom = ((& python $Py test-room --file (Join-Path $Desk "社員名簿.txt") 2>$null) | Select-Object -Last 1); if (-not $tRoom) { $tRoom = "統括" }   # 名簿の2人目（統括の次）の部屋
$nCand = 0   # 引き継ぎ診断（読むだけ・失敗しても先へ）
try { $env:PYTHONUTF8 = "1"; $mo = (& python $Py migrate --out $Desk 2>$null) -join "`n"; if ($mo -match "CANDIDATES=(\d+)") { $nCand = [int]$Matches[1] } } catch { $nCand = 0 }

Write-Host ""
Write-Host "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊" -ForegroundColor Yellow
Write-Host ""
Write-Host "      🎉  Congratulations!  セットアップ完了です  🎉" -ForegroundColor Green
Write-Host ""
Write-Host "  AIオフィスが完成しました。このまま使えます。"
Write-Host ""
Write-Host "  ▶ 次にあなたがすること"
Write-Host ("    スマホの Discord で「" + $tRoom + "」の部屋に「テスト」と送ってみてください。")
Write-Host "    返事が来たら、もう社員が働いています 🙌"
Write-Host ""
Write-Host "  ・🔐 最後に1つだけ（大事）: Discord の 設定 → マイアカウント → 「2段階認証を有効にする」。乗っ取られると他人が AI 社員に指示できてしまいます。バックアップコードは紙かパスワード管理に" -ForegroundColor Yellow
Write-Host "  ・この窓は閉じて大丈夫です（Claude は別の窓で動いています）"
Write-Host "  ・Claude が動いている窓は閉じないでください"
Write-Host "  ・パソコンは電源につないで、スリープしない設定にしておいてください"
if ($nCand -gt 0) {
  Write-Host ""
  Write-Host ("  📦 デスクトップアプリで開発していたプロジェクトが " + $nCand + " 個見つかりました") -ForegroundColor Cyan
  Write-Host "     （デスクトップの AIオフィス フォルダの「引き継ぎ診断.txt」）"
  Write-Host "     統括の部屋に「引き継いで」と送ると、そのまま Discord の開発部屋にできます"
}
Write-Host ""
Write-Host "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊" -ForegroundColor Yellow
Read-Host "Enter で閉じる" | Out-Null
