﻿# setup_windows.ps1 — AIオフィス まとめてセットアップ（Windows）。install.ps1（PowerShell に1行）から呼ばれる
#   powershell -NoProfile -ExecutionPolicy Bypass -File setup_windows.ps1 -Kit <キットのフォルダ>
#   途中で止まっても、もう一度同じ1行で頭から通せる（入っているものは飛ばす）
param([Parameter(Mandatory=$true)][string]$Kit)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Continue"
$Host.UI.RawUI.WindowTitle = "AIオフィス セットアップ"
$Test  = [bool]$env:AIO_TEST                                   # 作り手の動作確認用（ログイン・画面操作・本物のトークン確認を飛ばす）
$Home_ = $env:USERPROFILE
$Sheet = Join-Path $Kit "設定シート.txt"
$SK    = Join-Path $Home_ ".claude\skills\discord-ai-office"
$Desk0 = [Environment]::GetFolderPath("Desktop"); if ($Test -or -not $Desk0) { $Desk0 = Join-Path $Home_ "Desktop" }   # OneDrive のデスクトップにも対応
$Desk  = Join-Path $Desk0 "AIオフィス"
$CH    = Join-Path $Home_ ".claude\channels\discord"
$Logs  = Join-Path $Desk "logs"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$env:PYTHONUTF8 = "1"

function Step($t) { Write-Host ""; Write-Host ("━━ " + $t + " ━━") -ForegroundColor Cyan }
function Ok($t)   { Write-Host ("✓ " + $t) -ForegroundColor Green }
function Warn($t) { Write-Host ("⚠ " + $t) -ForegroundColor Yellow }
function Fail($t) { Write-Host ""; Write-Host ("✗ " + $t) -ForegroundColor Red; Write-Host "（この画面のスクショを送ってください）"; Read-Host "Enter で閉じる" | Out-Null; exit 1 }
function Drain()  { try { while ([Console]::KeyAvailable) { [void][Console]::ReadKey($true) } } catch {} }   # 間違って貼られた文字を捨てる（あとでコマンドとして動かないように）
function RefreshPath() {
  $m = [Environment]::GetEnvironmentVariable("Path", "Machine"); $u = [Environment]::GetEnvironmentVariable("Path", "User")
  $extra = @((Join-Path $Home_ ".local\bin"), (Join-Path $Home_ ".bun\bin"))
  $env:Path = (@($extra) + @($m, $u) | Where-Object { $_ }) -join ";"
}
function Val($key) {
  foreach ($l in (Get-Content $Sheet -Encoding UTF8)) { if ($l -match ("^\s*" + [regex]::Escape($key) + "\s*=\s*(.*?)\s*$")) { return $Matches[1] } }
  return ""
}
function HasPython() { try { $o = & python -c "print(12345)" 2>$null; return ($o -eq "12345") } catch { return $false } }   # Microsoft Store の偽 python を除く
function Winget($id) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Fail "winget（アプリのインストーラ）がありません。Microsoft Store で「アプリ インストーラー」を入れてから、もう一度同じ1行" }
  winget install --id $id -e --silent --accept-source-agreements --accept-package-agreements | Out-Host
  RefreshPath
}

$Server = Val "サーバー名"; if (-not $Server) { $Server = "AIオフィス" }
$Bot    = Val "bot名";      if (-not $Bot)    { $Bot = "AI社員" }
$RT     = Val "再起動の時刻"; if (-not $RT)    { $RT = "04:00" }
$Model  = Val "モデル"; if (-not $Model) { $Model = "opus" }
$Effort = Val "考える深さ"; if (-not $Effort) { $Effort = "high" }
RefreshPath

Step "1/8 ファイルを置く"
New-Item -ItemType Directory -Force (Join-Path $Home_ ".claude\skills") | Out-Null
if (Test-Path $SK) { Remove-Item -Recurse -Force $SK }
Copy-Item -Recurse (Join-Path $Kit "skill\discord-ai-office") $SK
if (-not (Test-Path $Desk)) { Copy-Item -Recurse (Join-Path $Kit "AIオフィス") $Desk }
foreach ($b in @("起動.bat", "再起動.bat")) { Copy-Item -Force (Join-Path $Kit ("AIオフィス\" + $b)) (Join-Path $Desk $b) }
Get-ChildItem $Desk -Filter *.command -ErrorAction SilentlyContinue | Remove-Item -Force   # Windows では Mac 用は置かない
New-Item -ItemType Directory -Force $Logs | Out-Null
$lines = Get-Content $Sheet -Encoding UTF8; $i = [array]::IndexOf($lines, ($lines | Where-Object { $_ -match "^\[社員名簿\]" } | Select-Object -First 1))
$roster = if ($i -ge 0) { $lines[($i + 1)..($lines.Count - 1)] } else { @() }
[IO.File]::WriteAllText((Join-Path $Desk "社員名簿.txt"), (($roster -join "`r`n") + "`r`n"), $Utf8NoBom)
[IO.File]::WriteAllText((Join-Path $Desk "モデル設定.txt"), ("model=" + $Model + "`r`neffort=" + $Effort + "`r`n"), $Utf8NoBom)
Ok ("スキル・机の上の AIオフィス・社員名簿（" + @($roster | Where-Object { $_ -match "\|" }).Count + " 人）")

Step "2/8 Python と Git"
if (-not (HasPython)) { Write-Host "Python を入れます（1〜3分）"; Winget "Python.Python.3.12" }
if (-not (HasPython)) { Fail "Python が入りませんでした。パソコンを再起動してから、もう一度同じ1行" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Write-Host "Git を入れます（1〜3分・「このアプリがデバイスに変更を加えることを許可しますか」と出たら「はい」）"; Winget "Git.Git" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Fail "Git が入りませんでした。パソコンを再起動してから、もう一度同じ1行" }
Ok ((& python --version) + "・" + ((& git --version) -replace "git version ", "git "))

Step "3/8 Claude Code（CLI 版）"
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) {
  Write-Host "Claude Code を入れます（公式のインストーラ・1〜2分）"
  try { Invoke-RestMethod https://claude.ai/install.ps1 | Invoke-Expression | Out-Null } catch { Warn ("インストーラの表示: " + $_) }
  RefreshPath
}
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) { Fail "Claude Code が入りませんでした" }
Ok ((& claude --version 2>$null) -join " ")

Step "4/8 Claude にログイン"
if (-not $Test) {
  if (-not ((& claude auth status 2>$null) -join "" -match '"loggedIn":\s*true')) {
    Write-Host "ブラウザが開きます。いつもの Claude のアカウントでログイン →「承認」してください"
    & claude auth login
    if (-not ((& claude auth status 2>$null) -join "" -match '"loggedIn":\s*true')) { Fail "ログインが確認できませんでした" }
  }
}
Ok "ログイン済み"

Step "5/8 Bun と Discord 連携（プラグイン）"
if (-not (Get-Command bun -ErrorAction SilentlyContinue)) {
  try { Invoke-RestMethod https://bun.sh/install.ps1 | Invoke-Expression | Out-Null } catch { Warn ("Bun の表示: " + $_) }
  RefreshPath
}
if (-not (Get-Command bun -ErrorAction SilentlyContinue)) { Fail "Bun が入りませんでした" }
if (-not ((& claude plugin marketplace list 2>$null) -join "`n" -match "claude-plugins-official")) { & claude plugin marketplace add anthropics/claude-plugins-official 2>&1 | Out-Null }
& claude plugin install discord@claude-plugins-official 2>&1 | Out-Null
if (-not ((& claude plugin list 2>$null) -join "`n" -match "discord@claude-plugins-official")) { Fail "Discord プラグインが入りませんでした" }
# Discord 連携（プラグイン）の部品がそろっているか確かめ、足りなければ入れ直す（途中で止まった install で空フォルダが残ると bot がオフラインのままになる）
function Heal-Plugin {
  $base = Join-Path $env:USERPROFILE ".claude\plugins\cache\claude-plugins-official\discord"
  $pd = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1
  if (-not $pd) { return "none" }
  $nm = Join-Path $pd.FullName "node_modules"
  $bad = { if (-not (Test-Path $nm)) { return 1 }
    $dirs = @(Get-ChildItem $nm -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne ".bin" -and $_.Name -ne ".cache" })
    $pk = @(); foreach ($d in $dirs) { if ($d.Name.StartsWith("@")) { $pk += @(Get-ChildItem $d.FullName -Directory -ErrorAction SilentlyContinue) } else { $pk += $d } }
    if ($pk.Count -lt 5) { return 1 }
    @($pk | Where-Object { -not (Test-Path (Join-Path $_.FullName "package.json")) }).Count }   # 中身の無い部品フォルダの数
  if ((& $bad) -eq 0) { return "ok" }
  for ($t = 1; $t -le 2; $t++) {
    Remove-Item -Recurse -Force $nm -ErrorAction SilentlyContinue
    cmd /c ("cd /d `"" + $pd.FullName + "`" && bun install --no-summary >nul 2>&1")
    if ((& $bad) -eq 0) { return "fixed" }
  }
  return "broken"
}
$h = Heal-Plugin
if ($h -eq "broken") { Fail "Discord 連携の部品を入れられませんでした（ネットにつながっているか確認して、もう一度同じ1行）" }
Ok ("Bun " + (& bun --version) + "・Discord プラグイン")

Step "6/8 bot を作って招待（ここだけ Claude アプリの画面操作）"
New-Item -ItemType Directory -Force $CH | Out-Null
$EnvF = Join-Path $CH ".env"
$haveToken = (Test-Path $EnvF) -and (Select-String -Path $EnvF -Pattern "DISCORD_BOT_TOKEN=\S" -Quiet)
if ($haveToken -and -not $Test) {   # 保存済みのトークンが死んでいたら（bot を消して作り直した等）作り直す。ネットの不調では消さない
  $old = ((Get-Content $EnvF -Raw) -replace '(?s).*DISCORD_BOT_TOKEN=(\S+).*', '$1')
  try { Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me" -Headers @{ Authorization = "Bot $old"; "User-Agent" = "DiscordBot (ai-office, 1.0)" } -TimeoutSec 15 | Out-Null }
  catch { if ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -eq 401) { Warn "保存されていたトークンが使えなくなっていたので、bot の準備からやり直します"; Move-Item -Force $EnvF ($EnvF + ".old"); $haveToken = $false } }
  $old = $null
}
if (-not $haveToken) {
  # Claude に貼る指示文（Mac 用の言い方を Windows 用に直す）→ コピー。上書きされた時用に「指示文をもう一度コピー」も置く
  $ins = [IO.File]::ReadAllText((Join-Path $SK "browser\computer_use_setup.txt"), [Text.Encoding]::UTF8)
  $ins = $ins.Replace("{SERVER}", $Server).Replace("{BOT}", $Bot).Replace("⌘C", "Ctrl+C").Replace("⌘V", "Ctrl+V").Replace("「ターミナル」アプリの「AIオフィス セットアップ」", "「AIオフィス セットアップ」という題の PowerShell").Replace("ターミナル", "PowerShell の窓")
  $InsF = Join-Path $Home_ ".claude\ai-office\computer_use_setup_win.txt"; New-Item -ItemType Directory -Force (Split-Path $InsF) | Out-Null
  [IO.File]::WriteAllText($InsF, $ins, $Utf8NoBom)
  Set-Clipboard -Value $ins
  $re = Join-Path $Desk "指示文をもう一度コピー.bat"
  [IO.File]::WriteAllText($re, ("@echo off`r`nchcp 65001 >nul`r`npowershell -NoProfile -Command `"Set-Clipboard -Value ([IO.File]::ReadAllText('" + $InsF + "', [Text.Encoding]::UTF8))`"`r`necho 指示文をコピーしました。Claude アプリの新しいチャットに Ctrl+V → 送信`r`npause`r`n"), (New-Object System.Text.UTF8Encoding($false)))
  Write-Host ""
  Write-Host "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓" -ForegroundColor Yellow
  Write-Host "┃  ⚠ この窓には、何も貼らなくて大丈夫です                            ┃" -ForegroundColor Yellow
  Write-Host "┃                                                                ┃" -ForegroundColor Yellow
  Write-Host "┃  ① パソコン版の「Claude」アプリを開いて「新しいチャット」         ┃" -ForegroundColor Yellow
  Write-Host "┃  ② そこに Ctrl+V（指示文はもうコピーしてあります）→ 送信          ┃" -ForegroundColor Yellow
  Write-Host "┃  ③ Claude が Discord の準備をします（認証ボタンだけ自分で押す）    ┃" -ForegroundColor Yellow
  Write-Host "┃  ④ 最後に、画面に出たトークン（長い英数字）を自分でコピーする      ┃" -ForegroundColor Yellow
  Write-Host "┃     マウスでドラッグ、または3回クリックで選んで Ctrl+C             ┃" -ForegroundColor Yellow
  Write-Host "┃     （「コピー」ボタンは効かないことが多い）この窓が自動で読み取る   ┃" -ForegroundColor Yellow
  Write-Host "┃  ※ この窓・Claude アプリ・Chrome のタブは、完成まで閉じない         ┃" -ForegroundColor Yellow
  Write-Host "┃  ※ 作業中はスマホでコピーしない（パソコンのコピーが上書きされる）   ┃" -ForegroundColor Yellow
  Write-Host "┃     上書きされたら 机の上 AIオフィス の「指示文をもう一度コピー」    ┃" -ForegroundColor Yellow
  Write-Host "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛" -ForegroundColor Yellow
  Write-Host ("（サーバー名「" + $Server + "」・bot「" + $Bot + "」）")
  if (-not $Test) { Start-Sleep 2; try { Start-Process "claude://" -ErrorAction Stop } catch {} }
  $tokRe = '^[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{20,}$'
  $H = @{ "User-Agent" = "DiscordBot (ai-office, 1.0)" }
  function TokOk($t) { if ($Test) { return $true }; try { Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me" -Headers ($H + @{ Authorization = "Bot $t" }) -TimeoutSec 15 | Out-Null; return $true } catch { return $false } }
  Write-Host "トークンを待っています…（コピーすれば自動で読み取ります）"
  $Token = ""; $last = ""
  try { $last = ((Get-Clipboard -Raw) -replace '\s', '') } catch {}
  if (($last -match $tokRe) -and (TokOk $last)) { $last = "" }   # 前回の有効なトークンが残っていれば使う
  while (-not $Token) {
    Drain
    $cb = ""; try { $cb = ((Get-Clipboard -Raw) -replace '\s', '') } catch {}
    if ($cb -ne $last) {
      $last = $cb
      if ($cb -match $tokRe) {
        if (TokOk $cb) { $Token = $cb; Set-Clipboard -Value " "; Write-Host "（コピーされたトークンを読み取りました）"; break }
        Warn "コピーされたトークンでは Discord につながりませんでした。Bot の「Reset Token」でもう一度出してコピーしてください"
      }
    }
    Start-Sleep 1
  }
  Ok "トークンを確認しました"
  # ユーザーID は聞かない: bot が入ったサーバーの「持ち主」を Discord から読む
  $Owner = ""
  for ($n = 1; $n -le 45 -and -not $Owner; $n++) {
    if ($Test) { $Owner = "123456789012345678"; break }
    try {
      $A = $H + @{ Authorization = "Bot $Token" }
      $gs = @(Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me/guilds" -Headers $A -TimeoutSec 15)
      if ($gs.Count -ge 1) { $Owner = (Invoke-RestMethod -Uri ("https://discord.com/api/v10/guilds/" + $gs[0].id) -Headers $A -TimeoutSec 15).owner_id }
    } catch {}
    if (-not $Owner) { if ($n % 3 -eq 1) { Write-Host "  bot のサーバー参加を待っています…（招待の「認証」まで進めてください）" }; Start-Sleep 20 }
  }
  if (-not $Owner) { Fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）" }
  Ok ("サーバーの持ち主を確認しました（あなたのID: " + $Owner + "）")
  [IO.File]::WriteAllText($EnvF, ("DISCORD_BOT_TOKEN=" + $Token + "`n"), $Utf8NoBom); $Token = $null
  $AccF = Join-Path $CH "access.json"
  $acc = [ordered]@{ dmPolicy = "allowlist"; allowFrom = @(); groups = @{}; pending = @{} }
  if (Test-Path $AccF) { try { $old = Get-Content $AccF -Raw -Encoding UTF8 | ConvertFrom-Json; foreach ($p in $old.PSObject.Properties) { $acc[$p.Name] = $p.Value } } catch {} }
  $acc["dmPolicy"] = "allowlist"; $af = @($acc["allowFrom"]); if ($af -notcontains $Owner) { $af += $Owner }; $acc["allowFrom"] = $af
  [IO.File]::WriteAllText($AccF, ($acc | ConvertTo-Json -Depth 8), $Utf8NoBom)
  Ok "トークンと許可を保存しました"
} else { Ok "bot トークンは設定済み" }
$Py = Join-Path $SK "scripts\office.py"
$who = (& python $Py whoami 2>&1 | Select-Object -First 1)
if (-not ("$who" -match "^bot:")) { Fail ("トークンで Discord につながりませんでした（" + $who + "）") }
Ok $who

Step "7/8 部屋と社員を作る"
$CM = Join-Path $Home_ ".claude\CLAUDE.md"
if (-not ((Test-Path $CM) -and (Select-String -Path $CM -Pattern "discord-ai-office スキル" -Quiet))) {
  Add-Content -Path $CM -Value ("`r`n" + [IO.File]::ReadAllText((Join-Path $SK "templates\CLAUDE_snippet.md"), [Text.Encoding]::UTF8)) -Encoding UTF8
}
for ($n = 1; $n -le 30; $n++) {
  if (((& python $Py whoami 2>$null) -join "`n") -match "(?m)^guild:") { break }
  if ($n % 3 -eq 1) { Write-Host "  bot のサーバー参加を待っています…（Claude アプリで招待の「認証」まで進めてください）" }; Start-Sleep 20
}
if (-not (((& python $Py whoami 2>$null) -join "`n") -match "(?m)^guild:")) { Fail "bot がサーバーに入っていません（招待の「認証」が終わっていない）" }
$out = (& python $Py hire-all --file (Join-Path $Desk "社員名簿.txt") 2>&1) -join "`n"
if ($out -match "HTTP 403") { Write-Host $out; Fail "bot の権限が足りません。招待の URL を開いて「認証」してから、もう一度同じ1行" }
if (-not ($out -match "(?m)^NEW=")) { Write-Host $out; Fail "部屋を作れませんでした" }
& python $Py links --out $Desk --post hq *> $null
if ($LASTEXITCODE -ne 0) { Fail "リンク一覧を送れませんでした" }
Ok ("部屋 " + @($roster | Where-Object { $_ -match "\|" }).Count + " つ・統括の部屋に部屋ごとのリンクを送りました")

Step "8/8 毎朝の再起動を入れて、起動"
$reg = (& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $SK "scripts\register_task.ps1") -Time $RT -Office $Desk 2>&1) -join "`n"
if (-not ($reg -match "登録しました")) { Write-Host $reg; Fail "毎朝の再起動を登録できませんでした" }
Ok ("登録しました: 毎日 " + $RT + " に 再起動")
$sl = Join-Path $Logs "setup_start.log"; $se = Join-Path $Logs "setup_start_err.log"
$sp = Start-Process powershell.exe -ArgumentList "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ("`"" + (Join-Path $SK "scripts\start.ps1") + "`""), "-Office", ("`"" + $Desk + "`"") -RedirectStandardOutput $sl -RedirectStandardError $se -WindowStyle Hidden -PassThru
$sp.WaitForExit()
if (-not (Select-String -Path $sl -Pattern "Claude Code を起動しました|すでに動いています" -Quiet)) { Get-Content $sl -Tail 5; Get-Content $se -Tail 5 -ErrorAction SilentlyContinue; Fail "Claude を起動できませんでした" }
$alive = $true
for ($n = 1; $n -le 15; $n++) { Start-Sleep 2; if (-not (Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" })) { $alive = $false } }
if (-not $alive -and -not $Test) { Fail "Claude が起動してすぐ止まりました（新しく開いた青い窓の赤い文字をスクショしてください）" }
Ok "Claude を起動しました（新しい窓・30秒動作を確認）"
# 本当に Discord とつながったか: 起動後に bot 自身が統括へ投稿したかを見る（来なければ1回だけ起動し直す）
function BotPosted($since) {
  try {
    $tok = ((Get-Content (Join-Path $CH ".env") -Raw) -replace '(?s).*DISCORD_BOT_TOKEN=(\S+).*', '$1')
    $cfgj = Get-Content (Join-Path $Home_ ".claude\ai-office\config.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $hq = $cfgj.hq_room
    if (-not $hq) { $st = Get-Content (Join-Path $Home_ ".claude\ai-office\staff.json") -Raw -Encoding UTF8 | ConvertFrom-Json; $hq = ($st.staff | Where-Object { $_.name -eq "統括" } | Select-Object -First 1).room_id }
    $A = @{ Authorization = "Bot $tok"; "User-Agent" = "DiscordBot (ai-office, 1.0)" }
    $me = (Invoke-RestMethod -Uri "https://discord.com/api/v10/users/@me" -Headers $A -TimeoutSec 15).id
    $msgs = Invoke-RestMethod -Uri ("https://discord.com/api/v10/channels/" + $hq + "/messages?limit=10") -Headers $A -TimeoutSec 15
    foreach ($m in $msgs) { if ($m.author.id -eq $me -and ([datetime]$m.timestamp).ToUniversalTime() -gt $since -and ($m.content -match "Congratulations|起動しました")) { return $true } }
  } catch {}
  return $false
}
if (-not $Test) {
  Write-Host "  Claude が Discord とつながるのを待っています（最長2分半）…"
  $since = (Get-Date).ToUniversalTime().AddMinutes(-2); $ok = $false
  for ($n = 1; $n -le 30 -and -not $ok; $n++) { Start-Sleep 5; $ok = BotPosted $since }
  if (-not $ok) {
    Warn "Discord とのつながりが遅いので、Claude を1回だけ起動し直します"
    Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match "claude" -and $_.CommandLine -match "--channels" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep 5
    $since = (Get-Date).ToUniversalTime()
    $sp2 = Start-Process powershell.exe -ArgumentList "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", ("`"" + (Join-Path $SK "scripts\start.ps1") + "`""), "-Office", ("`"" + $Desk + "`"") -RedirectStandardOutput (Join-Path $Logs "setup_start2.log") -RedirectStandardError (Join-Path $Logs "setup_start2_err.log") -WindowStyle Hidden -PassThru
    $sp2.WaitForExit()
    for ($n = 1; $n -le 30 -and -not $ok; $n++) { Start-Sleep 5; $ok = BotPosted $since }
  }
  if ($ok) { Ok "Claude が Discord につながりました（統括の部屋に投稿を確認）" }
  else { Warn "Claude が統括の部屋に投稿していません。Claude の窓を閉じて、机の上の AIオフィス の「起動」をダブルクリックしてください" }
}

Write-Host ""
Write-Host "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊" -ForegroundColor Yellow
Write-Host ""
Write-Host "      🎉  Congratulations!  セットアップ完了です  🎉" -ForegroundColor Green
Write-Host ""
Write-Host "  AIオフィスが完成しました。このまま使えます。"
Write-Host ""
Write-Host "  ▶ 次にあなたがすること"
Write-Host "    スマホの Discord で「秘書」の部屋に「テスト」と送ってみてください。"
Write-Host "    返事が来たら、もう社員が働いています 🙌"
Write-Host ""
Write-Host "  ・この窓は閉じて大丈夫です（Claude は別の窓で動いています）"
Write-Host "  ・Claude が動いている窓は閉じないでください"
Write-Host "  ・パソコンは電源につないで、スリープしない設定にしておいてください"
Write-Host ""
Write-Host "🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊🎉✨🎊" -ForegroundColor Yellow
Read-Host "Enter で閉じる" | Out-Null
