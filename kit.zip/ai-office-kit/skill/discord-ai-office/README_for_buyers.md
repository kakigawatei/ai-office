# Discord AI オフィス — スマホから「AI社員」に指示する仕組み（導入手順）

「Discord の部屋ごとに AI の担当者を置く」仕組みです。あなたはスマホで、経理の部屋に「請求書まとめて」、動画の部屋に「リール作って」と書くだけ。
裏では Claude Code が1つ動いていて、どの部屋から来たかで人格と作業場所を切り替えます。

## 必要なもの
- Claude Code（Discord プラグインが使える版）が動く PC（Windows / Mac）
- Discord アカウントと、自分用のサーバー（無料）
- Claude in Chrome か、ブラウザを自分で操作する時間 10分

## 手順（合計 30〜40分）
### 1. Discord の bot を作る（10分）
`browser/create_bot_instruction.txt` を開き、中身を Claude in Chrome（またはブラウザを操作できる AI）に貼ってください。サーバー名の空欄だけ自分のサーバー名にします。
ログインと最後の「認証」ボタンだけ自分で押します。終わると **Bot トークン** と **招待完了** が手に入ります。

### 2. Claude Code にトークンを渡す（3分）
Claude Code のターミナルで `/discord:configure` → トークンを貼る。続けて `/discord:access` で自分の Discord ユーザー ID を許可します。

### 3. 社員を雇う（1人1分）
```
python ~/.claude/skills/discord-ai-office/scripts/office.py hire "ジョー" "経理・会計" --emoji 🧾 --project "C:\path\to\keiri"
python ~/.claude/skills/discord-ai-office/scripts/office.py hire "リー" "動画・SNS" --emoji 🎬
```
実行すると、Discord に「AIオフィス」カテゴリと部屋ができ、部屋に挨拶が投稿され、社員の定義ファイルが `~/.claude/ai-office/staff/` にできます。

### 4. CLAUDE.md に「作法」を貼る（2分）
`templates/CLAUDE_snippet.md` の中身を `~/.claude/CLAUDE.md` の末尾に貼ってください。これで「来た部屋に返す」「コピペ値は単独で」「🇦🇧🇨で聞く」が毎回効きます。

### 5. 起動して試す
```
claude --channels plugin:discord@claude-plugins-official
```
スマホの Discord で、ジョーの部屋に「ジョー、テスト」と書く。返事が来たら完成です。

## 日常の使い方
- 部屋に書く＝その担当への指示。写真もそのまま送れます。
- 「新しい担当を作って」と書けば、AI が `hire` を実行して部屋を増やします。
- 選択肢のある相談は 🇦🇧🇨 の絵文字が出るので、タップで答えます。

## よくあるつまずき
- 返事が来ない → 起動コマンドに `--channels ...` が付いているか。付けずに起動すると受信だけ止まります。
- 部屋を作ったのに無視される → Claude Code を起動し直す（許可ファイルを読み直す）。
- bot の発言に AI が反応しない → 仕様です（bot→bot は届かない）。人が書いたものだけ届きます。
- 添付が開けない → ファイル名を半角英数に。

## 中身
- `SKILL.md` … Claude Code 向けの手順書（AI が読む）
- `scripts/office.py` … 部屋作成・社員登録・投稿・絵文字投票
- `templates/persona.md` … 社員定義のひな形
- `templates/CLAUDE_snippet.md` … 作法（CLAUDE.md に貼る）
- `browser/create_bot_instruction.txt` … bot 作成のブラウザ操作指示文
