# -*- coding: utf-8 -*-
"""invoice-inbox: 請求書を「01_未払い」「02_支払済み/YYYY-MM」の 2 つのフォルダで管理する小さな道具。
保存先は 2 通りから選べる（init のときに決めて設定ファイルに覚える）:
  drive … Google ドライブ（パソコン版）の同期フォルダ。スマホの Drive アプリからも見える・ほかの端末と共有しやすい
  local … このパソコンの中だけ（見分けられるクラウド同期の場所を避ける）。スマホからは見えない

  python inv.py init --where drive|local [--root フォルダ]       … 保存先を決めてフォルダと使い方.txt を作る（あとで変えるときも同じ）
  python inv.py add  <ファイル> <期日|期日未定> <取引先> <金額> [--memo 文字]   … 01_未払い にコピー
  python inv.py paid <ファイル> <支払日> <取引先> <金額> --checked [--memo 文字] … 02_支払済み/YYYY-MM に直接コピー（通帳・明細で支払いを確かめた物だけ）
  python inv.py pay  <01_未払いのファイル名の一部> [--date YYYY-MM-DD]        … 02_支払済み/YYYY-MM へ移動（名前の先頭を支払日に）
  python inv.py list  [--days 14]                                  … 01_未払い を期日順に表示
  python inv.py check [--days 14]                                  … list と同じ（定期点検用）。最後に COUNT= を出す
  python inv.py where                                              … いまの保存先（drive / local）と場所を表示

置き場所の決め方（上から順に）:
  1) --root <フォルダ>   2) 環境変数 INVOICE_ROOT   3) 設定ファイル（init で作る。既定 ~/.invoice-inbox.json・環境変数 INVOICE_CONFIG で変更可）
  drive を選ぶと Google ドライブの「マイドライブ / My Drive」を自動検出して その下の 請求書
  local を選ぶと デスクトップの 請求書（デスクトップが OneDrive・iCloud などで同期されている場合は、同期されないホームフォルダの 請求書）
フォルダ名の変更: 環境変数 INVOICE_DIRNAME（既定 請求書）／INVOICE_UNPAID（既定 01_未払い）／INVOICE_PAID（既定 02_支払済み）
重複の確認: add / paid は、同じ中身のファイル（どちらのフォルダでも）や、同じ取引先・同じ金額の未払いがあると止まる（--force で続行）
Python 3.8 以上・標準ライブラリのみ。
"""
import argparse
import datetime
import glob
import hashlib
import io
import json
import os
import re
import shutil
import string
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

DIRNAME = os.environ.get("INVOICE_DIRNAME") or "請求書"
UNPAID = os.environ.get("INVOICE_UNPAID") or "01_未払い"
PAID = os.environ.get("INVOICE_PAID") or "02_支払済み"
UNKNOWN_DUE = "期日未定"
UNKNOWN_AMT = "不明"
NAME_RE = re.compile(r"^(?P<due>\d{4}-\d{2}-\d{2}|" + UNKNOWN_DUE + r")_(?P<who>[^_]+)_(?P<amt>\d+|" + UNKNOWN_AMT + r")(?:_(?P<memo>[^.]*?))?(?:\((?P<dup>\d+)\))?(?P<ext>\.[^.]+)$")   # 末尾の (2) は同名登録の通し番号
SKIP = {"desktop.ini", ".ds_store", "thumbs.db"}
CONFIG = os.environ.get("INVOICE_CONFIG") or os.path.join(os.path.expanduser("~"), ".invoice-inbox.json")
MODES = {"drive": "Google ドライブ（スマホからも見える）", "local": "このパソコンの中だけ（クラウド同期の場所を避ける）", "custom": "指定したフォルダ"}

README = """請求書フォルダの使い方

■ フォルダは 2 つだけ
{unpaid} … まだ払っていない請求書。メール添付・スキャン・写真・チャットで届いた物は全部ここ
{paid} … 払い終わった物。月ごとのフォルダ（例 2026-10）

■ 名前の決まり（並べるだけで期日順になる）
{unpaid}: 期日_取引先_金額.pdf     例 2026-10-31_サンプル商事_33000.pdf
{paid}: 支払日_取引先_金額.pdf     例 2026-10-28_サンプル商事_33000.pdf
期日が分からない物は「{ud}」、金額が分からない物は「{ua}」
パスワードや口座番号はファイル名に入れない

■ 払ったら
ファイルを「{paid}/その月」へ移動する（名前の先頭を支払日に直せるとなお良い）
保存先が Google ドライブならスマホの Drive アプリからも移動できる。パソコンの中だけの場合はパソコンで移動する

■ {unpaid} に残っている物 ＝ 払っていない物
週 1 回、ここを見て期日が近い物・過ぎた物を確かめる
"""


def drive_candidates():
    """Google ドライブ（パソコン版）の「マイドライブ / My Drive」の候補を返す"""
    names = ("マイドライブ", "My Drive")
    found = []
    if os.name == "nt":
        for letter in string.ascii_uppercase:
            for n in names:
                p = "%s:\\%s" % (letter, n)
                if os.path.isdir(p):
                    found.append(p)
    home = os.path.expanduser("~")
    for pat in ("Library/CloudStorage/GoogleDrive-*/%s", "Google Drive/%s", "GoogleDrive/%s"):
        for n in names:
            found += [p for p in glob.glob(os.path.join(home, pat % n)) if os.path.isdir(p)]
    return found


def drive_root():
    c = drive_candidates()
    if len(c) == 1:
        return os.path.join(c[0], DIRNAME)
    if not c:
        sys.exit("Google ドライブの同期フォルダが見つかりません。Google ドライブ（パソコン版）を入れて同期するか、--root <フォルダ> で場所を指定してください")
    sys.exit("Google ドライブの候補が複数あります: %s\n--root で 1 つ選んでください（例 --root \"%s\"）" % (" / ".join(c), os.path.join(c[0], DIRNAME)))


def is_cloud_synced(path):
    """この道具が見分けられるクラウド同期（OneDrive・iCloud・Dropbox・Google ドライブ）の中か。
    ※ それ以外のバックアップ・同期ソフトまでは見分けられない（持ち主が確かめる）"""
    rp = os.path.realpath(path)
    low = rp.lower()
    if any(k in low for k in ("onedrive", "icloud", "mobile documents", "dropbox", "googledrive", "google drive", "cloudstorage", "マイドライブ", "my drive")):
        return True
    # Mac の「デスクトップと書類フォルダ」を iCloud に置く設定: ~/Desktop・~/Documents の中は（深い階層でも）全部同期される
    home = os.path.realpath(os.path.expanduser("~"))
    icloud = os.path.join(home, "Library", "Mobile Documents", "com~apple~CloudDocs")
    for name in ("Desktop", "Documents"):
        if os.path.isdir(os.path.join(icloud, name)):
            top = os.path.join(home, name)
            try:
                if os.path.commonpath([os.path.normcase(rp), os.path.normcase(top)]) == os.path.normcase(top):
                    return True
            except ValueError:   # 別ドライブなど
                pass
    return False


def local_root():
    home = os.path.expanduser("~")
    desk = os.path.join(home, "Desktop")
    if os.path.isdir(desk) and not is_cloud_synced(os.path.join(desk, DIRNAME)):
        return os.path.join(desk, DIRNAME), ""
    alt = os.path.join(home, DIRNAME)
    if is_cloud_synced(alt):
        sys.exit("デスクトップもホームフォルダもクラウドと同期されています。同期されない場所を --root で指定してください")
    return alt, "デスクトップがクラウド（OneDrive・iCloud など）と同期されているか見つからないため、ホームフォルダに作りました"


def load_config():
    try:
        with io.open(CONFIG, encoding="utf-8") as f:
            c = json.load(f)
        return c if isinstance(c, dict) and c.get("root") else None
    except (OSError, ValueError):
        return None


def env_root():
    v = os.environ.get("INVOICE_ROOT")
    return os.path.abspath(v) if v else None


def root_of(a):
    if getattr(a, "root", None):
        return os.path.abspath(a.root)
    e, c = env_root(), load_config()
    if e and c and os.path.normcase(e) != os.path.normcase(os.path.abspath(c["root"])):
        # 設定（init で選んだ保存先）と環境変数が食い違う → どちらに入れるか分からないので止める
        sys.exit("保存先が 2 つあって食い違っています。どちらかに揃えてください:\n"
                 "  設定ファイル（init で選んだ）: %s（%s）\n  環境変数 INVOICE_ROOT: %s\n"
                 "環境変数を使わないなら消す／設定を環境変数に合わせるなら init をやり直す" % (c["root"], c.get("mode", "?"), e))
    if e:
        return e
    if c:
        return os.path.abspath(c["root"])
    sys.exit("保存先がまだ決まっていません。先に init で選んでください:\n"
             "  python inv.py init --where drive   … Google ドライブ（スマホからも見える）\n"
             "  python inv.py init --where local   … このパソコンの中だけ（クラウド同期の場所を避ける）")


def need_folders(r):
    """フォルダが無い＝場所の指定違い・同期切れ。空と区別して止める"""
    miss = [d for d in (UNPAID, PAID) if not os.path.isdir(os.path.join(r, d))]
    if miss:
        sys.exit("請求書フォルダが見つかりません: %s（%s が無い）。場所の指定違い・フォルダの移動・Google ドライブの同期切れのどれかです。初めてなら init を実行" % (r, " と ".join(miss)))


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def all_files(r):
    """両フォルダの全ファイル。フォルダ自体が読めないときは OSError を上げる（os.walk は既定でエラーを黙って飛ばすため）"""
    def fail(e):
        raise e
    out = []
    for base in (UNPAID, PAID):
        for dp, _, fs in os.walk(os.path.join(r, base), onerror=fail):
            for f in fs:
                if not f.startswith(".") and f.lower() not in SKIP:
                    out.append(os.path.join(dp, f))
    return out


def duplicates(r, src, who, amt):
    """同じ中身のファイル（両フォルダ）と、同じ取引先・同じ金額の未払い（中身が違っても二重登録の疑い）を返す"""
    out = []
    h = digest(src)
    try:
        files = all_files(r)
    except OSError as e:   # フォルダが読めない＝照合できていない。「重複なし」にしない
        return ["フォルダが読めないので照合できません: %s（%s）" % (getattr(e, "filename", None) or r, e.__class__.__name__)]
    for p in files:
        try:
            if os.path.getsize(p) == os.path.getsize(src) and digest(p) == h:
                out.append("同じ中身: " + os.path.relpath(p, r))
        except OSError as e:   # 読めない物を「重複なし」と扱わない（照合できていないのに登録させない）
            out.append("読めないので照合できません: %s（%s）" % (os.path.relpath(p, r), e.__class__.__name__))
    digits = re.sub(r"[^\d]", "", str(amt))
    up = os.path.join(r, UNPAID)
    for f in os.listdir(up):
        m = NAME_RE.match(f)
        if m and m.group("who") == safe(who) and digits and m.group("amt") == digits:
            out.append("同じ取引先・同じ金額の未払い: " + os.path.join(UNPAID, f))
    return sorted(set(out))


def stop_if_duplicate(r, a):
    if a.force:
        return
    d = duplicates(r, a.file, a.who, a.amount)
    if d:
        sys.exit("二重登録の疑いがあるので止めました（本当に別の請求なら --force を付けて実行。読めないファイルがあるときは、同期が終わってからやり直す）\n  " + "\n  ".join(d))


def safe(s):
    return re.sub(r'[\\/:*?"<>|_\r\n\t]', "-", str(s)).strip() or "-"


def build_name(date, who, amt, memo, ext):
    digits = re.sub(r"[^\d]", "", str(amt))
    n = "%s_%s_%s" % (date, safe(who), digits or UNKNOWN_AMT)
    if memo:
        n += "_" + safe(memo)
    return n + (ext or "").lower()


def unique(path):
    if not os.path.exists(path):
        return path
    b, e = os.path.splitext(path)
    k = 2
    while os.path.exists("%s(%d)%s" % (b, k, e)):
        k += 1
    return "%s(%d)%s" % (b, k, e)


def check_date(s, allow_unknown=False):
    if allow_unknown and s == UNKNOWN_DUE:
        return s
    try:
        return datetime.date.fromisoformat(s).isoformat()
    except ValueError:
        sys.exit("日付は YYYY-MM-DD で（例 2026-10-31）" + ("、分からなければ %s" % UNKNOWN_DUE if allow_unknown else ""))


def cmd_where(a):
    r = root_of(a)
    c = load_config() or {}
    mode = "custom" if (getattr(a, "root", None) or os.environ.get("INVOICE_ROOT")) else c.get("mode", "custom")
    print("MODE=%s（%s）" % (mode, MODES.get(mode, mode)))
    print("ROOT=%s" % r)


def cmd_init(a):
    note = ""
    if a.root:
        r, mode = os.path.abspath(a.root), (a.where or "custom")
    elif a.where == "drive":
        r, mode = drive_root(), "drive"
    elif a.where == "local":
        (r, note), mode = local_root(), "local"
    else:
        sys.exit("保存先を選んでください（セキュリティの好みで決める）:\n"
                 "  --where drive … Google ドライブ。スマホの Drive アプリからも見える・移動できる。Google アカウントの守りが大事\n"
                 "  --where local … このパソコンの中だけ。OneDrive・iCloud・Dropbox・Google ドライブの同期場所は避ける（ほかのバックアップ・同期ソフトは持ち主が確かめる）。スマホからは見えない・バックアップは自分で")
    e = env_root()
    if e and os.path.normcase(e) != os.path.normcase(r):
        sys.exit("環境変数 INVOICE_ROOT が別の場所（%s）を指しています。このままだと選んだ保存先と食い違うので止めました。環境変数を消してから init をやり直してください" % e)
    if mode == "local" and is_cloud_synced(r):
        sys.exit("その場所はクラウドと同期されています（%s）。パソコンの中だけにするなら、同期されない場所を --root で指定してください" % r)
    os.makedirs(os.path.join(r, UNPAID), exist_ok=True)
    os.makedirs(os.path.join(r, PAID), exist_ok=True)
    p = os.path.join(r, "使い方.txt")
    if not os.path.exists(p):
        io.open(p, "w", encoding="utf-8").write(README.format(unpaid=UNPAID, paid=PAID, ud=UNKNOWN_DUE, ua=UNKNOWN_AMT))
    if not a.no_save:
        old = load_config()
        io.open(CONFIG, "w", encoding="utf-8").write(json.dumps({"mode": mode, "root": r, "set": datetime.date.today().isoformat()}, ensure_ascii=False, indent=1))
        if old and os.path.abspath(old["root"]) != r:
            print("※ 保存先を変えました。前の場所（%s）の請求書は自動では移しません。必要なら手で移してください" % old["root"])
    if note:
        print("※ " + note)
    print("MODE=%s（%s）" % (mode, MODES.get(mode, mode)))
    print("OK", r)


def need_file(f):
    if not os.path.isfile(f):
        sys.exit("ファイルがありません: %s" % f)


def cmd_add(a):
    need_file(a.file)
    due = check_date(a.due, allow_unknown=True)
    r = root_of(a)
    need_folders(r)
    stop_if_duplicate(r, a)
    dst = unique(os.path.join(r, UNPAID, build_name(due, a.who, a.amount, a.memo, os.path.splitext(a.file)[1])))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(a.file, dst)
    print("ADDED", os.path.relpath(dst, r))


def cmd_paid(a):
    need_file(a.file)
    date = check_date(a.date)
    if not a.checked:
        sys.exit("paid は「通帳・明細・領収書で支払いを確かめた物」だけに使います。確かめたら --checked を付けて実行。\n"
                 "口座振替・カード払いの予定（まだ引き落とされていない物）は add で 01 未払い に入れ、確かめてから pay で移してください")
    r = root_of(a)
    need_folders(r)
    stop_if_duplicate(r, a)
    dst = unique(os.path.join(r, PAID, date[:7], build_name(date, a.who, a.amount, a.memo, os.path.splitext(a.file)[1])))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(a.file, dst)
    print("PAID_ADDED", os.path.relpath(dst, r))


def cmd_pay(a):
    r = root_of(a)
    need_folders(r)
    up = os.path.join(r, UNPAID)
    hits = [f for f in (os.listdir(up) if os.path.isdir(up) else []) if a.match in f and f.lower() not in SKIP]
    if len(hits) != 1:
        sys.exit("一致が %d 件です: %s（名前の一部をもっと長く）" % (len(hits), " / ".join(hits) or "なし"))
    f = hits[0]
    info = NAME_RE.match(f)
    date = check_date(a.date) if a.date else datetime.date.today().isoformat()
    if info:
        g = info.groupdict()
        newname = build_name(date, g["who"], g["amt"], g["memo"], g["ext"])
    else:
        newname = f
    dst = unique(os.path.join(r, PAID, date[:7], newname))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.move(os.path.join(up, f), dst)
    print("MOVED", f, "->", os.path.relpath(dst, r))


def rows(a):
    r = root_of(a)
    need_folders(r)
    up = os.path.join(r, UNPAID)
    today = datetime.date.today()
    out = []
    for f in sorted(os.listdir(up)):
        if f.startswith(".") or f.lower() in SKIP:
            continue
        m = NAME_RE.match(f)
        if not m:
            out.append(("❓", None, f, "名前が決まりと違う"))
            continue
        due = m.group("due")
        if due == UNKNOWN_DUE:
            out.append(("❓", None, f, "期日未定"))
            continue
        d = datetime.date.fromisoformat(due)
        left = (d - today).days
        mark = "🟥" if left < 0 else ("🟡" if left <= a.days else "🔵")
        out.append((mark, d, f, ("期日超過 %d 日" % -left) if left < 0 else ("あと %d 日" % left)))
    order = {"🟥": 0, "🟡": 1, "❓": 2, "🔵": 3}
    out.sort(key=lambda x: (order[x[0]], x[1] or datetime.date.max))
    return out


def cmd_list(a):
    rs = rows(a)
    if not rs:
        print("%s は空です" % UNPAID)
    for mark, _, f, note in rs:
        print("%s %s（%s）" % (mark, f, note))
    print("COUNT=%d OVERDUE=%d SOON=%d UNKNOWN=%d" % (
        len(rs), sum(x[0] == "🟥" for x in rs), sum(x[0] == "🟡" for x in rs), sum(x[0] == "❓" for x in rs)))


def main():
    ap = argparse.ArgumentParser(description="請求書フォルダ（未払い／支払済み）の道具")
    ap.add_argument("--root", help="請求書フォルダの場所（省略時は環境変数 INVOICE_ROOT か Google ドライブを自動検出）")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("--where", choices=["drive", "local"], help="drive＝Google ドライブ／local＝このパソコンの中だけ")
    p.add_argument("--no-save", action="store_true", help="設定ファイルに覚えない（試験用）")
    p.add_argument("--root", default=argparse.SUPPRESS, help="保存先のフォルダを自分で決める（init の後ろにも書ける）")
    sub.add_parser("where")
    p = sub.add_parser("add"); p.add_argument("file"); p.add_argument("due"); p.add_argument("who"); p.add_argument("amount"); p.add_argument("--memo")
    p.add_argument("--force", action="store_true", help="二重登録の疑いがあっても入れる")
    p = sub.add_parser("paid"); p.add_argument("file"); p.add_argument("date"); p.add_argument("who"); p.add_argument("amount"); p.add_argument("--memo")
    p.add_argument("--checked", action="store_true", help="通帳・明細・領収書で支払いを確かめた")
    p.add_argument("--force", action="store_true", help="二重登録の疑いがあっても入れる")
    p = sub.add_parser("pay"); p.add_argument("match"); p.add_argument("--date")
    for n in ("list", "check"):
        p = sub.add_parser(n); p.add_argument("--days", type=int, default=14)
    a = ap.parse_args()
    {"init": cmd_init, "where": cmd_where, "add": cmd_add, "paid": cmd_paid, "pay": cmd_pay, "list": cmd_list, "check": cmd_list}[a.cmd](a)


if __name__ == "__main__":
    main()
