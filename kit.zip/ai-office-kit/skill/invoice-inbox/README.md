# invoice-inbox（請求書の受け箱）

請求書を 2 つのフォルダ（`01_未払い` / `02_支払済み/YYYY-MM`）だけで管理する（置き場は Google ドライブか、このパソコンの中だけかを選べる）、Claude Code 用のスキルです。
「未払いフォルダに残っている物＝払っていない物」という状態を保つことで、払い忘れ・二重払い・「払ったっけ？」を減らします。

## 入れ方
1. このフォルダごと `~/.claude/skills/invoice-inbox/` に置く（Windows は `C:\Users\<あなた>\.claude\skills\invoice-inbox\`）
2. Claude Code に「請求書フォルダを作って」と頼む
3. 保存先を聞かれるので選ぶ
   - **Google ドライブ** … スマホからも未払いを確かめられる（Google ドライブ パソコン版の同期が必要）
   - **このパソコンの中だけ** … OneDrive・iCloud・Dropbox・Google ドライブの同期場所を避けて作る（ほかの同期ソフトは自分で確かめる・スマホからは見えない・バックアップは自分で）

## 必要なもの
- Python 3.8 以上（標準ライブラリのみ）
- Google ドライブを選ぶ場合のみ: Google ドライブ（パソコン版）
- 好きなフォルダにしたい場合は `init --where local --root <フォルダ>`

## 試験
```
python tests/test_inv.py
```

## 中身
- `SKILL.md` … Claude が読む手順書（いつ使うか・名前の決まり・日々の流れ・守ること）
- `scripts/inv.py` … フォルダ操作の道具（init / add / paid / pay / list / check / where）
- `tests/test_inv.py` … 一時フォルダでの通し試験

## ライセンス
自由に使い・改変・再配布してかまいません（無保証）。
