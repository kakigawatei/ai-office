# -*- coding: utf-8 -*-
# invoice-inbox の試験（一時フォルダで init → add → list → pay → paid と、異常系を通す）
import datetime, os, subprocess, sys, tempfile
sys.dont_write_bytecode = True   # 試験で scripts/__pycache__ を作らない（パソコンのパスが入るため）

HERE = os.path.dirname(os.path.abspath(__file__))
INV = os.path.join(HERE, "..", "scripts", "inv.py")
tmp = tempfile.mkdtemp(prefix="inv_test_")
root = os.path.join(tmp, "請求書")
env = dict(os.environ, PYTHONUTF8="1", INVOICE_CONFIG=os.path.join(tmp, "config.json"))   # 本物の設定ファイルに触らない
env.pop("INVOICE_ROOT", None)


def run(*args, ok=True, at=None, noroot=False, extra=None):
    e = dict(env, **(extra or {}))
    pre = [] if noroot else ["--root", at or root]
    r = subprocess.run([sys.executable, INV] + pre + list(args), capture_output=True, text=True, encoding="utf-8", env=e)
    out = r.stdout + r.stderr
    assert (r.returncode == 0) == ok, (args, out)
    return out


def bill(name, body):
    p = os.path.join(tmp, name)
    open(p, "wb").write(body)
    return p


today = datetime.date.today()
past = (today - datetime.timedelta(days=3)).isoformat()
soon = (today + datetime.timedelta(days=5)).isoformat()
later = (today + datetime.timedelta(days=40)).isoformat()
b1, b2, b3, b4, b5 = (bill("b%d.pdf" % i, b"%%PDF-1.4 bill %d" % i) for i in range(1, 6))

# 異常系 1: フォルダが無い（同期切れ・指定違い）→「空」と言わずに止まる
out = run("check", ok=False)
assert "見つかりません" in out, out
run("add", b1, past, "サンプル商事", "33000", ok=False)
print("1) フォルダ無しで止まる OK")

assert "OK" in run("init")
assert os.path.isdir(os.path.join(root, "01_未払い")) and os.path.isfile(os.path.join(root, "使い方.txt"))
run("add", b1, past, "サンプル商事", "33,000")
run("add", b2, soon, "テスト_工業", "12000", "--memo", "10月分")
run("add", b3, later, "例示サービス", "5500")
run("add", b4, "期日未定", "見本株式会社", "不明")
run("add", b1, "2026/10/01", "x", "1", ok=False)
out = run("check")
assert "COUNT=4 OVERDUE=1 SOON=1 UNKNOWN=1" in out, out
assert out.index("🟥") < out.index("🟡") < out.index("❓") < out.index("🔵"), out
assert "テスト-工業" in out, out
print("2) 登録・点検 OK")

# 異常系 2: 二重登録 — 同じ中身／同じ取引先・同じ金額は止まる。--force なら入る
out = run("add", b1, later, "別名商店", "1", ok=False)
assert "同じ中身" in out, out
out = run("add", b5, later, "サンプル商事", "33000", ok=False)
assert "同じ取引先・同じ金額" in out, out
run("add", b5, later, "サンプル商事", "33000", "--force")
assert "COUNT=5" in run("list")
print("3) 二重登録の防止 OK")

# 払う → 支払済みへ。支払済みにある物の再登録も止まる
out = run("pay", "%s_サンプル商事" % past, "--date", today.isoformat())
assert "MOVED" in out, out
moved = os.listdir(os.path.join(root, "02_支払済み", today.isoformat()[:7]))
assert moved == ["%s_サンプル商事_33000.pdf" % today.isoformat()], moved
out = run("add", b1, later, "サンプル商事", "33000", ok=False)
assert "同じ中身" in out and "02_支払済み" in out, out
run("pay", "存在しない", ok=False)
print("4) 支払済みへの移動と再登録防止 OK")

# 異常系 3: paid は確かめた物だけ（--checked 必須）
b6 = bill("card.pdf", b"%PDF-1.4 card")
out = run("paid", b6, "2026-09-30", "カード払いの店", "880", ok=False)
assert "--checked" in out, out
run("paid", b6, "2026-09-30", "カード払いの店", "880", "--checked")
assert os.listdir(os.path.join(root, "02_支払済み", "2026-09")) == ["2026-09-30_カード払いの店_880.pdf"]
print("5) 支払済みの直接登録は確認つきだけ OK")

# 異常系 4: --force で同名登録 → 末尾 (2) が付いても期日で分類される（❓ にならない）
b7 = bill("b7.pdf", b"%PDF-1.4 same name 1")
b8 = bill("b8.pdf", b"%PDF-1.4 same name 2")
run("add", b7, past, "同名テスト", "1000")
run("add", b8, past, "同名テスト", "1000", "--force")
names = sorted(f for f in os.listdir(os.path.join(root, "01_未払い")) if "同名テスト" in f)
assert names == ["%s_同名テスト_1000(2).pdf" % past, "%s_同名テスト_1000.pdf" % past], names
out = run("check")
assert out.count("同名テスト") == 2 and "名前が決まりと違う" not in out, out
assert sum(1 for line in out.splitlines() if "同名テスト" in line and line.startswith("🟥")) == 2, out
run("add", bill("b9.pdf", b"%PDF-1.4 memo dup"), later, "メモ付き", "500", "--memo", "10月分")
run("add", bill("b10.pdf", b"%PDF-1.4 memo dup2"), later, "メモ付き", "500", "--memo", "10月分", "--force")
out = run("check")
assert "名前が決まりと違う" not in out, out
print("6) 同名登録の (2) も期日で分類 OK")

# 異常系 5: 照合中に読めないファイルがあれば止まる（無視して通さない）
import importlib.util
spec = importlib.util.spec_from_file_location("inv_mod", INV)
inv = importlib.util.module_from_spec(spec); spec.loader.exec_module(inv)
real_digest = inv.digest
victim = os.path.join(root, "01_未払い", sorted(os.listdir(os.path.join(root, "01_未払い")))[0])
newbill = bill("b11.pdf", b"%PDF-1.4 x" * 1)
open(newbill, "wb").write(open(victim, "rb").read()[:-1] + b"Z")   # 同じ大きさ・違う中身 → 照合で中身を読む
def broken(p):
    if os.path.abspath(p) == os.path.abspath(victim):
        raise PermissionError("locked")
    return real_digest(p)
inv.digest = broken
d = inv.duplicates(root, newbill, "別の会社", "7")
assert any("読めないので照合できません" in x for x in d), d
print("7) 読めないファイルがあれば止まる OK")

# 異常系 6: フォルダ自体が読めない（os.walk のエラー）→ 「照合できません」で止まる
inv.digest = real_digest
real_walk = inv.os.walk
def walk_fail(top, onerror=None, **kw):
    e = PermissionError(13, "denied", top)
    if onerror:
        onerror(e)
    return iter(())
inv.os.walk = walk_fail
try:
    d = inv.duplicates(root, newbill, "別の会社", "7")
finally:
    inv.os.walk = real_walk
assert d and "フォルダが読めないので照合できません" in d[0], d
print("8) フォルダが読めなければ止まる OK")

# 保存先の選択（drive / local）
home = os.path.join(tmp, "home"); os.makedirs(os.path.join(home, "Desktop"))
hx = {"USERPROFILE": home, "HOME": home, "INVOICE_CONFIG": os.path.join(tmp, "config2.json")}
out = run("check", noroot=True, extra=hx, ok=False)
assert "保存先がまだ決まっていません" in out, out
out = run("init", noroot=True, extra=hx, ok=False)
assert "--where drive" in out and "--where local" in out, out
out = run("init", "--where", "local", noroot=True, extra=hx)
assert "MODE=local" in out and os.path.join(home, "Desktop", "請求書") in out, out
out = run("where", noroot=True, extra=hx)
assert "MODE=local" in out, out
run("add", bill("b20.pdf", b"%PDF-1.4 local"), later, "ローカル確認", "100", noroot=True, extra=hx)
assert "COUNT=1" in run("check", noroot=True, extra=hx)
cloud = os.path.join(tmp, "OneDrive", "請求書")
out = run("init", "--where", "local", "--root", cloud, noroot=True, extra=hx, ok=False)
assert "クラウドと同期" in out, out
print("9) 保存先の選択（local・未設定・クラウド拒否）OK")

# 環境変数 INVOICE_ROOT が設定と食い違う → どちらに入れるか分からないので止まる（登録も init も）
other = os.path.join(tmp, "other_drive", "請求書")
out = run("add", bill("b21.pdf", b"%PDF-1.4 conflict"), later, "競合", "1", noroot=True, extra=dict(hx, INVOICE_ROOT=other), ok=False)
assert "食い違って" in out, out
out = run("init", "--where", "local", noroot=True, extra=dict(hx, INVOICE_ROOT=other), ok=False)
assert "INVOICE_ROOT" in out, out
assert "COUNT=1" in run("check", noroot=True, extra=hx)            # 環境変数が無ければ元どおり
print("10) 設定と環境変数の食い違いで止まる OK")

# Mac の「デスクトップと書類」を iCloud に置く設定: Desktop の深い階層を指定しても止まる
mh = os.path.join(tmp, "machome"); os.makedirs(os.path.join(mh, "Desktop", "経理"))
os.makedirs(os.path.join(mh, "Library", "Mobile Documents", "com~apple~CloudDocs", "Desktop"))
mx = {"USERPROFILE": mh, "HOME": mh, "INVOICE_CONFIG": os.path.join(tmp, "config3.json")}
out = run("init", "--where", "local", "--root", os.path.join(mh, "Desktop", "経理", "請求書"), noroot=True, extra=mx, ok=False)
assert "クラウドと同期" in out, out
out = run("init", "--where", "local", noroot=True, extra=mx)     # 既定はデスクトップを避けてホームへ
assert os.path.join(mh, "請求書") in out and "ホームフォルダ" in out, out
print("11) iCloud 同期のデスクトップ配下を見分ける OK")
print("ALL OK")
