@echo off
chcp 65001 >nul
title AIオフィス を入れる
set "KIT=%~dp0"
set "SK=%USERPROFILE%\.claude\skills\discord-ai-office"
set "DESK=%USERPROFILE%\Desktop\AIオフィス"
echo === AIオフィス を入れます ===
if not exist "%USERPROFILE%\.claude\skills" mkdir "%USERPROFILE%\.claude\skills"
if exist "%SK%" rmdir /s /q "%SK%"
xcopy /e /i /q "%KIT%skill\discord-ai-office" "%SK%" >nul && echo ✓ スキル: %SK%
if exist "%DESK%" (echo ✓ 机の上の AIオフィス はすでにあります) else (xcopy /e /i /q "%KIT%AIオフィス" "%DESK%" >nul && echo ✓ 机の上に AIオフィス フォルダを作りました)
findstr /c:"discord-ai-office スキル" "%USERPROFILE%\.claude\CLAUDE.md" >nul 2>&1 || (echo.>>"%USERPROFILE%\.claude\CLAUDE.md" & type "%SK%\templates\CLAUDE_snippet.md">>"%USERPROFILE%\.claude\CLAUDE.md" & echo ✓ Claude の作法を CLAUDE.md に足しました)
echo.
echo 次: 机の上の「AIオフィス」フォルダを開いて「起動.bat」をダブルクリック
explorer "%DESK%"
pause
