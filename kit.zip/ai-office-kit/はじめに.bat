@echo off
chcp 65001 >nul
title AIオフィス セットアップ
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_win.ps1" -Kit "%~dp0."
